/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { SplashScreen } from './components/common/SplashScreen';
import { PWAInstallPrompt } from './components/common/PWAInstallPrompt';
import { Navbar, StudioTab } from './components/Navbar';
import { HomeDashboard } from './components/dashboard/HomeDashboard';
import { VideoEditor } from './components/video/VideoEditor';
import { GamingStudio } from './components/gaming/GamingStudio';
import { EntertainmentStudio } from './components/entertainment/EntertainmentStudio';
import { PhotoEditor } from './components/photo/PhotoEditor';
import { AndroidApkHub } from './components/android/AndroidApkHub';
import { Auth } from './components/auth/Auth';
import { MusicStudio } from './components/music/MusicStudio';
import { VideoProject, AudioTrack } from './types/editor';
import { UserProfile } from './types/auth';
import { ShieldCheck, Smartphone, Sparkles, Heart } from 'lucide-react';

const INITIAL_PROJECT: VideoProject = {
  id: 'proj_default',
  name: 'My Pro Montage',
  createdAt: Date.now(),
  updatedAt: Date.now(),
  aspectRatio: '16:9',
  clips: [],
  transitions: {},
  colorGrade: {
    preset: 'original',
    brightness: 0,
    contrast: 0,
    saturation: 0,
    temperature: 0,
    sharpness: 0,
    vignette: 0,
    filmGrain: 0,
    letterbox: false,
    letterboxHeight: 12
  },
  textOverlays: [],
  pipOverlays: [],
  audioTracks: []
};

export default function App() {
  const [currentTab, setCurrentTab] = useState<StudioTab>('dashboard');
  const [showSplash, setShowSplash] = useState(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Authenticated User State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const savedUser = localStorage.getItem('sufyan_auth_user');
      if (savedUser) return JSON.parse(savedUser);
    } catch (e) {}
    return null;
  });

  // Shared Video Project State across studios
  const [project, setProject] = useState<VideoProject>(() => {
    try {
      const saved = localStorage.getItem('sufyan_video_project');
      if (saved) {
        const parsed: VideoProject = JSON.parse(saved);
        if (parsed.clips && Array.isArray(parsed.clips)) {
          parsed.clips = parsed.clips.filter((c) => !c.sourceUrl.startsWith('blob:'));
        }
        return parsed;
      }
    } catch (e) {}
    return INITIAL_PROJECT;
  });

  const handleUpdateProject = (updated: VideoProject) => {
    const withTimestamp = { ...updated, updatedAt: Date.now() };
    setProject(withTimestamp);
    try {
      localStorage.setItem('sufyan_video_project', JSON.stringify(withTimestamp));
    } catch (e) {}
  };

  const handleAddMusicTrackToProject = (track: AudioTrack) => {
    const updated = {
      ...project,
      audioTracks: [...project.audioTracks, track]
    };
    handleUpdateProject(updated);
  };

  return (
    <div className="min-h-screen bg-black text-zinc-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-black">
      {/* Brand Mascot Splash Screen */}
      {showSplash && <SplashScreen onDismiss={() => setShowSplash(false)} />}

      {/* Mobile Android PWA Install Prompt Banner */}
      <PWAInstallPrompt />

      {/* Main Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthModalOpen(true)}
      />

      {/* Main App Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5">
        {/* Home Dashboard */}
        {currentTab === 'dashboard' && (
          <HomeDashboard
            onNavigateTab={(tab) => {
              if (tab === 'auth') {
                setIsAuthModalOpen(true);
              } else {
                setCurrentTab(tab as StudioTab);
              }
            }}
            currentProject={project}
            onOpenProject={(proj) => {
              setProject(proj);
              setCurrentTab('video');
            }}
            currentUser={currentUser}
            onOpenAuth={() => setIsAuthModalOpen(true)}
          />
        )}

        {/* Video Editor Studio */}
        {currentTab === 'video' && (
          <VideoEditor
            onNavigateToAndroid={() => setCurrentTab('android')}
            externalProject={project}
            onUpdateExternalProject={handleUpdateProject}
          />
        )}

        {/* Gaming Studio */}
        {currentTab === 'gaming' && (
          <GamingStudio
            project={project}
            onUpdateProject={handleUpdateProject}
            onOpenTimeline={() => setCurrentTab('video')}
          />
        )}

        {/* Entertainment Studio */}
        {currentTab === 'entertainment' && (
          <EntertainmentStudio
            project={project}
            onUpdateProject={handleUpdateProject}
            onOpenTimeline={() => setCurrentTab('video')}
          />
        )}

        {/* Music Studio */}
        {currentTab === 'music' && (
          <MusicStudio
            videoProject={project}
            onSendToVideoProject={handleAddMusicTrackToProject}
            onOpenVideoEditor={() => setCurrentTab('video')}
          />
        )}

        {/* Photo Studio */}
        {currentTab === 'photo' && <PhotoEditor />}

        {/* Android APK & Source Hub */}
        {currentTab === 'android' && <AndroidApkHub />}
      </main>

      {/* Unified Auth Modal */}
      {isAuthModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-lg">
            <Auth
              currentUser={currentUser}
              onUpdateUser={(user) => {
                setCurrentUser(user);
                if (user) setIsAuthModalOpen(false);
              }}
              onClose={() => setIsAuthModalOpen(false)}
              isModal={true}
            />
          </div>
        </div>
      )}

      {/* Mobile-Friendly Pro Footer */}
      <footer className="w-full bg-zinc-950 border-t border-zinc-800/80 py-4 px-4 text-xs text-zinc-500 mt-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-zinc-300">SUFYAN AI EDITOR PRO</span>
            <span>•</span>
            <span className="flex items-center space-x-1 text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>100% Free • No Watermark • 720p - 10K Output</span>
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-center sm:justify-end gap-3 text-zinc-400">
            <button
              onClick={() => setCurrentTab('dashboard')}
              className="hover:text-cyan-400 transition"
            >
              Dashboard
            </button>
            <span>•</span>
            <button
              onClick={() => setCurrentTab('gaming')}
              className="hover:text-purple-400 transition"
            >
              PUBG/BGMI Gaming
            </button>
            <span>•</span>
            <button
              onClick={() => setCurrentTab('android')}
              className="hover:text-red-400 transition underline underline-offset-2"
            >
              Build APK on Phone
            </button>
            <span>•</span>
            <span>v1.0.0</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
