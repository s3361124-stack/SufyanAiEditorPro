/**
 * Procedural Audio Synthesizer for free, offline, royalty-free audio tracks & sound effects
 * Uses Web Audio API to generate cinematic music loops and SFX without external downloads.
 */

export interface BuiltinSound {
  id: string;
  name: string;
  type: 'bgm' | 'sfx';
  duration: number; // in seconds
  description: string;
}

export const BUILTIN_AUDIO_LIST: BuiltinSound[] = [
  { id: 'epic-cinematic', name: 'Cinematic Movie Trailer', type: 'bgm', duration: 16, description: 'Deep bass, orchestral pulse, and dramatic rises' },
  { id: 'lofi-vlog', name: 'Chill Lofi Vlog Beat', type: 'bgm', duration: 16, description: 'Relaxing Rhodes chords and smooth hip-hop kick/snare' },
  { id: 'cyberpunk-pulse', name: 'Cyberpunk Synthwave', type: 'bgm', duration: 16, description: 'Arpeggiated retro neon synth & driving bassline' },
  { id: 'gaming-montage', name: 'Gaming Montage High Energy', type: 'bgm', duration: 16, description: 'Uptempo electronic rhythm with heavy drop' },
  { id: 'sfx-boom', name: 'Cinematic Sub Bass Boom', type: 'sfx', duration: 2.5, description: 'Deep impactful movie trailer hit' },
  { id: 'sfx-whoosh', name: 'Fast Whoosh Transition', type: 'sfx', duration: 0.8, description: 'Crisp transition swoosh for cutaways' },
  { id: 'sfx-shutter', name: 'Camera Shutter Click', type: 'sfx', duration: 0.5, description: 'Mechanical camera snapshot sound' },
  { id: 'sfx-glitch', name: 'Digital Glitch FX', type: 'sfx', duration: 1.2, description: 'Electronic static zap for text transitions' }
];

/**
 * Generate audio buffer and render to WAV blob for specified builtin sound
 */
export async function generateBuiltinAudio(soundId: string): Promise<string> {
  const sound = BUILTIN_AUDIO_LIST.find(s => s.id === soundId) || BUILTIN_AUDIO_LIST[0];
  const sampleRate = 44100;
  const totalSamples = Math.floor(sampleRate * sound.duration);
  const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
  const buffer = audioCtx.createBuffer(2, totalSamples, sampleRate);
  const left = buffer.getChannelData(0);
  const right = buffer.getChannelData(1);

  if (soundId === 'epic-cinematic') {
    // Dramatic cinematic rhythm: D minor orchestral bass chord progression (D -> Bb -> C -> A)
    const bpm = 90;
    const beatDuration = 60 / bpm;
    for (let i = 0; i < totalSamples; i++) {
      const t = i / sampleRate;
      const bar = Math.floor(t / (beatDuration * 4)) % 4;
      const freqRoot = [73.42, 58.27, 65.41, 55.0][bar]; // D2, Bb1, C2, A1
      
      // Sub bass
      let sample = Math.sin(2 * Math.PI * freqRoot * t) * 0.4;
      // Brass harmonic
      sample += Math.sin(2 * Math.PI * freqRoot * 2 * t) * 0.2;
      sample += Math.sin(2 * Math.PI * freqRoot * 3 * t) * 0.1;
      
      // Drum kick on every beat
      const beatProgress = (t % beatDuration) / beatDuration;
      if (beatProgress < 0.2) {
        const kickEnv = Math.exp(-beatProgress * 25);
        const kickPitch = 120 * Math.exp(-beatProgress * 30) + 45;
        sample += Math.sin(2 * Math.PI * kickPitch * beatProgress) * kickEnv * 0.5;
      }
      
      // Subtle stereo reverb/panning
      left[i] = Math.max(-1, Math.min(1, sample * 0.8));
      right[i] = Math.max(-1, Math.min(1, (sample + Math.sin(t * 12) * 0.05) * 0.8));
    }
  } else if (soundId === 'lofi-vlog') {
    // Warm chords & soft vinyl groove
    const bpm = 80;
    const beatDuration = 60 / bpm;
    for (let i = 0; i < totalSamples; i++) {
      const t = i / sampleRate;
      const chord = [220, 261.63, 329.63, 392.0]; // A minor 7
      let sample = 0;
      chord.forEach(f => {
        sample += Math.sin(2 * Math.PI * f * t) * 0.08;
        sample += Math.sin(2 * Math.PI * (f * 0.5) * t) * 0.12; // warm sub
      });
      // Soft vinyl crackle
      const crackle = (Math.random() - 0.5) * 0.02 * (Math.random() > 0.98 ? 1 : 0.1);
      sample += crackle;
      
      // Snare on beats 2 and 4
      const beat = (t / beatDuration) % 4;
      if (Math.abs(beat - 1) < 0.15 || Math.abs(beat - 3) < 0.15) {
        const snareEnv = Math.exp(-((t % beatDuration) / 0.1) * 8);
        sample += (Math.random() - 0.5) * snareEnv * 0.25;
      }
      left[i] = sample;
      right[i] = sample;
    }
  } else if (soundId === 'cyberpunk-pulse') {
    // 120 BPM driving synth bass
    const bpm = 120;
    const sixteenth = 60 / bpm / 4;
    for (let i = 0; i < totalSamples; i++) {
      const t = i / sampleRate;
      const step = Math.floor(t / sixteenth) % 16;
      const notes = [65.41, 65.41, 73.42, 65.41, 87.31, 87.31, 73.42, 65.41];
      const freq = notes[step % notes.length];
      const stepProgress = (t % sixteenth) / sixteenth;
      const env = Math.exp(-stepProgress * 6);
      
      // Sawtooth-like synth wave
      let sample = 0;
      for (let h = 1; h <= 6; h++) {
        sample += (Math.sin(2 * Math.PI * freq * h * t) / h) * 0.15;
      }
      sample *= env;
      
      left[i] = sample * (0.8 + 0.2 * Math.sin(t * 3));
      right[i] = sample * (0.8 - 0.2 * Math.sin(t * 3));
    }
  } else if (soundId === 'sfx-boom') {
    // Cinematic Sub Boom SFX
    for (let i = 0; i < totalSamples; i++) {
      const t = i / sampleRate;
      const env = Math.exp(-t * 1.8);
      const pitch = 90 * Math.exp(-t * 2.5) + 32;
      const sample = Math.sin(2 * Math.PI * pitch * t) * env * 0.9;
      left[i] = sample;
      right[i] = sample;
    }
  } else if (soundId === 'sfx-whoosh') {
    // Whoosh transition
    for (let i = 0; i < totalSamples; i++) {
      const t = i / sampleRate;
      const center = sound.duration / 2;
      const env = Math.exp(-Math.pow((t - center) * 6, 2));
      const noise = (Math.random() * 2 - 1);
      const sweepFreq = 300 + 1200 * Math.sin((t / sound.duration) * Math.PI);
      const sample = noise * env * 0.6 * Math.sin(2 * Math.PI * sweepFreq * t);
      left[i] = sample * (t / sound.duration);
      right[i] = sample * (1 - t / sound.duration);
    }
  } else {
    // Shutter or glitch fallback
    for (let i = 0; i < totalSamples; i++) {
      const t = i / sampleRate;
      const env = Math.exp(-t * 15);
      const sample = (Math.random() * 2 - 1) * env * 0.7;
      left[i] = sample;
      right[i] = sample;
    }
  }

  // Convert AudioBuffer to WAV Blob URL
  const wavBlob = audioBufferToWavBlob(buffer);
  return URL.createObjectURL(wavBlob);
}

function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numOfChan = buffer.numberOfChannels;
  const length = buffer.length * numOfChan * 2 + 44;
  const outBuffer = new ArrayBuffer(length);
  const view = new DataView(outBuffer);
  const channels: Float32Array[] = [];
  let sampleRate = buffer.sampleRate;
  let offset = 0;
  let pos = 0;

  function setUint16(data: number) {
    view.setUint16(pos, data, true);
    pos += 2;
  }
  function setUint32(data: number) {
    view.setUint32(pos, data, true);
    pos += 4;
  }

  // RIFF identifier
  setUint32(0x46464952); // "RIFF"
  setUint32(length - 8); // file length - 8
  setUint32(0x45564157); // "WAVE"
  setUint32(0x20746d66); // "fmt " chunk
  setUint32(16); // length = 16
  setUint16(1); // PCM (uncompressed)
  setUint16(numOfChan);
  setUint32(sampleRate);
  setUint32(sampleRate * 2 * numOfChan); // byte rate
  setUint16(numOfChan * 2); // block align
  setUint16(16); // 16-bit
  setUint32(0x61746164); // "data" chunk
  setUint32(length - pos - 4); // chunk length

  for (let i = 0; i < buffer.numberOfChannels; i++) {
    channels.push(buffer.getChannelData(i));
  }

  while (pos < length) {
    for (let i = 0; i < numOfChan; i++) {
      let sample = Math.max(-1, Math.min(1, channels[i][offset]));
      sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
      view.setInt16(pos, sample, true);
      pos += 2;
    }
    offset++;
  }

  return new Blob([outBuffer], { type: 'audio/wav' });
}
