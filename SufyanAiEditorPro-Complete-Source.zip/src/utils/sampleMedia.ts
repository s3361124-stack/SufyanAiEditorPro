import { VideoClip } from '../types/editor';

/**
 * Creates high-quality demo media clips and sample photos so beginners on mobile
 * can start editing immediately without needing to hunt for sample files.
 */

// Helper to generate animated canvas video clip for reliable offline playback
export function createProceduralVideoClip(
  name: string,
  theme: 'cinematic' | 'cyberpunk' | 'vlog' | 'sunset' | 'gaming',
  durationSeconds: number = 5
): Promise<VideoClip> {
  return new Promise((resolve) => {
    const width = 1280;
    const height = 720;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d')!;

    const stream = canvas.captureStream(30);
    const mediaRecorder = new MediaRecorder(stream, {
      mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9')
        ? 'video/webm;codecs=vp9'
        : 'video/webm'
    });

    const chunks: Blob[] = [];
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      const videoUrl = URL.createObjectURL(blob);
      
      // Capture thumbnail
      const thumbUrl = canvas.toDataURL('image/jpeg', 0.8);

      resolve({
        id: 'clip_' + Math.random().toString(36).substring(2, 9),
        name,
        type: 'video',
        sourceUrl: videoUrl,
        thumbnailUrl: thumbUrl,
        duration: durationSeconds,
        startTime: 0,
        endTime: durationSeconds,
        playbackRate: 1.0,
        volume: 1.0,
        muted: false,
        rotation: 0,
        flipHorizontal: false,
        flipVertical: false,
        fitMode: 'cover'
      });
    };

    mediaRecorder.start();

    const fps = 30;
    const totalFrames = fps * durationSeconds;
    let currentFrame = 0;

    const interval = setInterval(() => {
      const progress = currentFrame / totalFrames;
      const t = progress * durationSeconds;

      // Draw background theme
      if (theme === 'cinematic') {
        const grad = ctx.createLinearGradient(0, 0, width, height);
        grad.addColorStop(0, '#0f172a');
        grad.addColorStop(0.5, '#1e293b');
        grad.addColorStop(1, '#090d16');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        // Sun / Spotlight
        const sunX = width * 0.5 + Math.sin(t * 0.8) * 80;
        const sunY = height * 0.35 + Math.cos(t * 0.5) * 40;
        const radial = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, 300);
        radial.addColorStop(0, 'rgba(245, 158, 11, 0.45)');
        radial.addColorStop(1, 'rgba(245, 158, 11, 0)');
        ctx.fillStyle = radial;
        ctx.beginPath();
        ctx.arc(sunX, sunY, 300, 0, Math.PI * 2);
        ctx.fill();

        // Cinematic Mountain silhouette
        ctx.fillStyle = '#060a10';
        ctx.beginPath();
        ctx.moveTo(0, height);
        ctx.lineTo(width * 0.2, height * 0.45 + Math.sin(t) * 5);
        ctx.lineTo(width * 0.45, height * 0.65);
        ctx.lineTo(width * 0.7, height * 0.38);
        ctx.lineTo(width, height * 0.7);
        ctx.lineTo(width, height);
        ctx.closePath();
        ctx.fill();

        // Overlay Title text
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.font = 'bold 36px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('CINEMATIC 4K SEQUENCE', width / 2, height * 0.88);
      } else if (theme === 'cyberpunk') {
        // Neon grid & retro sun
        ctx.fillStyle = '#090514';
        ctx.fillRect(0, 0, width, height);

        // Neon Horizon Sun
        const sunY = height * 0.45;
        const sunGrad = ctx.createLinearGradient(0, sunY - 120, 0, sunY + 120);
        sunGrad.addColorStop(0, '#f43f5e');
        sunGrad.addColorStop(1, '#ec4899');
        ctx.fillStyle = sunGrad;
        ctx.beginPath();
        ctx.arc(width / 2, sunY, 120, 0, Math.PI * 2);
        ctx.fill();

        // Cyber Grid Floor
        ctx.strokeStyle = '#06b6d4';
        ctx.lineWidth = 2;
        const horizon = height * 0.5;
        for (let x = -width; x < width * 2; x += 100) {
          ctx.beginPath();
          ctx.moveTo(width / 2 + (x - width / 2) * 0.1, horizon);
          ctx.lineTo(x, height);
          ctx.stroke();
        }
        for (let y = 0; y < 10; y++) {
          const py = horizon + Math.pow(y / 10, 2) * (height - horizon);
          ctx.beginPath();
          ctx.moveTo(0, py);
          ctx.lineTo(width, py);
          ctx.stroke();
        }

        ctx.fillStyle = '#38bdf8';
        ctx.font = 'bold 38px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('CYBERPUNK NEON DRIVE', width / 2, 80);
      } else if (theme === 'vlog') {
        // Warm outdoor vlog style
        const grad = ctx.createLinearGradient(0, 0, 0, height);
        grad.addColorStop(0, '#38bdf8');
        grad.addColorStop(0.6, '#fef08a');
        grad.addColorStop(1, '#86efac');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);

        // Animated particles / bokeh
        for (let i = 0; i < 20; i++) {
          const bx = (width * 0.1 * i + t * 40) % width;
          const by = (height * 0.15 * i + Math.sin(t + i) * 50) % height;
          ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
          ctx.beginPath();
          ctx.arc(bx, by, 12 + (i % 8), 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.fillStyle = '#0f172a';
        ctx.font = 'bold 34px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('SUMMER VLOG MOMENTS', width / 2, height * 0.5);
      } else {
        // Gaming Montage
        ctx.fillStyle = '#020617';
        ctx.fillRect(0, 0, width, height);

        // Pulsing audio visualizer bars
        const bars = 24;
        const barWidth = width / (bars * 1.5);
        for (let b = 0; b < bars; b++) {
          const h = (Math.sin(t * 8 + b * 0.5) * 0.5 + 0.5) * (height * 0.5) + 30;
          const bx = width * 0.15 + b * (barWidth + 8);
          const barGrad = ctx.createLinearGradient(0, height - h, 0, height);
          barGrad.addColorStop(0, '#a855f7');
          barGrad.addColorStop(1, '#3b82f6');
          ctx.fillStyle = barGrad;
          ctx.fillRect(bx, height * 0.7 - h, barWidth, h);
        }

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 36px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('GAMING MONTAGE HIGHLIGHTS', width / 2, 100);
      }

      // Frame time stamp overlay for pro look
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fillRect(20, height - 60, 220, 36);
      ctx.fillStyle = '#10b981';
      ctx.font = '16px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`REC [●] 00:0${Math.floor(t)}:${Math.floor((t % 1) * 30).toString().padStart(2, '0')}`, 32, height - 36);

      currentFrame++;
      if (currentFrame >= totalFrames) {
        clearInterval(interval);
        mediaRecorder.stop();
      }
    }, 1000 / fps);
  });
}

// Sample photos for photo editor
export const SAMPLE_PHOTOS = [
  {
    id: 'sufyan-logo',
    name: 'SUFYAN AI EDITOR PRO Official Mascot Logo',
    url: '/logo.png',
    type: 'portrait'
  },
  {
    id: 'sample-portrait-1',
    name: 'Cinematic Portrait (Model in City)',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1000&q=80',
    type: 'portrait'
  },
  {
    id: 'sample-portrait-2',
    name: 'Street Fashion Portrait',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1000&q=80',
    type: 'portrait'
  },
  {
    id: 'sample-landscape-1',
    name: 'Dramatic Golden Hour Mountain',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1000&q=80',
    type: 'landscape'
  },
  {
    id: 'sample-cyber-1',
    name: 'Cyberpunk Tokyo Night Rain',
    url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1000&q=80',
    type: 'cyber'
  }
];

export const SAMPLE_VIDEOS = [
  {
    id: 'sample_cinematic',
    name: 'Cinematic Drone Flyover',
    category: 'Cinematic',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    duration: 15
  },
  {
    id: 'sample_gaming',
    name: 'Cyber Gaming Rush',
    category: 'Gaming',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    duration: 15
  },
  {
    id: 'sample_vlog',
    name: 'Urban Vlog B-Roll',
    category: 'Vlog',
    url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    duration: 15
  },
  {
    id: 'sample_mascot',
    name: 'SUFYAN Mascot Brand Intro',
    category: 'Brand',
    url: '/logo.png',
    duration: 5
  }
];

export const SAMPLE_AUDIO = [
  {
    id: 'audio_cinematic_1',
    name: 'Epic Cyberpunk Beat',
    url: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=cyberpunk-2099-10701.mp3',
    duration: 30
  },
  {
    id: 'audio_gaming_1',
    name: 'Esports Victory Anthem',
    url: 'https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3?filename=electronic-future-beats-117997.mp3',
    duration: 25
  },
  {
    id: 'audio_ambient_1',
    name: 'Lo-Fi Chill Vlog Beat',
    url: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a73467.mp3?filename=lofi-study-112191.mp3',
    duration: 35
  }
];

