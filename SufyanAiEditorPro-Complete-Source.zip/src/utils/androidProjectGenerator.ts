import JSZip from 'jszip';

export interface AndroidFile {
  path: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidFile[] = [
  {
    path: 'settings.gradle.kts',
    content: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "SufyanAiEditorPro"
include(":app")
`
  },
  {
    path: 'build.gradle.kts',
    content: `// Top-level build file
plugins {
    id("com.android.application") version "8.3.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
`
  },
  {
    path: 'gradle/libs.versions.toml',
    content: `[versions]
agp = "8.3.2"
kotlin = "1.9.22"
coreKtx = "1.15.0"
lifecycleRuntime = "2.8.7"
activityCompose = "1.9.3"
composeBom = "2024.10.01"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-lifecycle-runtime-ktx = { group = "androidx.lifecycle", name = "lifecycle-runtime-ktx", version.ref = "lifecycleRuntime" }
androidx-activity-compose = { group = "androidx.activity", name = "activity-compose", version.ref = "activityCompose" }
androidx-compose-bom = { group = "androidx.compose", name = "compose-bom", version.ref = "composeBom" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
`
  },

  {
    path: 'gradle/wrapper/gradle-wrapper.properties',
    content: `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
  },
  {
    path: 'app/build.gradle.kts',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sufyan.aieditorpro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sufyan.aieditorpro"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Core Android & Jetpack Compose
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.3")

    // AndroidX Media3 (ExoPlayer & Transformer for hardware-accelerated video export)
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("androidx.media3:media3-transformer:1.4.1")
    implementation("androidx.media3:media3-effect:1.4.1")
    implementation("androidx.media3:media3-common:1.4.1")

    // Image Loading
    implementation("io.coil-kt:coil-compose:2.7.0")

    // Accompanist Permissions
    implementation("com.google.accompanist:accompanist-permissions:0.36.0")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Modern Granular Android Permissions -->
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="SUFYAN AI EDITOR PRO"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.SufyanAiEditorPro">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
            android:theme="@style/Theme.SufyanAiEditorPro">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`
  },
  {
    path: 'app/src/main/res/values/colors.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="black">#FF000000</color>
    <color name="white">#FFFFFFFF</color>
    <color name="dark_background">#FF0B0C10</color>
    <color name="dark_surface">#FF14161F</color>
    <color name="silver_platinum">#FFE5E7EB</color>
    <color name="accent_cyan">#FF38BDF8</color>
    <color name="accent_purple">#FFA855F7</color>
    <color name="electric_blue">#FF00F0FF</color>
</resources>
`
  },
  {
    path: 'app/src/main/res/values/strings.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">SUFYAN AI EDITOR PRO</string>
</resources>
`
  },
  {
    path: 'app/src/main/res/values/styles.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.SufyanAiEditorPro" parent="android:Theme.Material.NoActionBar">
        <item name="android:statusBarColor">#0B0C10</item>
        <item name="android:navigationBarColor">#0B0C10</item>
    </style>
</resources>
`
  },
  {
    path: 'app/src/main/res/drawable/ic_launcher_background.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#0D041A"
        android:pathData="M0,0h108v108h-108z"/>
    <path
        android:fillColor="#A855F7"
        android:fillAlpha="0.35"
        android:pathData="M54,54m-44,0a44,44 0 1,1 88,0a44,44 0 1,1 -88,0"/>
    <path
        android:fillColor="#38BDF8"
        android:fillAlpha="0.25"
        android:pathData="M54,54m-34,0a34,34 0 1,1 68,0a34,34 0 1,1 -68,0"/>
</vector>
`
  },
  {
    path: 'app/src/main/res/drawable/ic_launcher_foreground.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <!-- Outer Neon Glow Ring -->
    <path
        android:strokeColor="#A855F7"
        android:strokeWidth="3.5"
        android:fillColor="#00000000"
        android:pathData="M54,54m-38,0a38,38 0 1,1 76,0a38,38 0 1,1 -76,0"/>
    <path
        android:strokeColor="#38BDF8"
        android:strokeWidth="1.5"
        android:fillColor="#00000000"
        android:pathData="M54,54m-34,0a34,34 0 1,1 68,0a34,34 0 1,1 -68,0"/>
    <!-- Stylized Avatar Silhouette -->
    <path
        android:fillColor="#38BDF8"
        android:pathData="M38,38 C38,28 70,28 70,38 Z"/>
    <path
        android:fillColor="#E5E7EB"
        android:pathData="M40,40 Q54,64 68,40 Q54,78 40,40 Z"/>
    <path
        android:fillColor="#111827"
        android:pathData="M48,56 L60,56 L54,68 Z"/>
</vector>
`
  },
  {
    path: 'app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/dark_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
`
  },
  {
    path: 'app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/dark_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
`
  },
  {
    path: 'app/src/main/java/com/sufyan/aieditorpro/MainActivity.kt',
    content: `package com.sufyan.aieditorpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.sufyan.aieditorpro.R
import com.sufyan.aieditorpro.ui.screens.VideoEditorScreen
import com.sufyan.aieditorpro.ui.screens.PhotoEditorScreen
import com.sufyan.aieditorpro.ui.theme.*

import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SufyanAiEditorTheme {
                val navController = rememberNavController()
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MaterialTheme.colorScheme.background
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "splash",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("splash") {
                            SplashScreen(onTimeout = {
                                navController.navigate("video_editor") {
                                    popUpTo("splash") { inclusive = true }
                                }
                            })
                        }
                        composable("video_editor") {
                            VideoEditorScreen(
                                onNavigateToPhoto = { navController.navigate("photo_editor") }
                            )
                        }
                        composable("photo_editor") {
                            PhotoEditorScreen(
                                onNavigateToVideo = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1800)
        onTimeout()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Mascot Avatar with electric neon aura
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .border(
                        3.dp,
                        Brush.sweepGradient(listOf(AccentPurple, AccentCyan, Color(0xFF00F0FF), AccentPurple)),
                        RoundedCornerShape(26.dp)
                    )
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "SUFYAN Mascot Logo",
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "SUFYAN AI EDITOR PRO",
                color = SilverPlatinum,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "CINEMA • PHOTO AI • PRO MOBILE",
                color = AccentCyan,
                fontSize = 11.sp,
                letterSpacing = 2.sp
            )
        }
    }
}
`
  },
  {
    path: 'app/src/main/java/com/sufyan/aieditorpro/ui/theme/Color.kt',
    content: `package com.sufyan.aieditorpro.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Black & Silver Palette
val DarkBackground = Color(0xFF0B0C10)
val DarkSurface = Color(0xFF14161F)
val DarkSurfaceVariant = Color(0xFF1F222E)

val SilverPlatinum = Color(0xFFE5E7EB)
val SilverLight = Color(0xFFF3F4F6)
val SilverMuted = Color(0xFF9CA3AF)
val SilverBorder = Color(0xFF374151)

val AccentCyan = Color(0xFF38BDF8)
val AccentPurple = Color(0xFF818CF8)
val ActionRed = Color(0xFFEF4444)
`
  },
  {
    path: 'app/src/main/java/com/sufyan/aieditorpro/ui/theme/Theme.kt',
    content: `package com.sufyan.aieditorpro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = SilverPlatinum,
    onPrimary = DarkBackground,
    primaryContainer = DarkSurfaceVariant,
    secondary = AccentCyan,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceVariant,
    onBackground = SilverLight,
    onSurface = SilverLight,
    outline = SilverBorder
)

@Composable
fun SufyanAiEditorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
`
  },
  {
    path: 'app/src/main/java/com/sufyan/aieditorpro/media/MediaTransformerHelper.kt',
    content: `package com.sufyan.aieditorpro.media

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.effect.Contrast
import androidx.media3.effect.RgbFilter
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Hardware-accelerated video export using AndroidX Media3 Transformer
 * Encodes directly on device GPU without watermark.
 */
class MediaTransformerHelper(private val context: Context) {

    suspend fun exportVideo(
        inputUris: List<Uri>,
        outputFile: File,
        contrastLevel: Float = 1.0f,
        onProgress: (Int) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val editedMediaItems = inputUris.map { uri ->
                val mediaItem = MediaItem.fromUri(uri)
                val effects = Effects(
                    /* audioProcessors = */ emptyList(),
                    /* videoEffects = */ listOf(
                        Contrast(contrastLevel)
                    )
                )
                EditedMediaItem.Builder(mediaItem)
                    .setEffects(effects)
                    .build()
            }

            val sequence = EditedMediaItemSequence(editedMediaItems)
            val composition = Composition.Builder(listOf(sequence)).build()

            val progressHolder = ProgressHolder()
            var exportSuccess = false
            var exportError: Exception? = null

            val transformer = Transformer.Builder(context)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        exportSuccess = true
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        exportError = exportException
                    }
                })
                .build()

            transformer.start(composition, outputFile.absolutePath)

            // Monitor progress loop
            while (!exportSuccess && exportError == null) {
                val state = transformer.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(progressHolder.progress)
                }
                kotlinx.coroutines.delay(100)
            }

            exportError?.let { return@withContext Result.failure(it) }
            Result.success(outputFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
`
  },
  {
    path: 'app/src/main/java/com/sufyan/aieditorpro/ui/screens/VideoEditorScreen.kt',
    content: `package com.sufyan.aieditorpro.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sufyan.aieditorpro.R
import com.sufyan.aieditorpro.ui.theme.*


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoEditorScreen(onNavigateToPhoto: () -> Unit) {
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentAspectRatio by remember { mutableStateOf("16:9") }
    var selectedLut by remember { mutableStateOf("Original") }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedVideoUri = uri
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Top App Bar with Mascot Logo
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.5.dp, AccentPurple, RoundedCornerShape(8.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.logo),
                            contentDescription = "SUFYAN Logo",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        "SUFYAN AI EDITOR PRO",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = SilverPlatinum
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = DarkSurface
            ),
            actions = {
                IconButton(onClick = onNavigateToPhoto) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = "Photo Studio", tint = AccentCyan)
                }
                IconButton(onClick = { /* Export action */ }) {
                    Icon(Icons.Default.Download, contentDescription = "Export Video", tint = SilverPlatinum)
                }
            }
        )

        // Video Preview Player Viewport
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            if (selectedVideoUri != null) {
                Text("Video Active: \${selectedVideoUri?.lastPathSegment}", color = Color.White)
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.MovieCreation,
                        contentDescription = null,
                        tint = SilverMuted,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Import Video or tap + to begin", color = SilverMuted)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { videoPickerLauncher.launch("video/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Video Clip")
                    }
                }
            }
        }

        // Multi-clip Timeline Scrubbing Bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp),
            color = DarkSurface
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TIMELINE: 00:00.00", color = SilverMuted, fontSize = 12.sp)
                    Row {
                        IconButton(onClick = { isPlaying = !isPlaying }) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = SilverPlatinum
                            )
                        }
                        IconButton(onClick = { /* Split clip */ }) {
                            Icon(Icons.Default.ContentCut, contentDescription = "Split", tint = SilverPlatinum)
                        }
                        IconButton(onClick = { /* Delete clip */ }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ActionRed)
                        }
                    }
                }

                // Clip track preview
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .background(DarkSurfaceVariant, RoundedCornerShape(8.dp))
                        .border(1.dp, SilverBorder, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Primary Video Track (Trim, Split & Reorder)", color = SilverMuted, fontSize = 12.sp)
                }
            }
        }

        // Precision Video Trimmer Component
        VideoTrimmerView(
            startSeconds = 0.0f,
            endSeconds = 10.0f,
            maxDuration = 15.0f,
            onTrimChanged = { start, end -> /* update clip start & end points */ }
        )

        // Bottom Tool Dock
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkBackground)
                .padding(vertical = 12.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            ToolButton(icon = Icons.Default.ContentCut, label = "Trim [ ]")
            ToolButton(icon = Icons.Default.ColorLens, label = "Color / LUT")
            ToolButton(icon = Icons.Default.MusicNote, label = "Audio / SFX")
            ToolButton(icon = Icons.Default.TextFields, label = "Titles / Text")
            ToolButton(icon = Icons.Default.Speed, label = "Speed (0.25x)")
        }
    }
}

@Composable
fun VideoTrimmerView(
    startSeconds: Float,
    endSeconds: Float,
    maxDuration: Float,
    onTrimChanged: (Float, Float) -> Unit
) {
    var start by remember { mutableFloatStateOf(startSeconds) }
    var end by remember { mutableFloatStateOf(endSeconds) }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        color = DarkSurface,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SilverBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("TRIM IN: \${String.format(\"%.2f\", start)}s", color = AccentCyan, fontSize = 11.sp)
                Text("DURATION: \${String.format(\"%.2f\", end - start)}s", color = SilverPlatinum, fontSize = 11.sp)
                Text("TRIM OUT: \${String.format(\"%.2f\", end)}s", color = AccentCyan, fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Range Trim Slider Simulator
            RangeSlider(
                value = start..end,
                onValueChange = { range ->
                    start = range.start
                    end = range.endInclusive
                    onTrimChanged(start, end)
                },
                valueRange = 0f..maxDuration,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFFF59E0B),
                    activeTrackColor = Color(0xFFF59E0B),
                    inactiveTrackColor = Color.DarkGray
                )
            )
        }
    }
}

@Composable
fun ToolButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = label, tint = SilverPlatinum, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, color = SilverMuted, fontSize = 10.sp)
    }
}
`
  },
  {
    path: 'app/src/main/java/com/sufyan/aieditorpro/ui/screens/PhotoEditorScreen.kt',
    content: `package com.sufyan.aieditorpro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sufyan.aieditorpro.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoEditorScreen(onNavigateToVideo: () -> Unit) {
    var removeBgActive by remember { mutableStateOf(false) }
    var bokehBlurValue by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        TopAppBar(
            title = { Text("PHOTO AI STUDIO", fontSize = 18.sp, color = SilverPlatinum) },
            navigationIcon = {
                IconButton(onClick = onNavigateToVideo) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = SilverPlatinum)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface),
            actions = {
                IconButton(onClick = { /* Save photo */ }) {
                    Icon(Icons.Default.Save, contentDescription = "Save Photo", tint = AccentCyan)
                }
            }
        )

        // Photo Canvas Viewport
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(DarkBackground),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text("AI Background Cutout & Portrait Bokeh Studio", color = SilverPlatinum)
                Text("On-device offline photo processing", color = SilverMuted, fontSize = 12.sp)
            }
        }

        // Photo Tools Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurface
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                FilterChip(
                    selected = removeBgActive,
                    onClick = { removeBgActive = !removeBgActive },
                    label = { Text("AI Cutout") }
                )
                FilterChip(
                    selected = bokehBlurValue > 0,
                    onClick = { bokehBlurValue = if (bokehBlurValue > 0) 0f else 50f },
                    label = { Text("Portrait Bokeh") }
                )
                FilterChip(
                    selected = false,
                    onClick = { /* Auto enhance */ },
                    label = { Text("1-Tap Enhance") }
                )
            }
        }
    }
}
`
  },
  {
    path: '.github/workflows/build-apk.yml',
    content: `name: Build Android APK (Free Mobile Cloud Build)

on:
  push:
    branches: [ "main" ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - name: Checkout Source Code
      uses: actions/checkout@v4

    - name: Set up JDK 17
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'temurin'
        cache: gradle

    - name: Setup Gradle
      uses: gradle/actions/setup-gradle@v3

    - name: Grant execute permission for gradlew
      run: chmod +x gradlew || true

    - name: Build Debug APK
      run: |
        if [ -f "./gradlew" ]; then
          ./gradlew assembleDebug --no-daemon || gradle assembleDebug --no-daemon
        else
          gradle assembleDebug --no-daemon
        fi

    - name: Upload APK Installer Artifact
      uses: actions/upload-artifact@v4
      with:
        name: SUFYAN-AI-EDITOR-PRO-v1.0.apk
        path: app/build/outputs/apk/debug/app-debug.apk
`
  },
  {
    path: 'gradlew',
    content: `#!/bin/sh
PRG="$0"
while [ -h "$PRG" ] ; do
    ls=\`ls -ld "$PRG"\`
    link=\`expr "$ls" : '.*-> \\(.*\\)$'\`
    if expr "$link" : '/.*' > /dev/null; then
        PRG="$link"
    else
        PRG=\`dirname "$PRG"\`"/$link"
    fi
done
SAVED="\`pwd\`"
cd "\`dirname \\"$PRG\\"\`/" >/dev/null
APP_HOME="\`pwd -P\`"
cd "$SAVED" >/dev/null

APP_NAME="Gradle"
APP_BASE_NAME=\`basename "$0"\`
DEFAULT_JVM_OPTS='"-Xmx64m" "-Xms64m"'

CLASSPATH=$APP_HOME/gradle/wrapper/gradle-wrapper.jar

if [ -n "$JAVA_HOME" ] ; then
    JAVACMD="$JAVA_HOME/bin/java"
else
    JAVACMD="java"
fi

if [ -f "$CLASSPATH" ]; then
    exec "$JAVACMD" $DEFAULT_JVM_OPTS $JAVA_OPTS $GRADLE_OPTS "-Dorg.gradle.appname=$APP_BASE_NAME" -classpath "$CLASSPATH" org.gradle.wrapper.GradleWrapperMain "$@"
else
    gradle "$@"
fi
`
  },
  {
    path: 'README_MOBILE_BUILD_GUIDE.md',
    content: `# SUFYAN AI EDITOR PRO - Android Mobile-Only Build Guide

Dear Creator,
If you only have an Android mobile phone and no computer, here are the 3 realistic, 100% free ways to run and compile this application:

---

### Option 1: Instant Native-Like PWA (Easiest - 10 Seconds)
1. Open this app in Google Chrome on your Android phone.
2. Tap the Chrome three-dot menu (⋮) at top right.
3. Tap **"Add to Home screen"** or **"Install app"**.
4. The app icon will appear directly on your Android phone launcher!
5. It runs offline, in full-screen, without any browser bars, with full camera, gallery, and file support!

---

### Option 2: 100% Free Cloud APK Build via GitHub Actions (Real .APK File)
You can compile a genuine Android \`.apk\` installer directly from your phone for free:
1. Tap the **"Download Android Project (.ZIP)"** button in the Android APK Hub tab.
2. Open [github.com](https://github.com) on your mobile browser (create a free account if you don't have one).
3. Create a new repository named \`SufyanAiEditorPro\`.
4. Upload the project files or zip to the repository.
5. GitHub will automatically detect the included \`.github/workflows/build-apk.yml\` file.
6. Under the **"Actions"** tab on GitHub, click **Run workflow**.
7. In approximately 2 minutes, GitHub's free cloud runners will compile the APK.
8. Download \`SUFYAN-AI-EDITOR-PRO-v1.0.apk\` directly to your phone and install it!

---

### Option 3: Compile On Phone Using Termux
If you want to compile directly on your phone's processor:
1. Install **Termux** from F-Droid.
2. Run these commands:
   \`\`\`bash
   pkg update && pkg install openjdk-17 gradle git
   # Unzip the downloaded project
   cd SufyanAiEditorPro
   gradle assembleDebug
   \`\`\`
3. Your compiled APK will be at \`app/build/outputs/apk/debug/app-debug.apk\`!
`
  }
];

export async function generateAndroidProjectZip(): Promise<Blob> {
  const zip = new JSZip();
  ANDROID_PROJECT_FILES.forEach(file => {
    zip.file(file.path, file.content);
  });

  // Bundle the real user logo into all Android icon sizes, adaptive foregrounds, drawables and assets
  const iconTargets = [
    // Standard Mipmap Launcher Icons
    { url: '/android_res/mipmap-mdpi/ic_launcher.png', path: 'app/src/main/res/mipmap-mdpi/ic_launcher.png' },
    { url: '/android_res/mipmap-hdpi/ic_launcher.png', path: 'app/src/main/res/mipmap-hdpi/ic_launcher.png' },
    { url: '/android_res/mipmap-xhdpi/ic_launcher.png', path: 'app/src/main/res/mipmap-xhdpi/ic_launcher.png' },
    { url: '/android_res/mipmap-xxhdpi/ic_launcher.png', path: 'app/src/main/res/mipmap-xxhdpi/ic_launcher.png' },
    { url: '/android_res/mipmap-xxxhdpi/ic_launcher.png', path: 'app/src/main/res/mipmap-xxxhdpi/ic_launcher.png' },

    // Circular Mipmap Launcher Icons
    { url: '/android_res/mipmap-mdpi/ic_launcher_round.png', path: 'app/src/main/res/mipmap-mdpi/ic_launcher_round.png' },
    { url: '/android_res/mipmap-hdpi/ic_launcher_round.png', path: 'app/src/main/res/mipmap-hdpi/ic_launcher_round.png' },
    { url: '/android_res/mipmap-xhdpi/ic_launcher_round.png', path: 'app/src/main/res/mipmap-xhdpi/ic_launcher_round.png' },
    { url: '/android_res/mipmap-xxhdpi/ic_launcher_round.png', path: 'app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png' },
    { url: '/android_res/mipmap-xxxhdpi/ic_launcher_round.png', path: 'app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png' },

    // Adaptive Foreground Icons
    { url: '/android_res/mipmap-mdpi/ic_launcher_foreground.png', path: 'app/src/main/res/mipmap-mdpi/ic_launcher_foreground.png' },
    { url: '/android_res/mipmap-hdpi/ic_launcher_foreground.png', path: 'app/src/main/res/mipmap-hdpi/ic_launcher_foreground.png' },
    { url: '/android_res/mipmap-xhdpi/ic_launcher_foreground.png', path: 'app/src/main/res/mipmap-xhdpi/ic_launcher_foreground.png' },
    { url: '/android_res/mipmap-xxhdpi/ic_launcher_foreground.png', path: 'app/src/main/res/mipmap-xxhdpi/ic_launcher_foreground.png' },
    { url: '/android_res/mipmap-xxxhdpi/ic_launcher_foreground.png', path: 'app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.png' },

    // Drawable Resources
    { url: '/android_res/drawable/logo.png', path: 'app/src/main/res/drawable/logo.png' },
    { url: '/android_res/drawable/splash_logo.png', path: 'app/src/main/res/drawable/splash_logo.png' },
    { url: '/android_res/drawable-nodpi/logo.png', path: 'app/src/main/res/drawable-nodpi/logo.png' },

    // Raw Assets
    { url: '/logo.png', path: 'app/src/main/assets/logo.png' },
    { url: '/logo.png', path: 'app/src/main/assets/sufyan_logo.png' }
  ];

  await Promise.all(
    iconTargets.map(async (target) => {
      try {
        let res = await fetch(target.url);
        if (!res.ok) {
          // Fallback to primary logo
          res = await fetch('/logo.png');
        }
        if (res.ok) {
          const blob = await res.blob();
          zip.file(target.path, blob);
        }
      } catch (e) {
        console.warn(`Could not load icon resource for ${target.path}`, e);
      }
    })
  );

  return await zip.generateAsync({ type: 'blob' });
}

