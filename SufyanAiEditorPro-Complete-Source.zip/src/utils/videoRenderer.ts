import { AspectRatio, ColorGradeSettings, LUTPreset, TextOverlay, OverlayMedia, VideoClip, Transition } from '../types/editor';

export function getAspectRatioDimensions(aspectRatio: AspectRatio, baseWidth: number = 1920): { width: number; height: number } {
  // Ensure even dimensions for video encoding
  const makeEven = (n: number) => (n % 2 === 0 ? n : n + 1);

  switch (aspectRatio) {
    case '16:9':
      return { width: makeEven(baseWidth), height: makeEven(Math.round(baseWidth * (9 / 16))) };
    case '9:16':
      return { width: makeEven(Math.round(baseWidth * (9 / 16))), height: makeEven(baseWidth) };
    case '1:1': {
      const squareDim = makeEven(Math.round(baseWidth * (9 / 16)));
      return { width: squareDim, height: squareDim };
    }
    case '4:5': {
      const h = makeEven(baseWidth);
      return { width: makeEven(Math.round(h * (4 / 5))), height: h };
    }
    case '21:9':
      return { width: makeEven(baseWidth), height: makeEven(Math.round(baseWidth * (9 / 21))) };
    default:
      return { width: makeEven(baseWidth), height: makeEven(Math.round(baseWidth * (9 / 16))) };
  }
}

/**
 * Returns CSS filter string for standard adjustments
 */
export function buildCssFilter(colorGrade: ColorGradeSettings): string {
  const b = 100 + colorGrade.brightness; // percentage
  const c = 100 + colorGrade.contrast;
  const s = 100 + colorGrade.saturation;

  let filter = `brightness(${b}%) contrast(${c}%) saturate(${s}%)`;

  // Specific LUT adjustments via CSS filters
  switch (colorGrade.preset) {
    case 'teal-orange':
      // Cinematic contrast + slight hue shift
      filter += ` contrast(115%) saturate(125%) hue-rotate(-10deg)`;
      break;
    case 'film-noir':
      filter += ` grayscale(100%) contrast(140%) brightness(95%)`;
      break;
    case 'vintage-35mm':
      filter += ` sepia(35%) contrast(110%) brightness(105%) saturate(85%)`;
      break;
    case 'cyberpunk':
      filter += ` contrast(130%) saturate(160%) hue-rotate(190deg)`;
      break;
    case 'golden-hour':
      filter += ` sepia(20%) saturate(135%) brightness(108%)`;
      break;
    case 'emerald':
      filter += ` hue-rotate(60deg) contrast(110%) saturate(110%)`;
      break;
    case 'bleach-bypass':
      filter += ` contrast(150%) saturate(40%) brightness(95%)`;
      break;
    case 'kodachrome':
      filter += ` contrast(120%) saturate(140%)`;
      break;
    default:
      break;
  }

  return filter;
}

/**
 * Render color temperature tint, vignette, film grain, and letterbox bars onto 2D canvas context
 */
export function applyCanvasCinematicEffects(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  colorGrade: ColorGradeSettings
) {
  // 1. Color Temperature Tint (Warm Orange vs Cool Teal/Cyan)
  if (colorGrade.temperature !== 0) {
    ctx.save();
    if (colorGrade.temperature > 0) {
      // Warm Amber / Golden
      ctx.fillStyle = `rgba(255, 170, 50, ${Math.abs(colorGrade.temperature) * 0.0025})`;
      ctx.globalCompositeOperation = 'color-burn';
    } else {
      // Cool Cyan / Deep Blue
      ctx.fillStyle = `rgba(40, 160, 255, ${Math.abs(colorGrade.temperature) * 0.0025})`;
      ctx.globalCompositeOperation = 'soft-light';
    }
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  // 2. Cinematic Vignette (Dramatic darkened corners)
  if (colorGrade.vignette > 0) {
    ctx.save();
    const radius = Math.max(width, height) * 0.75;
    const vignetteGrad = ctx.createRadialGradient(
      width / 2,
      height / 2,
      radius * (1 - (colorGrade.vignette / 120)),
      width / 2,
      height / 2,
      radius
    );
    vignetteGrad.addColorStop(0, 'rgba(0,0,0,0)');
    vignetteGrad.addColorStop(1, `rgba(0,0,0,${Math.min(0.95, colorGrade.vignette / 100)})`);
    ctx.fillStyle = vignetteGrad;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  // 3. Film Grain
  if (colorGrade.filmGrain > 0) {
    ctx.save();
    const grainAlpha = (colorGrade.filmGrain / 100) * 0.15;
    ctx.fillStyle = 'rgba(255, 255, 255, 1)';
    // Fast procedural grain dots
    const grainCount = Math.floor((width * height) / 3000) * (colorGrade.filmGrain / 50);
    for (let i = 0; i < grainCount; i++) {
      const gx = Math.random() * width;
      const gy = Math.random() * height;
      const intensity = Math.random() * grainAlpha;
      ctx.fillStyle = Math.random() > 0.5 ? `rgba(255,255,255,${intensity})` : `rgba(0,0,0,${intensity})`;
      ctx.fillRect(gx, gy, 2, 2);
    }
    ctx.restore();
  }

  // 4. Cinematic Letterbox Bars (Anamorphic 2.39:1 Hollywood look)
  if (colorGrade.letterbox) {
    ctx.save();
    const barHeight = height * ((colorGrade.letterboxHeight || 12) / 100);
    ctx.fillStyle = '#000000';
    // Top bar
    ctx.fillRect(0, 0, width, barHeight);
    // Bottom bar
    ctx.fillRect(0, height - barHeight, width, barHeight);
    ctx.restore();
  }
}

/**
 * Draw a video or image clip into canvas respecting clip transform (rotate, flip, fit mode)
 */
export function drawClipToCanvas(
  ctx: CanvasRenderingContext2D,
  element: HTMLVideoElement | HTMLImageElement,
  clip: VideoClip,
  canvasWidth: number,
  canvasHeight: number,
  opacity: number = 1.0
) {
  if (!element) return;

  // Guard against broken, unloaded, or errored HTMLImageElement
  if (element instanceof HTMLImageElement) {
    if (!element.complete || element.naturalWidth === 0 || element.naturalHeight === 0) {
      // Element is still loading or in broken state: render safe placeholder
      ctx.save();
      ctx.fillStyle = '#111319';
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);
      ctx.fillStyle = '#9ca3af';
      ctx.font = '22px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(clip.name || 'Media Clip', canvasWidth / 2, canvasHeight / 2 - 10);
      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#6b7280';
      ctx.fillText(element.complete ? 'Media source unavailable' : 'Loading media...', canvasWidth / 2, canvasHeight / 2 + 18);
      ctx.restore();
      return;
    }
  }

  // Guard against unready or errored HTMLVideoElement
  if (element instanceof HTMLVideoElement) {
    if (element.readyState < 1 || element.videoWidth === 0 || element.videoHeight === 0) {
      ctx.save();
      ctx.fillStyle = '#111319';
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);
      ctx.fillStyle = '#9ca3af';
      ctx.font = '22px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(clip.name || 'Video Clip', canvasWidth / 2, canvasHeight / 2 - 10);
      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#6b7280';
      ctx.fillText('Loading video frame...', canvasWidth / 2, canvasHeight / 2 + 18);
      ctx.restore();
      return;
    }
  }

  ctx.save();
  ctx.globalAlpha = opacity;

  try {
    // Center coordinate origin for transformations
    ctx.translate(canvasWidth / 2, canvasHeight / 2);

    // Apply rotation
    if (clip.rotation) {
      ctx.rotate((clip.rotation * Math.PI) / 180);
    }

    // Apply flip
    const scaleX = clip.flipHorizontal ? -1 : 1;
    const scaleY = clip.flipVertical ? -1 : 1;
    ctx.scale(scaleX, scaleY);

    const elWidth = (element as HTMLVideoElement).videoWidth || (element as HTMLImageElement).naturalWidth || canvasWidth;
    const elHeight = (element as HTMLVideoElement).videoHeight || (element as HTMLImageElement).naturalHeight || canvasHeight;

    let drawW = canvasWidth;
    let drawH = canvasHeight;

    if (clip.fitMode === 'cover') {
      const scale = Math.max(canvasWidth / Math.max(1, elWidth), canvasHeight / Math.max(1, elHeight));
      drawW = elWidth * scale;
      drawH = elHeight * scale;
    } else if (clip.fitMode === 'contain') {
      const scale = Math.min(canvasWidth / Math.max(1, elWidth), canvasHeight / Math.max(1, elHeight));
      drawW = elWidth * scale;
      drawH = elHeight * scale;
    }

    ctx.drawImage(element, -drawW / 2, -drawH / 2, drawW, drawH);
  } catch (err) {
    // Gracefully handle any browser drawImage error without crashing render loop
  } finally {
    ctx.restore();
  }
}

/**
 * Draw active Text Overlays, Movie Titles, Captions, End Credits
 */
export function drawTextOverlays(
  ctx: CanvasRenderingContext2D,
  textOverlays: TextOverlay[],
  currentTime: number,
  width: number,
  height: number
) {
  textOverlays.forEach((item) => {
    if (currentTime >= item.startTime && currentTime <= item.endTime) {
      ctx.save();

      const timeInOverlay = currentTime - item.startTime;
      const duration = item.endTime - item.startTime;

      // Handle Animations
      let alpha = 1.0;
      let offsetY = 0;
      let scale = 1.0;

      if (item.animation === 'fade') {
        if (timeInOverlay < 0.5) alpha = timeInOverlay / 0.5;
        else if (currentTime > item.endTime - 0.5) alpha = (item.endTime - currentTime) / 0.5;
      } else if (item.animation === 'zoom-in') {
        const p = Math.min(1, timeInOverlay / 0.6);
        scale = 0.8 + 0.2 * p;
        alpha = p;
      } else if (item.animation === 'scroll-up' || item.type === 'credits') {
        // Classic Hollywood credits crawling upward
        const progress = timeInOverlay / duration;
        offsetY = height * (1 - progress * 2);
      }

      ctx.globalAlpha = Math.max(0, Math.min(1, alpha));

      const posX = (item.x / 100) * width;
      const posY = (item.y / 100) * height + offsetY;

      ctx.translate(posX, posY);
      ctx.scale(scale, scale);

      // Measure font size relative to 1080p canvas
      const scaledFontSize = Math.max(16, (item.fontSize / 1080) * height);
      ctx.font = `${item.type === 'title' ? 'bold ' : ''}${scaledFontSize}px ${item.fontFamily || 'Inter, sans-serif'}`;
      ctx.textAlign = item.align || 'center';
      ctx.textBaseline = 'middle';

      const metrics = ctx.measureText(item.text);
      const textWidth = metrics.width;
      const padX = scaledFontSize * 0.4;
      const padY = scaledFontSize * 0.3;

      // Draw background pill if configured
      if (item.backgroundColor && item.backgroundColor !== 'transparent') {
        ctx.fillStyle = item.backgroundColor;
        const bgX = item.align === 'center' ? -textWidth / 2 - padX : item.align === 'right' ? -textWidth - padX : -padX;
        ctx.beginPath();
        ctx.roundRect(bgX, -scaledFontSize / 2 - padY, textWidth + padX * 2, scaledFontSize + padY * 2, 8);
        ctx.fill();
      }

      // Title drop shadow / cinematic glow
      if (item.type === 'title') {
        ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
        ctx.shadowBlur = 12;
        ctx.shadowOffsetX = 3;
        ctx.shadowOffsetY = 3;
      }

      // Border outline if specified
      if (item.borderColor) {
        ctx.strokeStyle = item.borderColor;
        ctx.lineWidth = Math.max(2, scaledFontSize * 0.08);
        ctx.strokeText(item.text, 0, 0);
      }

      // Main Text fill
      ctx.fillStyle = item.color || '#FFFFFF';
      ctx.fillText(item.text, 0, 0);

      ctx.restore();
    }
  });
}

/**
 * Draw Picture-in-Picture (PIP) and overlays
 */
export function drawPipOverlays(
  ctx: CanvasRenderingContext2D,
  pipOverlays: OverlayMedia[],
  currentTime: number,
  canvasWidth: number,
  canvasHeight: number,
  elementsMap: Map<string, HTMLImageElement | HTMLVideoElement>
) {
  pipOverlays.forEach((pip) => {
    if (currentTime >= pip.startTime && currentTime <= pip.endTime) {
      const el = elementsMap.get(pip.id);
      if (!el) return;

      // Check image or video readiness
      if (el instanceof HTMLImageElement && (!el.complete || el.naturalWidth === 0)) return;
      if (el instanceof HTMLVideoElement && (el.readyState < 1 || el.videoWidth === 0)) return;

      ctx.save();
      ctx.globalAlpha = pip.opacity ?? 1.0;

      const px = (pip.x / 100) * canvasWidth;
      const py = (pip.y / 100) * canvasHeight;
      const pw = (pip.width / 100) * canvasWidth;
      const ph = (pip.height / 100) * canvasHeight;

      if (pip.borderRadius > 0) {
        ctx.beginPath();
        ctx.roundRect(px, py, pw, ph, pip.borderRadius);
        ctx.clip();
      }

      try {
        ctx.drawImage(el, px, py, pw, ph);

        // Subtle metallic border for PIP
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.lineWidth = 2;
        ctx.strokeRect(px, py, pw, ph);
      } catch (err) {
        // Safe catch
      } finally {
        ctx.restore();
      }
    }
  });
}
