import { DrumInstrument, DrumPattern, MusicTrack, MasterFxSettings } from '../types/music';

// Safe AudioContext creator
let globalAudioCtx: AudioContext | null = null;

export function getAudioContext(): AudioContext {
  if (!globalAudioCtx || globalAudioCtx.state === 'closed') {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    globalAudioCtx = new AudioContextClass();
  }
  if (globalAudioCtx.state === 'suspended') {
    globalAudioCtx.resume().catch(() => {});
  }
  return globalAudioCtx;
}

/**
 * Generate synthetic impulse response buffer for ConvolverNode (Realistic Reverb)
 */
export function createReverbImpulse(ctx: BaseAudioContext, duration: number = 2.0, decay: number = 2.0): AudioBuffer {
  const sampleRate = ctx.sampleRate;
  const length = Math.floor(sampleRate * duration);
  const impulse = ctx.createBuffer(2, length, sampleRate);
  const left = impulse.getChannelData(0);
  const right = impulse.getChannelData(1);

  for (let i = 0; i < length; i++) {
    const t = i / length;
    const n = Math.exp(-t * decay);
    left[i] = (Math.random() * 2 - 1) * n;
    right[i] = (Math.random() * 2 - 1) * n;
  }
  return impulse;
}

/**
 * Procedural Drum Synthesizers (Web Audio API)
 */
export function playSynthesizedDrum(
  ctx: BaseAudioContext,
  dest: AudioNode,
  instrument: DrumInstrument,
  time: number,
  volume: number = 0.8
) {
  const now = Math.max(ctx.currentTime, time);

  switch (instrument) {
    case 'kick': {
      // Punchy sub punch + pitch sweep 150Hz -> 35Hz
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(150, now);
      osc.frequency.exponentialRampToValueAtTime(35, now + 0.12);

      gain.gain.setValueAtTime(volume * 1.0, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

      osc.connect(gain);
      gain.connect(dest);

      osc.start(now);
      osc.stop(now + 0.3);
      break;
    }

    case 'snare': {
      // Tonal snap + White noise body
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.exponentialRampToValueAtTime(80, now + 0.08);
      oscGain.gain.setValueAtTime(volume * 0.5, now);
      oscGain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
      osc.connect(oscGain);
      oscGain.connect(dest);
      osc.start(now);
      osc.stop(now + 0.12);

      // Noise burst
      const bufferSize = Math.floor(ctx.sampleRate * 0.18);
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      const noiseSource = ctx.createBufferSource();
      noiseSource.buffer = noiseBuffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 800;

      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(volume * 0.7, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);

      noiseSource.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(dest);

      noiseSource.start(now);
      noiseSource.stop(now + 0.18);
      break;
    }

    case 'hihat': {
      // Crisp metallic tick (bandpass noise)
      const bufferSize = Math.floor(ctx.sampleRate * 0.06);
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 7000;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(volume * 0.45, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(dest);

      noise.start(now);
      noise.stop(now + 0.06);
      break;
    }

    case 'openhat': {
      const bufferSize = Math.floor(ctx.sampleRate * 0.35);
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 6000;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(volume * 0.4, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(dest);

      noise.start(now);
      noise.stop(now + 0.35);
      break;
    }

    case 'clap': {
      // Triple transient burst + reverb tail
      const bufferSize = Math.floor(ctx.sampleRate * 0.22);
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = noiseBuffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 1200;
      filter.Q.value = 1.2;

      const gain = ctx.createGain();
      // 3 clicks
      gain.gain.setValueAtTime(volume * 0.3, now);
      gain.gain.setValueAtTime(0.05, now + 0.015);
      gain.gain.setValueAtTime(volume * 0.4, now + 0.02);
      gain.gain.setValueAtTime(0.05, now + 0.035);
      gain.gain.setValueAtTime(volume * 0.6, now + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(dest);

      noise.start(now);
      noise.stop(now + 0.22);
      break;
    }

    case 'bass808': {
      // Heavy saturated sub bass note (C1 / 32.7Hz or F1 / 43.65Hz)
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(48, now);
      osc.frequency.exponentialRampToValueAtTime(36, now + 0.2);

      gain.gain.setValueAtTime(volume * 0.9, now);
      gain.gain.setValueAtTime(volume * 0.8, now + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      osc.connect(gain);
      gain.connect(dest);

      osc.start(now);
      osc.stop(now + 0.65);
      break;
    }
  }
}

/**
 * Decode Audio File (MP3, WAV, AAC, OGG) to AudioBuffer and extract visual waveform peaks
 */
export async function decodeAudioFile(file: File, ctx: AudioContext): Promise<{ buffer: AudioBuffer; peaks: number[] }> {
  const arrayBuffer = await file.arrayBuffer();
  const audioBuffer = await ctx.decodeAudioData(arrayBuffer);
  const peaks = extractPeaks(audioBuffer, 120);
  return { buffer: audioBuffer, peaks };
}

/**
 * Extract normalized peaks for waveform rendering
 */
export function extractPeaks(buffer: AudioBuffer, numPeaks: number = 100): number[] {
  const channelData = buffer.getChannelData(0);
  const totalLength = channelData.length;
  const blockSize = Math.floor(totalLength / numPeaks);
  const peaks: number[] = [];

  for (let i = 0; i < numPeaks; i++) {
    const start = i * blockSize;
    let max = 0;
    for (let j = 0; j < blockSize; j++) {
      const val = Math.abs(channelData[start + j] || 0);
      if (val > max) max = val;
    }
    peaks.push(Math.min(1, max));
  }
  return peaks;
}

/**
 * Convert AudioBuffer into a downloadable WAV Blob (16-bit PCM stereo/mono)
 */
export function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;

  const length = buffer.length * numChannels * bytesPerSample;
  const headerBuffer = new ArrayBuffer(44 + length);
  const view = new DataView(headerBuffer);

  const writeString = (offset: number, string: string) => {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  };

  /* RIFF identifier */
  writeString(0, 'RIFF');
  /* file length */
  view.setUint32(4, 36 + length, true);
  /* RIFF type */
  writeString(8, 'WAVE');
  /* format chunk identifier */
  writeString(12, 'fmt ');
  /* format chunk length */
  view.setUint32(16, 16, true);
  /* sample format (raw) */
  view.setUint16(20, format, true);
  /* channel count */
  view.setUint16(22, numChannels, true);
  /* sample rate */
  view.setUint32(24, sampleRate, true);
  /* byte rate (sample rate * block align) */
  view.setUint32(28, sampleRate * blockAlign, true);
  /* block align (channel count * bytes per sample) */
  view.setUint16(32, blockAlign, true);
  /* bits per sample */
  view.setUint16(34, bitDepth, true);
  /* data chunk identifier */
  writeString(36, 'data');
  /* data chunk length */
  view.setUint32(40, length, true);

  // Write sample data (interleaved)
  let offset = 44;
  const channels = [];
  for (let c = 0; c < numChannels; c++) {
    channels.push(buffer.getChannelData(c));
  }

  for (let i = 0; i < buffer.length; i++) {
    for (let c = 0; c < numChannels; c++) {
      const sample = Math.max(-1, Math.min(1, channels[c][i]));
      // Convert to 16-bit signed integer
      view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
      offset += 2;
    }
  }

  return new Blob([headerBuffer], { type: 'audio/wav' });
}

/**
 * Offline Mixdown: Combines drum sequencer loop and multitrack audio clips into a high quality WAV
 */
export async function renderMusicMixdown(
  tracks: MusicTrack[],
  drumPattern: DrumPattern,
  bpm: number,
  fx: MasterFxSettings,
  bars: number = 4
): Promise<{ blob: Blob; url: string; duration: number }> {
  const secondsPerBeat = 60 / bpm;
  const totalDuration = Math.max(4, secondsPerBeat * 4 * bars);
  const sampleRate = 44100;
  const totalSamples = Math.ceil(sampleRate * totalDuration);

  // Use OfflineAudioContext for rendering
  const offlineCtx = new OfflineAudioContext(2, totalSamples, sampleRate);

  // Master Gain Node
  const masterGain = offlineCtx.createGain();
  masterGain.gain.value = fx.volume;

  // Master Filter (Lowpass)
  const masterFilter = offlineCtx.createBiquadFilter();
  masterFilter.type = 'lowpass';
  masterFilter.frequency.value = fx.filterCutoff || 20000;

  // Master Reverb (Convolver)
  const convolver = offlineCtx.createConvolver();
  convolver.buffer = createReverbImpulse(offlineCtx, Math.max(0.5, fx.reverbDecay), 2.2);

  const reverbGain = offlineCtx.createGain();
  reverbGain.gain.value = fx.reverbWet;

  // Master Delay (Echo)
  const delayNode = offlineCtx.createDelay(2.0);
  delayNode.delayTime.value = Math.max(0.05, Math.min(1.0, fx.echoTime));

  const delayFeedback = offlineCtx.createGain();
  delayFeedback.gain.value = Math.min(0.75, fx.echoFeedback);
  delayNode.connect(delayFeedback);
  delayFeedback.connect(delayNode);

  const delayGain = offlineCtx.createGain();
  delayGain.gain.value = fx.echoFeedback > 0 ? 0.35 : 0;

  // Connect FX bus to destination
  masterGain.connect(masterFilter);
  masterFilter.connect(offlineCtx.destination);

  // Reverb & Echo sends to master
  convolver.connect(reverbGain);
  reverbGain.connect(masterGain);

  delayNode.connect(delayGain);
  delayGain.connect(masterGain);

  // 1. Schedule Drum Pattern across the bars
  const sixteenthTime = (60 / bpm) / 4;
  const total16ths = bars * 16;
  const instruments: DrumInstrument[] = ['kick', 'snare', 'hihat', 'openhat', 'clap', 'bass808'];

  for (let s = 0; s < total16ths; s++) {
    const patternStep = s % 16;
    const stepTime = s * sixteenthTime;

    instruments.forEach((inst) => {
      if (drumPattern[inst] && drumPattern[inst][patternStep]) {
        playSynthesizedDrum(offlineCtx, masterGain, inst, stepTime, 0.85);

        // Send drum to reverb/echo if active
        if (fx.reverbWet > 0 && (inst === 'snare' || inst === 'clap')) {
          playSynthesizedDrum(offlineCtx, convolver, inst, stepTime, 0.4);
        }
        if (fx.echoFeedback > 0 && inst === 'hihat') {
          playSynthesizedDrum(offlineCtx, delayNode, inst, stepTime, 0.3);
        }
      }
    });
  }

  // 2. Schedule Multitrack Audio Tracks
  for (const track of tracks) {
    if (track.isMuted) continue;
    if (!track.buffer) continue;

    const source = offlineCtx.createBufferSource();
    source.buffer = track.buffer;

    const trackGain = offlineCtx.createGain();
    trackGain.gain.value = track.volume;

    const trackPan = offlineCtx.createStereoPanner ? offlineCtx.createStereoPanner() : null;
    if (trackPan) {
      trackPan.pan.value = track.pan;
    }

    // Connect chain
    if (trackPan) {
      source.connect(trackGain);
      trackGain.connect(trackPan);
      trackPan.connect(masterGain);

      if (track.reverbSend > 0) trackPan.connect(convolver);
      if (track.echoSend > 0) trackPan.connect(delayNode);
    } else {
      source.connect(trackGain);
      trackGain.connect(masterGain);

      if (track.reverbSend > 0) trackGain.connect(convolver);
      if (track.echoSend > 0) trackGain.connect(delayNode);
    }

    // Offset playback for trim
    const effectiveDuration = Math.min(track.trimEnd - track.trimStart, totalDuration);
    source.start(0, track.trimStart, effectiveDuration);
  }

  // Render audio offline
  const renderedBuffer = await offlineCtx.startRendering();
  const wavBlob = audioBufferToWavBlob(renderedBuffer);
  const url = URL.createObjectURL(wavBlob);

  return { blob: wavBlob, url, duration: totalDuration };
}
