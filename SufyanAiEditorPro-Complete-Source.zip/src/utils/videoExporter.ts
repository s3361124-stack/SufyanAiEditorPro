import { ExportSettings, ExportResolution, VideoProject, VideoClip } from '../types/editor';
import {
  getAspectRatioDimensions,
  buildCssFilter,
  applyCanvasCinematicEffects,
  drawClipToCanvas,
  drawTextOverlays,
  drawPipOverlays
} from './videoRenderer';

export interface ExportProgress {
  progress: number; // 0 to 100
  currentFrame: number;
  totalFrames: number;
  elapsedSeconds: number;
  remainingSeconds: number;
  status: 'preparing' | 'rendering' | 'encoding' | 'completed' | 'error';
  errorMessage?: string;
}

export const RESOLUTION_SPECS: Record<ExportResolution, { baseWidth: number; label: string; bitrateUltra: number; bitrateHigh: number; minRamGb: number }> = {
  '720p': { baseWidth: 1280, label: '720p HD (1280x720)', bitrateUltra: 8000000, bitrateHigh: 5000000, minRamGb: 2 },
  '1080p': { baseWidth: 1920, label: '1080p Full HD (1920x1080)', bitrateUltra: 16000000, bitrateHigh: 10000000, minRamGb: 4 },
  '1440p': { baseWidth: 2560, label: '1440p 2K QHD (2560x1440)', bitrateUltra: 28000000, bitrateHigh: 18000000, minRamGb: 6 },
  '4k': { baseWidth: 3840, label: '4K Ultra HD (3840x2160)', bitrateUltra: 55000000, bitrateHigh: 35000000, minRamGb: 8 },
  '8k': { baseWidth: 7680, label: '8K FUHD (7680x4320)', bitrateUltra: 100000000, bitrateHigh: 65000000, minRamGb: 16 },
  '10k': { baseWidth: 10240, label: '10K Master (10240x5760)', bitrateUltra: 150000000, bitrateHigh: 90000000, minRamGb: 24 }
};

export async function exportVideoProject(
  project: VideoProject,
  settings: ExportSettings,
  onProgress: (p: ExportProgress) => void,
  abortSignal?: { aborted: boolean }
): Promise<{ blob: Blob; url: string; filename: string }> {
  return new Promise(async (resolve, reject) => {
    try {
      const startTimeMs = Date.now();
      const spec = RESOLUTION_SPECS[settings.resolution] || RESOLUTION_SPECS['1080p'];
      const dims = getAspectRatioDimensions(project.aspectRatio, spec.baseWidth);

      // Verify canvas allocation
      const offscreenCanvas = document.createElement('canvas');
      offscreenCanvas.width = dims.width;
      offscreenCanvas.height = dims.height;
      const rawCtx = offscreenCanvas.getContext('2d');

      if (!rawCtx) {
        throw new Error(
          `Unable to allocate ${dims.width}x${dims.height} video canvas on this device. Device GPU/RAM limit reached. Try exporting at 1080p or 1440p.`
        );
      }
      const ctx: CanvasRenderingContext2D = rawCtx;

      // Preload all clip elements
      onProgress({
        progress: 2,
        currentFrame: 0,
        totalFrames: 0,
        elapsedSeconds: 0,
        remainingSeconds: 0,
        status: 'preparing'
      });

      const elementsMap = new Map<string, HTMLVideoElement | HTMLImageElement>();
      for (const clip of project.clips) {
        if (abortSignal?.aborted) throw new Error('Export cancelled by user.');

        if (clip.type === 'video') {
          const video = document.createElement('video');
          if (!clip.sourceUrl.startsWith('data:') && !clip.sourceUrl.startsWith('blob:')) {
            video.crossOrigin = 'anonymous';
          }
          video.src = clip.sourceUrl;
          video.muted = true;
          video.preload = 'auto';
          await new Promise((res) => {
            video.onloadeddata = res;
            video.onerror = res;
          });
          elementsMap.set(clip.id, video);
        } else {
          const img = new Image();
          if (!clip.sourceUrl.startsWith('data:') && !clip.sourceUrl.startsWith('blob:')) {
            img.crossOrigin = 'anonymous';
          }
          img.src = clip.sourceUrl;
          await new Promise((res) => {
            img.onload = res;
            img.onerror = res;
          });
          elementsMap.set(clip.id, img);
        }
      }

      // Preload PIP overlay elements
      const pipElementsMap = new Map<string, HTMLImageElement | HTMLVideoElement>();
      for (const pip of project.pipOverlays) {
        if (abortSignal?.aborted) throw new Error('Export cancelled by user.');
        const img = new Image();
        if (!pip.sourceUrl.startsWith('data:') && !pip.sourceUrl.startsWith('blob:')) {
          img.crossOrigin = 'anonymous';
        }
        img.src = pip.sourceUrl;
        await new Promise((res) => {
          img.onload = res;
          img.onerror = res;
        });
        pipElementsMap.set(pip.id, img);
      }

      // Calculate total duration
      const totalDuration = project.clips.reduce(
        (sum, c) => sum + (c.endTime - c.startTime) / c.playbackRate,
        0
      );

      if (totalDuration <= 0) {
        throw new Error('Project has no clips to export. Please add at least one clip.');
      }

      const fps = settings.fps;
      const totalFrames = Math.max(1, Math.round(totalDuration * fps));

      // Audio Mixing setup with Web Audio API
      let audioCtx: AudioContext | null = null;
      let audioDest: MediaStreamAudioDestinationNode | null = null;
      const audioSources: AudioBufferSourceNode[] = [];

      try {
        const AudioContextClass =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AudioContextClass && project.audioTracks && project.audioTracks.length > 0) {
          audioCtx = new AudioContextClass();
          audioDest = audioCtx.createMediaStreamDestination();

          // Preload and decode project audio tracks
          for (const track of project.audioTracks) {
            try {
              const res = await fetch(track.url);
              if (res.ok) {
                const arrayBuf = await res.arrayBuffer();
                const audioBuffer = await audioCtx.decodeAudioData(arrayBuf);
                const source = audioCtx.createBufferSource();
                source.buffer = audioBuffer;

                const gainNode = audioCtx.createGain();
                gainNode.gain.value = track.volume ?? 1.0;

                source.connect(gainNode);
                gainNode.connect(audioDest);
                audioSources.push(source);

                // Schedule playback offset
                const playDelay = Math.max(0, track.startTime);
                source.start(audioCtx.currentTime + playDelay);
              }
            } catch (audioErr) {
              console.warn(`Could not preload audio track ${track.name || track.id}:`, audioErr);
            }
          }
        }
      } catch (err) {
        console.warn('Audio mixing initialization skipped or unsupported:', err);
      }

      // Determine supported mime type
      let mimeType = '';
      if (settings.format === 'mp4') {
        if (MediaRecorder.isTypeSupported('video/mp4;codecs=avc1,mp4a.40.2')) {
          mimeType = 'video/mp4;codecs=avc1,mp4a.40.2';
        } else if (MediaRecorder.isTypeSupported('video/mp4')) {
          mimeType = 'video/mp4';
        }
      }
      if (!mimeType) {
        if (MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')) {
          mimeType = 'video/webm;codecs=vp9,opus';
        } else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')) {
          mimeType = 'video/webm;codecs=vp8,opus';
        } else if (MediaRecorder.isTypeSupported('video/webm')) {
          mimeType = 'video/webm';
        }
      }

      const stream = offscreenCanvas.captureStream(fps);

      // Attach mixed audio track if available
      if (audioDest && audioDest.stream.getAudioTracks().length > 0) {
        const audioTrack = audioDest.stream.getAudioTracks()[0];
        stream.addTrack(audioTrack);
      }

      const targetBitrate =
        settings.quality === 'ultra'
          ? spec.bitrateUltra
          : settings.quality === 'high'
          ? spec.bitrateHigh
          : Math.round(spec.bitrateHigh * 0.6);

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: mimeType || undefined,
        videoBitsPerSecond: targetBitrate
      });

      const chunks: Blob[] = [];
      mediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
      };

      mediaRecorder.onstop = () => {
        // Clean up audio sources and context
        audioSources.forEach((s) => {
          try {
            s.stop();
          } catch (e) {}
        });
        if (audioCtx && audioCtx.state !== 'closed') {
          audioCtx.close().catch(() => {});
        }

        const finalBlob = new Blob(chunks, { type: mimeType || 'video/webm' });
        const finalUrl = URL.createObjectURL(finalBlob);
        const ext = (mimeType && mimeType.includes('mp4')) ? 'mp4' : 'webm';
        const sanitizedName = (project.name || 'sufyan_pro_edit').replace(/[^a-zA-Z0-9_-]/g, '_');
        const filename = `${sanitizedName}_${settings.resolution.toUpperCase()}_${settings.fps}fps.${ext}`;

        onProgress({
          progress: 100,
          currentFrame: totalFrames,
          totalFrames,
          elapsedSeconds: Math.round((Date.now() - startTimeMs) / 1000),
          remainingSeconds: 0,
          status: 'completed'
        });

        resolve({ blob: finalBlob, url: finalUrl, filename });
      };

      mediaRecorder.start();

      let currentFrame = 0;
      const frameDuration = 1 / fps;
      const frameIntervalMs = 1000 / fps;

      async function renderNextFrame() {
        if (abortSignal?.aborted) {
          mediaRecorder.stop();
          reject(new Error('Export cancelled by user.'));
          return;
        }

        if (currentFrame >= totalFrames) {
          // Flush mediaRecorder by waiting a moment for final chunks
          setTimeout(() => {
            if (mediaRecorder.state !== 'inactive') {
              mediaRecorder.stop();
            }
          }, 150);
          return;
        }

        const projectTime = currentFrame * frameDuration;

        // Find which clip is active at this project time
        let accumulatedTime = 0;
        let activeClip: VideoClip | null = null;
        let clipLocalTime = 0;

        for (const clip of project.clips) {
          const effectiveDuration = (clip.endTime - clip.startTime) / clip.playbackRate;
          if (projectTime >= accumulatedTime && projectTime < accumulatedTime + effectiveDuration) {
            activeClip = clip;
            clipLocalTime = clip.startTime + (projectTime - accumulatedTime) * clip.playbackRate;
            break;
          }
          accumulatedTime += effectiveDuration;
        }

        if (!activeClip && project.clips.length > 0) {
          activeClip = project.clips[project.clips.length - 1];
          clipLocalTime = activeClip.endTime;
        }

        // Clear canvas
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, dims.width, dims.height);

        if (activeClip) {
          const element = elementsMap.get(activeClip.id);
          if (element) {
            if (activeClip.type === 'video' && element instanceof HTMLVideoElement) {
              element.currentTime = clipLocalTime;
              await new Promise((r) => {
                const onSeeked = () => {
                  element.removeEventListener('seeked', onSeeked);
                  r(null);
                };
                element.addEventListener('seeked', onSeeked);
                setTimeout(r, 30); // fallback safety
              });
            }

            // Apply CSS color grade filter to offscreen context
            ctx.save();
            ctx.filter = buildCssFilter(project.colorGrade);
            drawClipToCanvas(ctx, element, activeClip, dims.width, dims.height);
            ctx.restore();

            // Apply cinematic overlay effects (temperature, vignette, grain, letterbox)
            applyCanvasCinematicEffects(ctx, dims.width, dims.height, project.colorGrade);
          }
        }

        // Draw Text Overlays
        drawTextOverlays(ctx, project.textOverlays, projectTime, dims.width, dims.height);

        // Draw PIP Overlays
        drawPipOverlays(ctx, project.pipOverlays, projectTime, dims.width, dims.height, pipElementsMap);

        currentFrame++;
        const progress = Math.min(99, Math.round((currentFrame / totalFrames) * 100));
        const elapsedSec = (Date.now() - startTimeMs) / 1000;
        const framesPerSec = currentFrame / Math.max(0.1, elapsedSec);
        const remainingFrames = totalFrames - currentFrame;
        const remainingSec = Math.round(remainingFrames / Math.max(1, framesPerSec));

        if (currentFrame % 5 === 0 || currentFrame === totalFrames) {
          onProgress({
            progress,
            currentFrame,
            totalFrames,
            elapsedSeconds: Math.round(elapsedSec),
            remainingSeconds: remainingSec,
            status: 'rendering'
          });
        }

        // Precise wall-clock frame pacing for captureStream
        const targetWallClock = startTimeMs + currentFrame * frameIntervalMs;
        const delay = Math.max(0, targetWallClock - Date.now());
        if (delay > 0) {
          setTimeout(renderNextFrame, delay);
        } else {
          // If slightly behind, yield to browser render cycle
          setTimeout(renderNextFrame, 0);
        }
      }

      renderNextFrame();
    } catch (err) {
      onProgress({
        progress: 0,
        currentFrame: 0,
        totalFrames: 0,
        elapsedSeconds: 0,
        remainingSeconds: 0,
        status: 'error',
        errorMessage: (err as Error).message || 'Export error'
      });
      reject(err);
    }
  });
}
