export interface MusicTrack {
  id: string;
  name: string;
  url: string;
  buffer?: AudioBuffer;
  peaks?: number[];
  duration: number; // in seconds
  trimStart: number;
  trimEnd: number;
  volume: number; // 0 to 1
  pan: number; // -1 to 1
  isMuted: boolean;
  isSolo: boolean;
  reverbSend: number; // 0 to 1
  echoSend: number; // 0 to 1
  color: string;
}

export type DrumInstrument = 'kick' | 'snare' | 'hihat' | 'openhat' | 'clap' | 'bass808';

export interface DrumStep {
  active: boolean;
  accent?: boolean;
}

export interface DrumPattern {
  kick: boolean[];
  snare: boolean[];
  hihat: boolean[];
  openhat: boolean[];
  clap: boolean[];
  bass808: boolean[];
}

export interface MasterFxSettings {
  volume: number;
  reverbWet: number;
  reverbDecay: number;
  echoTime: number; // seconds (e.g. 0.25 = 1/4 note at 120bpm)
  echoFeedback: number; // 0 to 0.8
  filterCutoff: number; // 200 to 20000 Hz
}
