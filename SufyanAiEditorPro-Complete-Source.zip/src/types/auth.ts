export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatarUrl?: string;
  provider: 'email' | 'google' | 'apple' | 'phone' | 'guest';
  createdAt: number;
  lastLoginAt: number;
  plan: 'free_pro';
  cloudSyncEnabled: boolean;
  projectsCount: number;
}

export interface AuthState {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isGuest: boolean;
}

export interface SocialProviderConfig {
  name: 'Google' | 'Apple' | 'Facebook';
  status: 'supported_requires_config' | 'configured' | 'client_side_ready';
  requiredCredentials: string[];
  docsUrl: string;
  securityNotice: string;
}
