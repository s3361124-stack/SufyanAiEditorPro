export type AspectRatio = '16:9' | '9:16' | '1:1' | '4:5' | '21:9';

export type ClipType = 'video' | 'image' | 'color';

export interface VideoClip {
  id: string;
  name: string;
  type: ClipType;
  sourceUrl: string; // Blob URL or base64 or sample URL
  thumbnailUrl?: string;
  duration: number; // in seconds
  startTime: number; // trimmed in-point
  endTime: number; // trimmed out-point
  playbackRate: number; // 0.25 to 4.0
  volume: number; // 0 to 2.0 (1.0 = normal)
  muted: boolean;
  rotation: number; // 0, 90, 180, 270
  flipHorizontal: boolean;
  flipVertical: boolean;
  fitMode: 'cover' | 'contain' | 'fill';
}

export interface Transition {
  type: 'none' | 'fade' | 'crossfade' | 'zoom' | 'slide-left' | 'glitch' | 'flash-white';
  duration: number; // in seconds, typically 0.3 - 1.0s
}

export type LUTPreset = 
  | 'original'
  | 'teal-orange'
  | 'film-noir'
  | 'vintage-35mm'
  | 'cyberpunk'
  | 'golden-hour'
  | 'emerald'
  | 'bleach-bypass'
  | 'kodachrome';

export interface ColorGradeSettings {
  preset: LUTPreset;
  brightness: number; // -100 to 100 (0 default)
  contrast: number; // -100 to 100 (0 default)
  saturation: number; // -100 to 100 (0 default)
  temperature: number; // -100 (cool cyan) to 100 (warm orange)
  sharpness: number; // 0 to 100
  vignette: number; // 0 to 100
  filmGrain: number; // 0 to 100
  letterbox: boolean; // 2.39:1 cinematic bars
  letterboxHeight: number; // 0 to 25 (%)
}

export interface TextOverlay {
  id: string;
  text: string;
  type: 'title' | 'subtitle' | 'caption' | 'credits';
  startTime: number;
  endTime: number;
  x: number; // percentage (0 - 100)
  y: number; // percentage (0 - 100)
  fontSize: number; // in px
  fontFamily: string;
  color: string;
  backgroundColor?: string;
  borderColor?: string;
  letterSpacing?: number;
  align: 'left' | 'center' | 'right';
  animation: 'none' | 'fade' | 'typewriter' | 'zoom-in' | 'scroll-up';
}

export interface OverlayMedia {
  id: string;
  sourceUrl: string;
  name: string;
  startTime: number;
  endTime: number;
  x: number; // percentage
  y: number; // percentage
  width: number; // percentage
  height: number; // percentage
  opacity: number;
  borderRadius: number;
}

export interface AudioTrack {
  id: string;
  name: string;
  url: string;
  duration: number;
  startTime: number; // when it begins in project timeline
  volume: number; // 0 to 2.0
  fadeIn: number; // seconds
  fadeOut: number; // seconds
  isVoiceover?: boolean;
}

export interface VideoProject {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  aspectRatio: AspectRatio;
  clips: VideoClip[];
  transitions: Record<string, Transition>; // key is clip id before transition
  colorGrade: ColorGradeSettings;
  textOverlays: TextOverlay[];
  pipOverlays: OverlayMedia[];
  audioTracks: AudioTrack[];
}

export type ExportResolution = '720p' | '1080p' | '1440p' | '4k' | '8k' | '10k';

export interface ResolutionSpec {
  id: ExportResolution;
  label: string;
  width16x9: number;
  height16x9: number;
  width9x16: number;
  height9x16: number;
  megapixels: number;
  recommendedRamGb: number;
  tier: 'mobile_safe' | 'recommended' | 'high_end' | 'workstation_only';
  upscaleWarning?: string;
}

export interface ExportSettings {
  resolution: ExportResolution;
  fps: 30 | 60;
  quality: 'medium' | 'high' | 'ultra';
  format: 'mp4' | 'webm';
  codec?: 'h264' | 'vp9' | 'auto';
}


export interface PhotoFilterSettings {
  brightness: number; // -100 to 100
  contrast: number; // -100 to 100
  saturation: number; // -100 to 100
  temperature: number; // -100 to 100
  sharpness: number; // 0 to 100
  vignette: number; // 0 to 100
  bokehBlur: number; // 0 to 100
  bokehRadius: number; // focal circle radius
  removeBackground: boolean;
  bgReplacementType: 'transparent' | 'color' | 'gradient' | 'cyber' | 'studio' | 'nature';
  customBgColor: string;
  autoEnhanced: boolean;
  lut: LUTPreset;
}
