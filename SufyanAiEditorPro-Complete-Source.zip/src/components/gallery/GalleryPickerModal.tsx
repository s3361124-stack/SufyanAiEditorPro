import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  Film,
  Camera,
  Music,
  Plus,
  Check,
  Sparkles,
  Smartphone,
  FolderOpen,
  Volume2,
  Play,
  Pause
} from 'lucide-react';
import { SAMPLE_VIDEOS, SAMPLE_PHOTOS, SAMPLE_AUDIO } from '../../utils/sampleMedia';
import { VideoClip, AudioTrack } from '../../types/editor';

interface GalleryPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectVideoClip: (clip: VideoClip) => void;
  onSelectPhoto: (url: string) => void;
  onSelectAudioTrack: (track: AudioTrack) => void;
  initialTab?: 'video' | 'photo' | 'audio';
}

export const GalleryPickerModal: React.FC<GalleryPickerModalProps> = ({
  isOpen,
  onClose,
  onSelectVideoClip,
  onSelectPhoto,
  onSelectAudioTrack,
  initialTab = 'video'
}) => {
  const [activeTab, setActiveTab] = useState<'video' | 'photo' | 'audio'>(initialTab);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const audioPreviewRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Handle local file picking
  const handleLocalFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    const type = file.type;

    if (type.startsWith('video/')) {
      const clip: VideoClip = {
        id: 'clip_' + Date.now(),
        name: file.name.replace(/\.[^/.]+$/, ''),
        type: 'video',
        sourceUrl: url,
        duration: 10,
        startTime: 0,
        endTime: 10,
        playbackRate: 1.0,
        volume: 1.0,
        muted: false,
        rotation: 0,
        flipHorizontal: false,
        flipVertical: false,
        fitMode: 'cover'
      };
      onSelectVideoClip(clip);
      onClose();
    } else if (type.startsWith('image/')) {
      onSelectPhoto(url);
      onClose();
    } else if (type.startsWith('audio/')) {
      const track: AudioTrack = {
        id: 'audio_' + Date.now(),
        name: file.name.replace(/\.[^/.]+$/, ''),
        url: url,
        duration: 15,
        startTime: 0,
        volume: 1.0,
        fadeIn: 0.5,
        fadeOut: 0.5
      };
      onSelectAudioTrack(track);
      onClose();
    }
  };

  const handleSelectSampleVideo = (item: any) => {
    const clip: VideoClip = {
      id: 'clip_' + Date.now(),
      name: item.name,
      type: item.url.endsWith('.png') || item.url.endsWith('.jpg') ? 'image' : 'video',
      sourceUrl: item.url,
      duration: item.duration || 6,
      startTime: 0,
      endTime: item.duration || 6,
      playbackRate: 1.0,
      volume: 1.0,
      muted: false,
      rotation: 0,
      flipHorizontal: false,
      flipVertical: false,
      fitMode: 'cover'
    };
    onSelectVideoClip(clip);
    onClose();
  };

  const handleSelectSamplePhoto = (url: string) => {
    onSelectPhoto(url);
    onClose();
  };

  const handleTogglePlayAudio = (track: any) => {
    if (playingAudioId === track.id) {
      audioPreviewRef.current?.pause();
      setPlayingAudioId(null);
    } else {
      if (audioPreviewRef.current) {
        audioPreviewRef.current.src = track.url;
        audioPreviewRef.current.play().catch(() => {});
        setPlayingAudioId(track.id);
      }
    }
  };

  const handleAddSampleAudio = (track: any) => {
    const audioTrack: AudioTrack = {
      id: 'audio_' + Date.now(),
      name: track.name,
      url: track.url,
      duration: track.duration || 20,
      startTime: 0,
      volume: 1.0,
      fadeIn: 0.5,
      fadeOut: 0.5
    };
    onSelectAudioTrack(audioTrack);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <audio
        ref={audioPreviewRef}
        onEnded={() => setPlayingAudioId(null)}
        className="hidden"
      />
      <input
        ref={fileInputRef}
        type="file"
        accept={
          activeTab === 'video'
            ? 'video/*'
            : activeTab === 'photo'
            ? 'image/*'
            : 'audio/*'
        }
        onChange={handleLocalFileSelect}
        className="hidden"
      />

      <div className="w-full max-w-2xl bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-zinc-800/80 bg-zinc-900/60 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <FolderOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-wide">
                STUDIO MEDIA GALLERY PICKER
              </h2>
              <p className="text-[11px] text-zinc-400">Import Phone Media or Royalty-Free Studio Clips</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-zinc-800/80 bg-zinc-900/40 px-6 pt-2 shrink-0">
          <button
            onClick={() => setActiveTab('video')}
            className={`flex items-center space-x-1.5 pb-2.5 px-3 text-xs font-semibold border-b-2 transition ${
              activeTab === 'video'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Film className="w-3.5 h-3.5" />
            <span>Video Clips</span>
          </button>

          <button
            onClick={() => setActiveTab('photo')}
            className={`flex items-center space-x-1.5 pb-2.5 px-3 text-xs font-semibold border-b-2 transition ${
              activeTab === 'photo'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Photos & Stills</span>
          </button>

          <button
            onClick={() => setActiveTab('audio')}
            className={`flex items-center space-x-1.5 pb-2.5 px-3 text-xs font-semibold border-b-2 transition ${
              activeTab === 'audio'
                ? 'border-purple-400 text-purple-400'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Music className="w-3.5 h-3.5" />
            <span>Audio & Sound FX</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 sm:p-6 space-y-4 overflow-y-auto flex-1">
          {/* Upload Button */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-zinc-800 hover:border-cyan-400/60 rounded-xl p-4 text-center cursor-pointer bg-zinc-900/40 hover:bg-zinc-900/80 transition flex flex-col items-center justify-center space-y-1.5 group"
          >
            <div className="p-2.5 rounded-full bg-zinc-800 group-hover:bg-cyan-500/20 text-zinc-400 group-hover:text-cyan-400 transition">
              <Upload className="w-5 h-5" />
            </div>
            <div className="text-xs font-bold text-white">
              Choose from Phone Gallery or Computer
            </div>
            <p className="text-[11px] text-zinc-500">
              {activeTab === 'video'
                ? 'MP4, WebM, MOV gameplay or camera clips'
                : activeTab === 'photo'
                ? 'PNG, JPG, WebP photos & graphics'
                : 'MP3, WAV, AAC music tracks & voiceovers'}
            </p>
          </div>

          <div className="text-xs font-semibold text-zinc-400 pt-1">
            Or select royalty-free Studio Asset:
          </div>

          {/* VIDEO TAB CONTENT */}
          {activeTab === 'video' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {SAMPLE_VIDEOS.map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleSelectSampleVideo(item)}
                  className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-cyan-400/50 cursor-pointer transition flex items-center space-x-3 group"
                >
                  <div className="w-16 h-12 rounded-lg bg-black border border-zinc-800 overflow-hidden shrink-0 flex items-center justify-center">
                    {item.url.endsWith('.png') || item.url.endsWith('.jpg') ? (
                      <img src={item.url} alt={item.name} className="w-full h-full object-cover" />
                    ) : (
                      <Film className="w-5 h-5 text-zinc-500 group-hover:text-cyan-400 transition" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-white truncate group-hover:text-cyan-400 transition">
                      {item.name}
                    </div>
                    <div className="text-[10px] text-zinc-500 uppercase">{item.category} • {item.duration}s</div>
                  </div>
                  <Plus className="w-4 h-4 text-zinc-500 group-hover:text-cyan-400" />
                </div>
              ))}
            </div>
          )}

          {/* PHOTO TAB CONTENT */}
          {activeTab === 'photo' && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {SAMPLE_PHOTOS.map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleSelectSamplePhoto(item.url)}
                  className="rounded-xl border border-zinc-800 hover:border-amber-400/50 cursor-pointer overflow-hidden group bg-zinc-900"
                >
                  <div className="aspect-square bg-black overflow-hidden relative">
                    <img
                      src={item.url}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                  </div>
                  <div className="p-2">
                    <div className="text-[11px] font-bold text-white truncate group-hover:text-amber-400 transition">
                      {item.name}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* AUDIO TAB CONTENT */}
          {activeTab === 'audio' && (
            <div className="space-y-2">
              {SAMPLE_AUDIO.map((track) => (
                <div
                  key={track.id}
                  className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-between"
                >
                  <div className="flex items-center space-x-3 min-w-0">
                    <button
                      type="button"
                      onClick={() => handleTogglePlayAudio(track)}
                      className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition"
                    >
                      {playingAudioId === track.id ? (
                        <Pause className="w-4 h-4 text-purple-400" />
                      ) : (
                        <Play className="w-4 h-4" />
                      )}
                    </button>
                    <div className="truncate">
                      <div className="text-xs font-bold text-white truncate">{track.name}</div>
                      <div className="text-[10px] text-zinc-500">Royalty-Free Audio • {track.duration}s</div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleAddSampleAudio(track)}
                    className="px-3 py-1.5 rounded-lg bg-purple-500/20 hover:bg-purple-500 text-purple-300 hover:text-black font-bold text-xs transition flex items-center space-x-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add to Timeline</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
