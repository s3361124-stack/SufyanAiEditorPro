import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  Download,
  Sparkles,
  Scissors,
  Sliders,
  Crop,
  RotateCw,
  FlipHorizontal,
  Eye,
  Check,
  Undo2,
  Image as ImageIcon,
  Disc,
  Layers,
  FileCheck,
  Sparkle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PhotoFilterSettings, LUTPreset } from '../../types/editor';
import { processPhotoOnCanvas } from '../../utils/photoProcessing';
import { SAMPLE_PHOTOS } from '../../utils/sampleMedia';

const DEFAULT_SETTINGS: PhotoFilterSettings = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  temperature: 0,
  sharpness: 0,
  vignette: 0,
  bokehBlur: 0,
  bokehRadius: 50,
  removeBackground: false,
  bgReplacementType: 'transparent',
  customBgColor: '#1e293b',
  autoEnhanced: false,
  lut: 'original'
};

export const PhotoEditor: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const originalImageRef = useRef<HTMLImageElement | null>(null);

  const [imageSrc, setImageSrc] = useState<string>(SAMPLE_PHOTOS[0].url);
  const [settings, setSettings] = useState<PhotoFilterSettings>(DEFAULT_SETTINGS);
  const [showBeforeAfter, setShowBeforeAfter] = useState(false);
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isProcessing, setIsProcessing] = useState(false);

  // Crop & Transform State
  const [isCropOpen, setIsCropOpen] = useState(false);
  const [imageHistory, setImageHistory] = useState<string[]>([]);
  const [imageDimensions, setImageDimensions] = useState<{ width: number; height: number }>({ width: 0, height: 0 });

  // Export Settings
  const [exportFormat, setExportFormat] = useState<'png' | 'jpeg' | 'webp'>('png');
  const [exportQuality, setExportQuality] = useState(0.95);
  const [showExportDrawer, setShowExportDrawer] = useState(false);

  // Load and render photo when imageSrc or settings change
  useEffect(() => {
    const img = new Image();
    if (!imageSrc.startsWith('blob:') && !imageSrc.startsWith('data:')) {
      img.crossOrigin = 'anonymous';
    }
    img.src = imageSrc;

    img.onload = () => {
      originalImageRef.current = img;
      setImageDimensions({
        width: img.naturalWidth || img.width,
        height: img.naturalHeight || img.height
      });
      if (canvasRef.current) {
        setIsProcessing(true);
        processPhotoOnCanvas(img, settings, canvasRef.current);
        setIsProcessing(false);
      }
    };
    img.onerror = () => {
      console.warn('Failed to load photo:', imageSrc);
      setIsProcessing(false);
    };
  }, [imageSrc, settings]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const blobUrl = URL.createObjectURL(file);
    setImageHistory((prev) => [...prev, imageSrc]);
    setImageSrc(blobUrl);
    setSettings(DEFAULT_SETTINGS);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Crop Execution to Aspect Ratio Preset
  const handleApplyCrop = (aspect: '1:1' | '4:5' | '9:16' | '16:9' | '3:2') => {
    const img = originalImageRef.current;
    if (!img) return;

    const sourceW = img.naturalWidth || img.width;
    const sourceH = img.naturalHeight || img.height;
    if (!sourceW || !sourceH) return;

    let targetRatio = 1;
    if (aspect === '1:1') targetRatio = 1;
    else if (aspect === '4:5') targetRatio = 4 / 5;
    else if (aspect === '9:16') targetRatio = 9 / 16;
    else if (aspect === '16:9') targetRatio = 16 / 9;
    else if (aspect === '3:2') targetRatio = 3 / 2;

    const currentRatio = sourceW / sourceH;
    let cropW = sourceW;
    let cropH = sourceH;
    let cropX = 0;
    let cropY = 0;

    if (currentRatio > targetRatio) {
      cropW = Math.round(sourceH * targetRatio);
      cropX = Math.round((sourceW - cropW) / 2);
    } else {
      cropH = Math.round(sourceW / targetRatio);
      cropY = Math.round((sourceH - cropH) / 2);
    }

    const offscreen = document.createElement('canvas');
    offscreen.width = cropW;
    offscreen.height = cropH;
    const ctx = offscreen.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(img, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);
    const croppedUrl = offscreen.toDataURL('image/png', 1.0);

    setImageHistory((prev) => [...prev, imageSrc]);
    setImageSrc(croppedUrl);
    setIsCropOpen(false);
  };

  // Rotate 90 Degrees Clockwise
  const handleRotate90 = () => {
    const img = originalImageRef.current;
    if (!img) return;
    const sourceW = img.naturalWidth || img.width;
    const sourceH = img.naturalHeight || img.height;

    const offscreen = document.createElement('canvas');
    offscreen.width = sourceH;
    offscreen.height = sourceW;
    const ctx = offscreen.getContext('2d');
    if (!ctx) return;

    ctx.translate(sourceH / 2, sourceW / 2);
    ctx.rotate((90 * Math.PI) / 180);
    ctx.drawImage(img, -sourceW / 2, -sourceH / 2);

    setImageHistory((prev) => [...prev, imageSrc]);
    setImageSrc(offscreen.toDataURL('image/png', 1.0));
  };

  // Flip Horizontal
  const handleFlipHorizontal = () => {
    const img = originalImageRef.current;
    if (!img) return;
    const sourceW = img.naturalWidth || img.width;
    const sourceH = img.naturalHeight || img.height;

    const offscreen = document.createElement('canvas');
    offscreen.width = sourceW;
    offscreen.height = sourceH;
    const ctx = offscreen.getContext('2d');
    if (!ctx) return;

    ctx.translate(sourceW, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(img, 0, 0);

    setImageHistory((prev) => [...prev, imageSrc]);
    setImageSrc(offscreen.toDataURL('image/png', 1.0));
  };

  // Undo Last Crop / Transform
  const handleUndo = () => {
    if (imageHistory.length === 0) return;
    const previous = imageHistory[imageHistory.length - 1];
    setImageHistory((prev) => prev.slice(0, -1));
    setImageSrc(previous);
  };

  // Download Processed Photo with Format & Quality Controls
  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const mime =
      exportFormat === 'jpeg' ? 'image/jpeg' : exportFormat === 'webp' ? 'image/webp' : 'image/png';
    const dataUrl = canvas.toDataURL(mime, exportQuality);
    const link = document.createElement('a');
    link.download = `sufyan_pro_photo_${Date.now()}.${exportFormat}`;
    link.href = dataUrl;
    link.click();

    setShowExportDrawer(false);

    confetti({
      particleCount: 60,
      spread: 60,
      origin: { y: 0.7 }
    });
  };

  const handleReset = () => {
    setSettings(DEFAULT_SETTINGS);
  };

  return (
    <div className="w-full flex flex-col space-y-4 animate-fadeIn pb-10">
      <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />

      {/* Top Photo Studio Header */}
      <div className="flex items-center justify-between bg-zinc-950 border border-zinc-800 rounded-2xl px-4 py-2.5 shadow-lg flex-wrap gap-2">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold text-white tracking-wide">PHOTO AI & RETOUCH STUDIO</h2>
          {imageDimensions.width > 0 && (
            <span className="hidden sm:inline-block text-[11px] bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded font-mono">
              {imageDimensions.width} × {imageDimensions.height} px
            </span>
          )}
        </div>

        <div className="flex items-center space-x-1.5 sm:space-x-2 flex-wrap">
          {/* Undo Crop / Transform */}
          {imageHistory.length > 0 && (
            <button
              onClick={handleUndo}
              className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 rounded-xl border border-zinc-800 text-xs transition"
              title="Undo Crop / Transform"
            >
              <Undo2 className="w-4 h-4" />
            </button>
          )}

          {/* Crop Toggle Button */}
          <button
            onClick={() => setIsCropOpen(!isCropOpen)}
            className={`flex items-center space-x-1 px-3 py-1.5 rounded-xl text-xs font-semibold border transition ${
              isCropOpen
                ? 'border-amber-400 bg-amber-950/40 text-amber-300'
                : 'border-zinc-800 bg-zinc-900 text-zinc-300 hover:text-white'
            }`}
            title="Image Crop & Aspect Ratio Presets"
          >
            <Crop className="w-3.5 h-3.5" />
            <span>Crop</span>
          </button>

          {/* Rotate 90 */}
          <button
            onClick={handleRotate90}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 rounded-xl border border-zinc-800 text-xs transition"
            title="Rotate 90° Clockwise"
          >
            <RotateCw className="w-4 h-4" />
          </button>

          {/* Flip Horizontal */}
          <button
            onClick={handleFlipHorizontal}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 rounded-xl border border-zinc-800 text-xs transition"
            title="Mirror / Flip Horizontal"
          >
            <FlipHorizontal className="w-4 h-4" />
          </button>

          {/* Open Photo */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center space-x-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 px-3 py-1.5 rounded-xl text-xs font-medium border border-zinc-700 transition"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Open</span>
          </button>

          {/* Before / After */}
          <button
            onClick={() => setShowBeforeAfter(!showBeforeAfter)}
            className={`flex items-center space-x-1 px-3 py-1.5 rounded-xl text-xs font-medium border transition ${
              showBeforeAfter
                ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300'
                : 'border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Before / After</span>
          </button>

          {/* Save / Export Button */}
          <button
            onClick={() => setShowExportDrawer(!showExportDrawer)}
            className="flex items-center space-x-1.5 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-black font-bold px-3 sm:px-4 py-1.5 rounded-xl text-xs transition shadow-md shadow-emerald-500/20"
          >
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Image Cropping Drawer */}
      {isCropOpen && (
        <div className="bg-zinc-950 border border-amber-500/50 rounded-2xl p-4 shadow-2xl space-y-3">
          <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2">
            <div className="flex items-center space-x-2 text-amber-400">
              <Crop className="w-4 h-4" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Crop to Social & Photography Aspect Ratios
              </h3>
            </div>
            <button onClick={() => setIsCropOpen(false)} className="text-xs text-zinc-500 hover:text-white">
              Close
            </button>
          </div>

          <p className="text-[11px] text-zinc-400 leading-relaxed">
            Select an aspect ratio preset to crop the image center with high-precision pixel rendering:
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {[
              { id: '1:1', label: '1:1 Square', desc: 'Instagram Feed / Avatar' },
              { id: '4:5', label: '4:5 Portrait', desc: 'Instagram Post' },
              { id: '9:16', label: '9:16 Vertical', desc: 'Reels, TikTok & Story' },
              { id: '16:9', label: '16:9 Wide', desc: 'YouTube & Desktop' },
              { id: '3:2', label: '3:2 Classic', desc: 'DSLR Photography' }
            ].map((ratio) => (
              <button
                key={ratio.id}
                onClick={() => handleApplyCrop(ratio.id as any)}
                className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-amber-400/80 hover:bg-zinc-850 text-left transition group space-y-1"
              >
                <div className="text-xs font-bold text-white group-hover:text-amber-300">{ratio.label}</div>
                <div className="text-[10px] text-zinc-400">{ratio.desc}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Photo Export Drawer */}
      {showExportDrawer && (
        <div className="bg-zinc-950 border border-emerald-500/50 rounded-2xl p-4 shadow-2xl space-y-3">
          <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2">
            <div className="flex items-center space-x-2 text-emerald-400">
              <Download className="w-4 h-4" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Export Photo Options
              </h3>
            </div>
            <button onClick={() => setShowExportDrawer(false)} className="text-xs text-zinc-500 hover:text-white">
              Close
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            {/* Format */}
            <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800 space-y-1.5">
              <label className="text-[11px] font-semibold text-zinc-300 block">File Format:</label>
              <div className="flex space-x-1.5">
                {(['png', 'jpeg', 'webp'] as const).map((fmt) => (
                  <button
                    key={fmt}
                    onClick={() => setExportFormat(fmt)}
                    className={`flex-1 py-1 rounded text-xs font-bold uppercase transition ${
                      exportFormat === fmt
                        ? 'bg-emerald-500 text-black shadow'
                        : 'bg-zinc-800 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {fmt}
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-zinc-500">
                {exportFormat === 'png'
                  ? 'Lossless with transparency'
                  : exportFormat === 'jpeg'
                  ? 'Standard photo format'
                  : 'Modern high compression'}
              </p>
            </div>

            {/* Quality Slider */}
            {exportFormat !== 'png' && (
              <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800 space-y-1.5">
                <div className="flex justify-between text-zinc-300 font-semibold">
                  <span>Compression Quality</span>
                  <span className="font-mono text-cyan-400">{Math.round(exportQuality * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0.6"
                  max="1.0"
                  step="0.05"
                  value={exportQuality}
                  onChange={(e) => setExportQuality(Number(e.target.value))}
                  className="w-full accent-emerald-400"
                />
              </div>
            )}

            {/* Download Trigger */}
            <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800 flex flex-col justify-between">
              <div className="text-[11px] text-zinc-400">
                Output: <strong>{imageDimensions.width} × {imageDimensions.height} px</strong>
              </div>
              <button
                onClick={handleDownload}
                className="w-full py-2 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-black font-extrabold text-xs rounded-xl shadow-lg transition mt-2 flex items-center justify-center space-x-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save to Device</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Photo Canvas Viewport */}
      <div className="relative w-full flex items-center justify-center p-4 min-h-[340px] max-h-[520px] bg-black/90 rounded-2xl border border-zinc-800 shadow-2xl overflow-hidden">
        {/* Rendered Canvas */}
        <canvas
          ref={canvasRef}
          className="max-h-[480px] max-w-full rounded-lg shadow-2xl object-contain border border-zinc-800"
        />

        {/* Split Before/After Interactive Slider */}
        {showBeforeAfter && originalImageRef.current && (
          <div className="absolute inset-4 overflow-hidden pointer-events-none flex items-center justify-center">
            {/* Original overlay clipped by slider */}
            <div
              className="absolute inset-0 overflow-hidden"
              style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
            >
              <img
                src={originalImageRef.current.src}
                alt="Original Before"
                className="w-full h-full object-contain pointer-events-none"
              />
              <div className="absolute top-2 left-2 bg-black/80 text-white text-[10px] px-2 py-0.5 rounded font-mono border border-white/20">
                BEFORE (ORIGINAL)
              </div>
            </div>

            <div
              className="absolute inset-0 overflow-hidden"
              style={{ clipPath: `inset(0 0 0 ${sliderPosition}%)` }}
            >
              <div className="absolute top-2 right-2 bg-cyan-950/80 text-cyan-300 text-[10px] px-2 py-0.5 rounded font-mono border border-cyan-500/30">
                AFTER (EDITED)
              </div>
            </div>

            {/* Draggable Divider Line */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-white pointer-events-auto cursor-ew-resize shadow-[0_0_10px_white]"
              style={{ left: `${sliderPosition}%` }}
              onMouseDown={(e) => {
                const onMouseMove = (ev: MouseEvent) => {
                  const rect = e.currentTarget.parentElement?.getBoundingClientRect();
                  if (!rect) return;
                  const pos = ((ev.clientX - rect.left) / rect.width) * 100;
                  setSliderPosition(Math.max(5, Math.min(95, pos)));
                };
                const onMouseUp = () => {
                  window.removeEventListener('mousemove', onMouseMove);
                  window.removeEventListener('mouseup', onMouseUp);
                };
                window.addEventListener('mousemove', onMouseMove);
                window.addEventListener('mouseup', onMouseUp);
              }}
              onTouchStart={(e) => {
                const onTouchMove = (ev: TouchEvent) => {
                  const touch = ev.touches[0];
                  if (!touch) return;
                  const rect = e.currentTarget.parentElement?.getBoundingClientRect();
                  if (!rect) return;
                  const pos = ((touch.clientX - rect.left) / rect.width) * 100;
                  setSliderPosition(Math.max(5, Math.min(95, pos)));
                };
                const onTouchEnd = () => {
                  window.removeEventListener('touchmove', onTouchMove);
                  window.removeEventListener('touchend', onTouchEnd);
                };
                window.addEventListener('touchmove', onTouchMove);
                window.addEventListener('touchend', onTouchEnd);
              }}
            >
              <div className="w-6 h-6 bg-white text-black rounded-full -ml-[11px] mt-[180px] flex items-center justify-center text-[10px] font-bold shadow-lg touch-none">
                ⇄
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Quick Sample Selector */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs text-zinc-400 no-scrollbar">
        <span className="shrink-0 text-[11px] text-zinc-500 font-semibold">Try Sample Photos:</span>
        {SAMPLE_PHOTOS.map((sample) => (
          <button
            key={sample.id}
            onClick={() => {
              setImageSrc(sample.url);
              setSettings(DEFAULT_SETTINGS);
            }}
            className={`shrink-0 flex items-center space-x-1.5 px-2.5 py-1 rounded-lg border text-xs transition ${
              imageSrc === sample.url
                ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300'
                : 'border-zinc-800 bg-zinc-900 hover:border-zinc-700 text-zinc-300'
            }`}
          >
            <span>{sample.type === 'portrait' ? '👤' : sample.type === 'cyber' ? '⚡' : '🌄'}</span>
            <span>{sample.name}</span>
          </button>
        ))}
      </div>

      {/* AI Portrait & Background Removal Tools */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* AI Background Cutout & Replacement Box */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
            <div className="flex items-center space-x-2">
              <Scissors className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-bold text-white tracking-wide">AI BACKGROUND CUTOUT & REPLACEMENT</h3>
            </div>
            <button
              onClick={() => setSettings({ ...settings, removeBackground: !settings.removeBackground })}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                settings.removeBackground
                  ? 'bg-cyan-500 text-black shadow-md shadow-cyan-500/20'
                  : 'bg-zinc-800 text-zinc-400 hover:text-white'
              }`}
            >
              {settings.removeBackground ? 'Active' : 'Turn On'}
            </button>
          </div>

          <p className="text-[11px] text-zinc-400">
            Free edge & luminance segmentation extracts subject and isolates background on your phone without server upload.
          </p>

          {/* Replacement Background Choices */}
          {settings.removeBackground && (
            <div className="space-y-2 pt-1">
              <label className="text-[11px] font-semibold text-zinc-300 block">Replace Background With:</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'transparent', name: 'Transparent PNG' },
                  { id: 'studio', name: 'Studio Gradient' },
                  { id: 'cyber', name: 'Cyber Neon Grid' },
                  { id: 'gradient', name: 'Sunset Glow' },
                  { id: 'nature', name: 'Nature Forest' }
                ].map((bg) => (
                  <button
                    key={bg.id}
                    onClick={() => setSettings({ ...settings, bgReplacementType: bg.id as any })}
                    className={`p-2 rounded-lg border text-center text-xs transition ${
                      settings.bgReplacementType === bg.id
                        ? 'border-cyan-400 bg-cyan-950/40 text-white font-medium'
                        : 'border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {bg.name}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Portrait Bokeh Depth Blur (f/1.4 Simulator) */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
            <div className="flex items-center space-x-2">
              <Disc className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-bold text-white tracking-wide">PORTRAIT BOKEH DEPTH (F/1.4 LENS)</h3>
            </div>
            <span className="font-mono text-xs text-amber-400">{settings.bokehBlur}%</span>
          </div>

          <p className="text-[11px] text-zinc-400">
            Simulates DSLR portrait lens aperture: keeps center subject in sharp focus while creating creamy background blur.
          </p>

          <div className="space-y-3 pt-1">
            <div>
              <div className="flex justify-between text-xs text-zinc-400 mb-1">
                <span>Blur Strength (Aperture)</span>
                <span>{settings.bokehBlur > 0 ? `f/1.${Math.max(2, 8 - Math.round(settings.bokehBlur / 15))}` : 'Off'}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.bokehBlur}
                onChange={(e) => setSettings({ ...settings, bokehBlur: Number(e.target.value) })}
                className="w-full accent-amber-400 bg-zinc-800 h-1.5 rounded appearance-none"
              />
            </div>

            {settings.bokehBlur > 0 && (
              <div>
                <div className="flex justify-between text-xs text-zinc-400 mb-1">
                  <span>Focal Circle Radius</span>
                  <span>{settings.bokehRadius}%</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="80"
                  value={settings.bokehRadius}
                  onChange={(e) => setSettings({ ...settings, bokehRadius: Number(e.target.value) })}
                  className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded appearance-none"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 1-Tap AI Auto-Enhance & Color Adjustments */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-2 flex-wrap gap-2">
          <div className="flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-white tracking-wide">COLOR ADJUSTMENTS & TONE MAPPING</h3>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setSettings({ ...settings, autoEnhanced: !settings.autoEnhanced })}
              className={`flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-semibold transition ${
                settings.autoEnhanced
                  ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-black shadow-md shadow-cyan-500/20'
                  : 'bg-zinc-800 text-zinc-300 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{settings.autoEnhanced ? 'AI Enhanced (Active)' : '1-Tap AI Auto-Enhance'}</span>
            </button>

            <button
              onClick={handleReset}
              className="text-xs text-zinc-400 hover:text-white transition px-2 py-1"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <div className="flex justify-between text-xs text-zinc-400 mb-1">
              <span>Brightness</span>
              <span className="font-mono">{settings.brightness}</span>
            </div>
            <input
              type="range"
              min="-60"
              max="60"
              value={settings.brightness}
              onChange={(e) => setSettings({ ...settings, brightness: Number(e.target.value) })}
              className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded appearance-none"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs text-zinc-400 mb-1">
              <span>Contrast</span>
              <span className="font-mono">{settings.contrast}</span>
            </div>
            <input
              type="range"
              min="-60"
              max="60"
              value={settings.contrast}
              onChange={(e) => setSettings({ ...settings, contrast: Number(e.target.value) })}
              className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded appearance-none"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs text-zinc-400 mb-1">
              <span>Saturation</span>
              <span className="font-mono">{settings.saturation}</span>
            </div>
            <input
              type="range"
              min="-100"
              max="100"
              value={settings.saturation}
              onChange={(e) => setSettings({ ...settings, saturation: Number(e.target.value) })}
              className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded appearance-none"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs text-zinc-400 mb-1">
              <span>Temperature</span>
              <span className="font-mono">{settings.temperature}</span>
            </div>
            <input
              type="range"
              min="-100"
              max="100"
              value={settings.temperature}
              onChange={(e) => setSettings({ ...settings, temperature: Number(e.target.value) })}
              className="w-full accent-amber-400 bg-zinc-800 h-1.5 rounded appearance-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
