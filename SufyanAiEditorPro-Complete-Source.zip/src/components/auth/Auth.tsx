import React, { useState, useEffect } from 'react';
import {
  User,
  Mail,
  Lock,
  Phone,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  ExternalLink,
  LogOut,
  Sparkles,
  Smartphone,
  Info,
  X,
  RefreshCw,
  FolderGit2
} from 'lucide-react';
import { UserProfile } from '../../types/auth';

interface AuthProps {
  currentUser: UserProfile | null;
  onUpdateUser: (user: UserProfile | null) => void;
  onClose?: () => void;
  isModal?: boolean;
}

type AuthMode = 'login' | 'signup' | 'phone_otp' | 'forgot_password' | 'provider_docs' | 'profile';

export const Auth: React.FC<AuthProps> = ({
  currentUser,
  onUpdateUser,
  onClose,
  isModal = false
}) => {
  const [mode, setMode] = useState<AuthMode>(currentUser ? 'profile' : 'login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [countryCode, setCountryCode] = useState('+1');
  const [otpCode, setOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Sync mode if currentUser changes
  useEffect(() => {
    if (currentUser) {
      setMode('profile');
    }
  }, [currentUser]);

  // Handle standard Email & Password Sign In
  const handleEmailSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setMessage({ type: 'error', text: 'Please fill in both email and password.' });
      return;
    }
    setLoading(true);
    setMessage(null);

    setTimeout(() => {
      setLoading(false);
      const user: UserProfile = {
        id: 'usr_' + Math.random().toString(36).substring(2, 9),
        name: email.split('@')[0],
        email: email,
        avatarUrl: '/logo.png',
        provider: 'email',
        createdAt: Date.now() - 86400000 * 3,
        lastLoginAt: Date.now(),
        plan: 'free_pro',
        cloudSyncEnabled: true,
        projectsCount: 1
      };
      localStorage.setItem('sufyan_auth_user', JSON.stringify(user));
      onUpdateUser(user);
      setMessage({ type: 'success', text: 'Welcome back! Signed in successfully.' });
      setMode('profile');
    }, 600);
  };

  // Handle Sign Up
  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || !name) {
      setMessage({ type: 'error', text: 'Please complete all required fields.' });
      return;
    }
    if (password.length < 6) {
      setMessage({ type: 'error', text: 'Password must be at least 6 characters long.' });
      return;
    }
    setLoading(true);
    setMessage(null);

    setTimeout(() => {
      setLoading(false);
      const user: UserProfile = {
        id: 'usr_' + Math.random().toString(36).substring(2, 9),
        name: name,
        email: email,
        avatarUrl: '/logo.png',
        provider: 'email',
        createdAt: Date.now(),
        lastLoginAt: Date.now(),
        plan: 'free_pro',
        cloudSyncEnabled: true,
        projectsCount: 0
      };
      localStorage.setItem('sufyan_auth_user', JSON.stringify(user));
      onUpdateUser(user);
      setMessage({ type: 'success', text: 'Account created! SUFYAN AI EDITOR PRO is ready.' });
      setMode('profile');
    }, 650);
  };

  // Handle Phone OTP Flow
  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || phoneNumber.length < 7) {
      setMessage({ type: 'error', text: 'Please enter a valid phone number.' });
      return;
    }
    setLoading(true);
    setMessage(null);

    setTimeout(() => {
      setLoading(false);
      setOtpSent(true);
      setMessage({
        type: 'info',
        text: `Demo OTP sent to ${countryCode} ${phoneNumber}. (For testing, enter 123456 or your carrier code).`
      });
    }, 700);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpCode.length < 6) {
      setMessage({ type: 'error', text: 'Please enter a 6-digit OTP code.' });
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const user: UserProfile = {
        id: 'usr_phone_' + Math.random().toString(36).substring(2, 9),
        name: `User ${phoneNumber.slice(-4)}`,
        email: `${phoneNumber}@sms.sufyan.local`,
        phone: `${countryCode} ${phoneNumber}`,
        avatarUrl: '/logo.png',
        provider: 'phone',
        createdAt: Date.now(),
        lastLoginAt: Date.now(),
        plan: 'free_pro',
        cloudSyncEnabled: true,
        projectsCount: 1
      };
      localStorage.setItem('sufyan_auth_user', JSON.stringify(user));
      onUpdateUser(user);
      setMessage({ type: 'success', text: 'Phone verified! Signed in.' });
      setMode('profile');
    }, 600);
  };

  // Handle Forgot Password
  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setMessage({ type: 'error', text: 'Enter your account email to receive a reset link.' });
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setMessage({
        type: 'success',
        text: `Password reset instructions have been dispatched to ${email}. Check your inbox or spam folder.`
      });
    }, 600);
  };

  // Handle Continue as Guest
  const handleContinueAsGuest = () => {
    const guestUser: UserProfile = {
      id: 'usr_guest',
      name: 'Local Guest Creator',
      email: 'guest@sufyan.device',
      avatarUrl: '/logo.png',
      provider: 'guest',
      createdAt: Date.now(),
      lastLoginAt: Date.now(),
      plan: 'free_pro',
      cloudSyncEnabled: false,
      projectsCount: 1
    };
    localStorage.setItem('sufyan_auth_user', JSON.stringify(guestUser));
    onUpdateUser(guestUser);
    if (onClose) onClose();
  };

  // Handle Sign Out
  const handleSignOut = () => {
    localStorage.removeItem('sufyan_auth_user');
    onUpdateUser(null);
    setMode('login');
    setMessage({ type: 'info', text: 'You have been signed out. Local projects remain intact.' });
  };

  return (
    <div className={`w-full bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden ${isModal ? 'max-w-lg mx-auto' : ''}`}>
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800/80 bg-zinc-900/60">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl border border-cyan-500/40 overflow-hidden bg-black flex items-center justify-center p-0.5 shadow-[0_0_12px_rgba(6,182,212,0.25)]">
            <img src="/logo.png" alt="SUFYAN AI" className="w-full h-full object-cover" />
          </div>
          <div>
            <h2 className="text-sm font-bold tracking-wider text-white flex items-center space-x-1.5">
              <span>SUFYAN AI STUDIO ID</span>
              <span className="text-[10px] bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-extrabold px-1.5 py-0.5 rounded">
                PRO
              </span>
            </h2>
            <p className="text-[11px] text-zinc-400">Unified Account • Multi-Device Sync</p>
          </div>
        </div>
        {isModal && onClose && (
          <button
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Notification Banner */}
      {message && (
        <div
          className={`px-6 py-2.5 text-xs flex items-center space-x-2 border-b ${
            message.type === 'success'
              ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
              : message.type === 'error'
              ? 'bg-red-950/40 border-red-500/30 text-red-300'
              : 'bg-cyan-950/40 border-cyan-500/30 text-cyan-300'
          }`}
        >
          {message.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      {/* Main Body */}
      <div className="p-6">
        {/* LOGGED IN PROFILE VIEW */}
        {mode === 'profile' && currentUser && (
          <div className="space-y-6">
            <div className="flex items-center space-x-4 p-4 rounded-xl bg-zinc-900 border border-zinc-800">
              <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-cyan-500/50 p-0.5 bg-black">
                <img
                  src={currentUser.avatarUrl || '/logo.png'}
                  alt={currentUser.name}
                  className="w-full h-full object-cover rounded-xl"
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2">
                  <h3 className="text-base font-bold text-white truncate">{currentUser.name}</h3>
                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-500/30">
                    {currentUser.provider}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 truncate">{currentUser.email}</p>
                <p className="text-[11px] text-zinc-500 mt-0.5">
                  Member since {new Date(currentUser.createdAt).toLocaleDateString()}
                </p>
              </div>
            </div>

            {/* Cloud Sync & Quota */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800/80">
                <div className="text-zinc-400 mb-1">Editing Plan</div>
                <div className="font-bold text-emerald-400 flex items-center space-x-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Free Pro Lifetime</span>
                </div>
                <div className="text-[10px] text-zinc-500 mt-1">Unlimited 4K & No Watermark</div>
              </div>

              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800/80">
                <div className="text-zinc-400 mb-1">Local Storage Backup</div>
                <div className="font-bold text-cyan-400 flex items-center space-x-1">
                  <FolderGit2 className="w-3.5 h-3.5" />
                  <span>Active & Saved</span>
                </div>
                <div className="text-[10px] text-zinc-500 mt-1">Persistent Browser DB</div>
              </div>
            </div>

            {/* Account Settings Actions */}
            <div className="space-y-2 pt-2">
              <button
                onClick={() => setMode('provider_docs')}
                className="w-full py-2.5 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs text-zinc-300 hover:text-white flex items-center justify-between transition"
              >
                <span className="flex items-center space-x-2">
                  <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Configure Google, Apple & Social OAuth</span>
                </span>
                <ExternalLink className="w-3.5 h-3.5 text-zinc-500" />
              </button>

              <button
                onClick={handleSignOut}
                className="w-full py-2.5 px-3 rounded-xl bg-red-950/20 hover:bg-red-950/40 border border-red-500/20 text-xs text-red-400 hover:text-red-300 flex items-center justify-center space-x-2 transition"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out from this Device</span>
              </button>
            </div>
          </div>
        )}

        {/* LOGIN FORM */}
        {mode === 'login' && (
          <div className="space-y-5">
            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">Sign In to SUFYAN AI PRO</h3>
              <p className="text-xs text-zinc-400">Sync projects, presets, and high-res video renders</p>
            </div>

            {/* Social / OAuth Placeholders with transparent info */}
            <div className="space-y-2.5">
              {/* Google Sign-in */}
              <button
                type="button"
                onClick={() => {
                  setMessage({
                    type: 'info',
                    text: 'Google Sign-In integration ready. To configure production OAuth credentials, click the Developer Setup guide below.'
                  });
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-white text-xs font-semibold flex items-center justify-center space-x-3 transition shadow-sm"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>

              {/* Apple Sign-in */}
              <button
                type="button"
                onClick={() => {
                  setMessage({
                    type: 'info',
                    text: 'Sign in with Apple requires Apple Developer Service ID and client secret server endpoint.'
                  });
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-white text-xs font-semibold flex items-center justify-center space-x-3 transition shadow-sm"
              >
                <svg className="w-4 h-4 fill-current shrink-0" viewBox="0 0 24 24">
                  <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.61-.75 1.04-1.8 0.92-2.87-.93.04-2.02.63-2.66 1.38-.56.65-1.06 1.71-.92 2.74 1.04.08 2.06-.52 2.66-1.25z" />
                </svg>
                <span>Continue with Apple</span>
              </button>
            </div>

            <div className="flex items-center my-3">
              <div className="flex-1 border-t border-zinc-800"></div>
              <span className="px-3 text-[11px] text-zinc-500 uppercase tracking-widest font-semibold">Or with Email</span>
              <div className="flex-1 border-t border-zinc-800"></div>
            </div>

            {/* Email & Password Form */}
            <form onSubmit={handleEmailSignIn} className="space-y-3.5">
              <div>
                <label className="text-xs font-semibold text-zinc-300 block mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-zinc-500 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="creator@example.com"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                    required
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-zinc-300">Password</label>
                  <button
                    type="button"
                    onClick={() => setMode('forgot_password')}
                    className="text-[11px] text-cyan-400 hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-zinc-500 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs shadow-lg shadow-cyan-500/20 transition flex items-center justify-center space-x-2"
              >
                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <span>Sign In</span>}
              </button>
            </form>

            {/* Quick Option Row: Phone OTP & Sign Up */}
            <div className="flex items-center justify-between text-xs pt-1 border-t border-zinc-800/80">
              <button
                type="button"
                onClick={() => setMode('phone_otp')}
                className="text-zinc-400 hover:text-cyan-400 flex items-center space-x-1"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Phone OTP</span>
              </button>

              <button
                type="button"
                onClick={() => setMode('signup')}
                className="text-zinc-300 hover:text-white font-semibold"
              >
                Create Account
              </button>
            </div>

            {/* Local Guest Mode - No mandatory account */}
            <div className="pt-2 border-t border-zinc-800/80">
              <button
                type="button"
                onClick={handleContinueAsGuest}
                className="w-full py-2 rounded-xl bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 text-xs text-zinc-400 hover:text-zinc-200 transition flex items-center justify-center space-x-2"
              >
                <span>Continue Editing Locally (No Account Required)</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Provider Docs Link */}
            <div className="text-center">
              <button
                type="button"
                onClick={() => setMode('provider_docs')}
                className="text-[11px] text-zinc-500 hover:text-zinc-400 underline underline-offset-2 flex items-center justify-center mx-auto space-x-1"
              >
                <Info className="w-3 h-3" />
                <span>OAuth provider setup & backend security guide</span>
              </button>
            </div>
          </div>
        )}

        {/* SIGN UP FORM */}
        {mode === 'signup' && (
          <div className="space-y-4">
            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">Create Pro Creator Account</h3>
              <p className="text-xs text-zinc-400">100% Free • Unlimited 4K Exports • Cloud Backup</p>
            </div>

            <form onSubmit={handleSignUp} className="space-y-3.5">
              <div>
                <label className="text-xs font-semibold text-zinc-300 block mb-1">Your Name</label>
                <div className="relative">
                  <User className="w-4 h-4 text-zinc-500 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Sufyan Gamer"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-zinc-300 block mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-zinc-500 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="sufyan@example.com"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-zinc-300 block mb-1">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-zinc-500 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="At least 6 characters"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                    required
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 text-[11px] text-zinc-400 space-y-1">
                <div className="flex items-center space-x-1.5 text-emerald-400 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Safe & Independent Processing</span>
                </div>
                <p>All video rendering happens directly on your device. We never sell your personal data or gameplay clips.</p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs shadow-lg shadow-cyan-500/20 transition flex items-center justify-center space-x-2"
              >
                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <span>Create Account</span>}
              </button>
            </form>

            <div className="text-center text-xs text-zinc-400 pt-1">
              <span>Already have an account? </span>
              <button
                type="button"
                onClick={() => setMode('login')}
                className="text-cyan-400 hover:underline font-semibold"
              >
                Sign In
              </button>
            </div>
          </div>
        )}

        {/* PHONE NUMBER OTP AUTHENTICATION */}
        {mode === 'phone_otp' && (
          <div className="space-y-4">
            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">Sign In with Phone OTP</h3>
              <p className="text-xs text-zinc-400">Receive a one-time SMS verification code</p>
            </div>

            {!otpSent ? (
              <form onSubmit={handleSendOtp} className="space-y-3.5">
                <div>
                  <label className="text-xs font-semibold text-zinc-300 block mb-1">Mobile Phone Number</label>
                  <div className="flex space-x-2">
                    <select
                      value={countryCode}
                      onChange={(e) => setCountryCode(e.target.value)}
                      className="bg-zinc-900 border border-zinc-800 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                    >
                      <option value="+1">+1 (US/CA)</option>
                      <option value="+44">+44 (UK)</option>
                      <option value="+91">+91 (IN)</option>
                      <option value="+92">+92 (PK)</option>
                      <option value="+971">+971 (UAE)</option>
                      <option value="+61">+61 (AU)</option>
                    </select>
                    <input
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="555 123 4567"
                      className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs shadow-md shadow-cyan-500/20 transition flex items-center justify-center space-x-2"
                >
                  {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <span>Send Verification Code</span>}
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-3.5">
                <div>
                  <label className="text-xs font-semibold text-zinc-300 block mb-1">Enter 6-Digit OTP</label>
                  <input
                    type="text"
                    maxLength={6}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    placeholder="123456"
                    className="w-full text-center tracking-widest text-lg font-mono bg-zinc-900 border border-zinc-800 rounded-xl py-2 px-3 text-white focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-black font-bold text-xs shadow-md transition flex items-center justify-center space-x-2"
                >
                  {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <span>Verify & Continue</span>}
                </button>

                <div className="text-center">
                  <button
                    type="button"
                    onClick={() => setOtpSent(false)}
                    className="text-xs text-zinc-400 hover:text-white"
                  >
                    Edit Phone Number
                  </button>
                </div>
              </form>
            )}

            <div className="text-center text-xs text-zinc-400 pt-2 border-t border-zinc-800/80">
              <button
                type="button"
                onClick={() => setMode('login')}
                className="text-cyan-400 hover:underline"
              >
                Return to Email Sign In
              </button>
            </div>
          </div>
        )}

        {/* FORGOT PASSWORD FORM */}
        {mode === 'forgot_password' && (
          <div className="space-y-4">
            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">Reset Account Password</h3>
              <p className="text-xs text-zinc-400">We will send instructions to your verified email</p>
            </div>

            <form onSubmit={handleResetPassword} className="space-y-3.5">
              <div>
                <label className="text-xs font-semibold text-zinc-300 block mb-1">Account Email</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-zinc-500 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="creator@example.com"
                    className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs shadow-md transition flex items-center justify-center space-x-2"
              >
                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <span>Send Reset Instructions</span>}
              </button>
            </form>

            <div className="text-center text-xs text-zinc-400 pt-2 border-t border-zinc-800/80">
              <button
                type="button"
                onClick={() => setMode('login')}
                className="text-cyan-400 hover:underline"
              >
                Back to Sign In
              </button>
            </div>
          </div>
        )}

        {/* PROVIDER CREDENTIALS & DEVELOPER DOCUMENTATION */}
        {mode === 'provider_docs' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
                <KeyRound className="w-4 h-4 text-cyan-400" />
                <span>OAuth & Security Requirements</span>
              </h3>
              <button
                onClick={() => setMode(currentUser ? 'profile' : 'login')}
                className="text-xs text-cyan-400 hover:underline"
              >
                Back
              </button>
            </div>

            <div className="space-y-3 text-xs text-zinc-300">
              <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-200">
                <p className="font-semibold mb-1">Zero Private Secrets on Frontend</p>
                <p className="text-[11px] leading-relaxed">
                  Never embed Google Client Secrets, Apple Private Keys, or Facebook App Secrets into client-side code. Secrets must remain on an authenticated server proxy.
                </p>
              </div>

              {/* Google */}
              <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800">
                <div className="font-bold text-white mb-1 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                  <span>Google Sign-In Configuration</span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  1. Visit <strong>Google Cloud Console</strong> &gt; APIs &amp; Services &gt; Credentials.<br />
                  2. Create an <strong>OAuth 2.0 Web Client ID</strong>.<br />
                  3. Add your app domain to <em>Authorized JavaScript origins</em>.<br />
                  4. Provide the public <code>client_id</code> to the client-side Google SDK.
                </p>
              </div>

              {/* Apple */}
              <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800">
                <div className="font-bold text-white mb-1 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-zinc-400"></span>
                  <span>Sign in with Apple Configuration</span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  1. Requires an active <strong>Apple Developer Account</strong> ($99/yr).<br />
                  2. Configure a <em>Services ID</em> with Sign in with Apple enabled.<br />
                  3. Create a private key (.p8) and store it securely on your server.<br />
                  4. Verify JWT identity tokens on your backend endpoint.
                </p>
              </div>

              {/* Facebook / Meta */}
              <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800">
                <div className="font-bold text-white mb-1 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                  <span>Facebook Login Configuration</span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  1. Go to <strong>Meta for Developers</strong> &gt; My Apps &gt; Create App.<br />
                  2. Add the Facebook Login product and configure Web OAuth redirect URIs.<br />
                  3. Exchange user access tokens for long-lived tokens securely on your backend.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
