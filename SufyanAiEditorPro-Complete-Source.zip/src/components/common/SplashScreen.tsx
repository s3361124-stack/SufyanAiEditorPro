import React, { useEffect, useState } from 'react';
import { Sparkles, Film, Smartphone } from 'lucide-react';

interface SplashScreenProps {
  onDismiss: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onDismiss }) => {
  const [fadeState, setFadeState] = useState<'in' | 'visible' | 'out'>('in');

  useEffect(() => {
    // Fade in
    const timer1 = setTimeout(() => setFadeState('visible'), 50);
    // Start fade out after 1.8s
    const timer2 = setTimeout(() => setFadeState('out'), 1800);
    // Dismiss completely after 2.2s
    const timer3 = setTimeout(() => onDismiss(), 2200);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [onDismiss]);

  return (
    <div
      onClick={onDismiss}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/95 backdrop-blur-xl transition-opacity duration-500 cursor-pointer select-none ${
        fadeState === 'out' ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background radial glow */}
      <div className="absolute w-[450px] h-[450px] bg-gradient-to-r from-purple-600/20 via-blue-600/20 to-cyan-500/20 rounded-full blur-3xl pointer-events-none animate-pulse" />

      {/* Center Mascot Container */}
      <div className="relative z-10 flex flex-col items-center text-center px-4">
        {/* Glowing Logo Frame */}
        <div className="relative w-32 h-32 sm:w-40 sm:h-40 rounded-3xl p-1 bg-gradient-to-tr from-purple-500 via-cyan-400 to-blue-500 shadow-[0_0_40px_rgba(168,85,247,0.5)] mb-6 animate-scaleIn">
          <div className="w-full h-full rounded-[22px] overflow-hidden bg-zinc-950 border-2 border-black/80">
            <img
              src="/logo.png"
              alt="SUFYAN AI EDITOR PRO"
              className="w-full h-full object-cover"
            />
          </div>
          {/* Subtle spark accent */}
          <div className="absolute -top-2 -right-2 p-1.5 rounded-full bg-cyan-400 text-black shadow-lg">
            <Sparkles className="w-4 h-4" />
          </div>
        </div>

        {/* Brand Title */}
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-wider bg-gradient-to-r from-white via-zinc-200 to-zinc-400 bg-clip-text text-transparent mb-1">
          SUFYAN AI EDITOR PRO
        </h1>

        <div className="flex items-center space-x-2 text-xs text-cyan-400 font-mono tracking-widest uppercase mb-4">
          <span>Cinema</span>
          <span>•</span>
          <span>Photo AI</span>
          <span>•</span>
          <span>Android Suite</span>
        </div>

        <p className="text-xs text-zinc-400 max-w-xs leading-relaxed">
          100% Free • On-Device Processing • Zero Watermarks
        </p>

        {/* Loading Bar */}
        <div className="w-48 h-1 bg-zinc-800 rounded-full mt-6 overflow-hidden">
          <div className="h-full bg-gradient-to-r from-cyan-400 to-purple-500 animate-[progress_1.8s_ease-in-out_infinite]" />
        </div>

        <span className="text-[10px] text-zinc-600 mt-3 font-mono">
          Tap anywhere to skip
        </span>
      </div>
    </div>
  );
};
