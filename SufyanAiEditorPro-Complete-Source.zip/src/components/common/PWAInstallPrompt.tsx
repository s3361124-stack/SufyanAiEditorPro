import React, { useEffect, useState } from 'react';
import { Download, Smartphone, CheckCircle, X } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PWAInstallPrompt: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showBanner, setShowBanner] = useState(true);
  const [showManualGuide, setShowManualGuide] = useState(false);

  useEffect(() => {
    // Check if already running in standalone mode (installed)
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleInstalled);
    };
  }, []);

  if (isInstalled || !showBanner) return null;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    } else {
      setShowManualGuide((prev) => !prev);
    }
  };

  return (
    <div className="bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-900 border-b border-zinc-700/60 px-4 py-2 text-xs text-zinc-200">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Smartphone className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>
            <strong className="text-white font-medium">Install on your Android Phone:</strong> Run in full screen without browser bars & edit offline!
          </span>
        </div>
        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={handleInstallClick}
            className="flex items-center space-x-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-semibold px-3 py-1 rounded-full text-xs transition shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Install App</span>
          </button>
          <button
            onClick={() => setShowBanner(false)}
            className="text-zinc-400 hover:text-white p-1"
            aria-label="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {showManualGuide && (
        <div className="mt-2 pt-2 border-t border-zinc-700/60 text-cyan-300 text-[11px] flex items-center justify-between">
          <span>
            💡 <strong>Android installation:</strong> Tap the 3 dots (⋮) in Chrome browser menu at the top right, then tap <em>"Install app"</em> or <em>"Add to Home screen"</em>.
          </span>
          <button
            onClick={() => setShowManualGuide(false)}
            className="text-zinc-400 hover:text-white text-[11px] underline ml-2"
          >
            Got it
          </button>
        </div>
      )}
    </div>
  );
};
