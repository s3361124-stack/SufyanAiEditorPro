import React, { useState } from 'react';
import {
  Tv,
  Film,
  Sparkles,
  Clapperboard,
  Sliders,
  Type,
  Music,
  Maximize2,
  Layers,
  ArrowRight
} from 'lucide-react';
import { VideoProject, AspectRatio, ColorGradeSettings, TextOverlay } from '../../types/editor';

interface EntertainmentStudioProps {
  project: VideoProject;
  onUpdateProject: (project: VideoProject) => void;
  onOpenTimeline: () => void;
}

export const EntertainmentStudio: React.FC<EntertainmentStudioProps> = ({
  project,
  onUpdateProject,
  onOpenTimeline
}) => {
  // Apply Film / Entertainment Preset
  const handleApplyCinemaPreset = (type: 'reels' | 'anamorphic' | 'noir' | 'vlog') => {
    let newAspectRatio: AspectRatio = project.aspectRatio;
    let newGrade: ColorGradeSettings = { ...project.colorGrade };
    let newOverlays = [...project.textOverlays];

    if (type === 'reels') {
      newAspectRatio = '9:16';
      newGrade = {
        preset: 'teal-orange',
        brightness: 5,
        contrast: 10,
        saturation: 15,
        temperature: 5,
        sharpness: 25,
        vignette: 15,
        filmGrain: 0,
        letterbox: false,
        letterboxHeight: 0
      };
      newOverlays.push({
        id: 'reels_txt_' + Date.now(),
        text: 'WAIT FOR THE END... 😱',
        type: 'caption',
        startTime: 0,
        endTime: 3.5,
        x: 50,
        y: 20,
        fontSize: 30,
        fontFamily: 'Montserrat',
        color: '#ffffff',
        backgroundColor: '#000000aa',
        align: 'center',
        animation: 'typewriter'
      });
    } else if (type === 'anamorphic') {
      newAspectRatio = '16:9';
      newGrade = {
        preset: 'teal-orange',
        brightness: -5,
        contrast: 20,
        saturation: 10,
        temperature: -5,
        sharpness: 30,
        vignette: 35,
        filmGrain: 15,
        letterbox: true,
        letterboxHeight: 12 // 2.39:1 scope
      };
      newOverlays.push({
        id: 'cinema_txt_' + Date.now(),
        text: 'A SUFYAN FILM',
        type: 'title',
        startTime: 0.5,
        endTime: 4.0,
        x: 50,
        y: 50,
        fontSize: 36,
        fontFamily: 'Times New Roman',
        color: '#f4f4f5',
        letterSpacing: 8,
        align: 'center',
        animation: 'fade'
      });
    } else if (type === 'noir') {
      newGrade = {
        preset: 'film-noir',
        brightness: -5,
        contrast: 40,
        saturation: -100,
        temperature: 0,
        sharpness: 30,
        vignette: 45,
        filmGrain: 25,
        letterbox: true,
        letterboxHeight: 10
      };
    } else if (type === 'vlog') {
      newGrade = {
        preset: 'golden-hour',
        brightness: 8,
        contrast: 8,
        saturation: 20,
        temperature: 15,
        sharpness: 15,
        vignette: 10,
        filmGrain: 0,
        letterbox: false,
        letterboxHeight: 0
      };
    }

    onUpdateProject({
      ...project,
      aspectRatio: newAspectRatio,
      colorGrade: newGrade,
      textOverlays: newOverlays
    });
  };

  return (
    <div className="w-full space-y-6 animate-fadeIn pb-8">
      {/* Studio Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-pink-500/30 bg-gradient-to-r from-pink-950/40 via-zinc-950 to-black p-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="text-[10px] bg-pink-500/20 text-pink-300 font-extrabold px-2.5 py-0.5 rounded-full border border-pink-500/40">
                TIKTOK • REELS • CINEMA
              </span>
              <span className="text-xs text-zinc-400">• Entertainment & Film Engine</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-white">
              ENTERTAINMENT & CINEMA STUDIO
            </h1>
            <p className="text-xs text-zinc-300 max-w-xl">
              Create viral 9:16 vertical reels, cinematic short film anamorphic scope, film grain, vintage 35mm, and movie titles.
            </p>
          </div>

          <button
            onClick={onOpenTimeline}
            className="py-2.5 px-5 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-400 hover:to-purple-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-pink-500/25 flex items-center space-x-2 transition shrink-0"
          >
            <Film className="w-4 h-4" />
            <span>Open Timeline</span>
          </button>
        </div>
      </div>

      {/* Preset Cinema Formats */}
      <div className="space-y-3">
        <h2 className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center space-x-2">
          <Clapperboard className="w-4 h-4 text-pink-400" />
          <span>One-Tap Cinematic Workflows</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          <div
            onClick={() => handleApplyCinemaPreset('reels')}
            className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-pink-400/80 cursor-pointer transition group"
          >
            <div className="font-bold text-pink-400 text-sm mb-1">
              TikTok & Reels Viral
            </div>
            <p className="text-[11px] text-zinc-400">
              9:16 vertical crop, hook subtitle overlay, punchy warm color grading.
            </p>
          </div>

          <div
            onClick={() => handleApplyCinemaPreset('anamorphic')}
            className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-cyan-400/80 cursor-pointer transition group"
          >
            <div className="font-bold text-cyan-400 text-sm mb-1">
              2.39:1 Anamorphic Scope
            </div>
            <p className="text-[11px] text-zinc-400">
              Hollywood cinema letterbox bars, teal-and-orange grading, subtle film grain.
            </p>
          </div>

          <div
            onClick={() => handleApplyCinemaPreset('noir')}
            className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-zinc-400/80 cursor-pointer transition group"
          >
            <div className="font-bold text-zinc-300 text-sm mb-1">
              Classic Film Noir
            </div>
            <p className="text-[11px] text-zinc-400">
              High-contrast monochrome black & white with deep shadows and heavy vintage grain.
            </p>
          </div>

          <div
            onClick={() => handleApplyCinemaPreset('vlog')}
            className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-amber-400/80 cursor-pointer transition group"
          >
            <div className="font-bold text-amber-400 text-sm mb-1">
              Golden Hour Travel Vlog
            </div>
            <p className="text-[11px] text-zinc-400">
              Warm sunlight tones, natural skin enhancement, and soft organic vignettes.
            </p>
          </div>
        </div>
      </div>

      {/* Cinematic Overlays & Letterbox Control */}
      <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Maximize2 className="w-4 h-4 text-pink-400" />
            <h3 className="text-sm font-bold text-white">Letterbox Bars & Film Grain</h3>
          </div>

          <label className="flex items-center space-x-2 cursor-pointer text-xs text-zinc-300">
            <input
              type="checkbox"
              checked={project.colorGrade.letterbox}
              onChange={(e) =>
                onUpdateProject({
                  ...project,
                  colorGrade: { ...project.colorGrade, letterbox: e.target.checked }
                })
              }
              className="accent-pink-500 rounded"
            />
            <span>Enable 2.39:1 Letterbox</span>
          </label>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <div className="flex justify-between text-zinc-300 mb-1">
              <span>Letterbox Height (%)</span>
              <span className="font-mono">{project.colorGrade.letterboxHeight}%</span>
            </div>
            <input
              type="range"
              min={5}
              max={25}
              disabled={!project.colorGrade.letterbox}
              value={project.colorGrade.letterboxHeight}
              onChange={(e) =>
                onUpdateProject({
                  ...project,
                  colorGrade: { ...project.colorGrade, letterboxHeight: Number(e.target.value) }
                })
              }
              className="w-full accent-pink-500 disabled:opacity-30"
            />
          </div>

          <div>
            <div className="flex justify-between text-zinc-300 mb-1">
              <span>35mm Film Grain Simulation</span>
              <span className="font-mono">{project.colorGrade.filmGrain}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={project.colorGrade.filmGrain}
              onChange={(e) =>
                onUpdateProject({
                  ...project,
                  colorGrade: { ...project.colorGrade, filmGrain: Number(e.target.value) }
                })
              }
              className="w-full accent-pink-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
