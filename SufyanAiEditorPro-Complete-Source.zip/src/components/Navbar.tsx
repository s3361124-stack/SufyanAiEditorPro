import React from 'react';
import {
  Film,
  Camera,
  Smartphone,
  Sparkles,
  Gamepad2,
  Tv,
  LayoutDashboard,
  User,
  ShieldCheck,
  Music
} from 'lucide-react';
import { UserProfile } from '../types/auth';

export type StudioTab = 'dashboard' | 'video' | 'gaming' | 'entertainment' | 'music' | 'photo' | 'android';

interface NavbarProps {
  currentTab: StudioTab;
  onSelectTab: (tab: StudioTab) => void;
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  currentUser,
  onOpenAuth
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-zinc-950/95 backdrop-blur-md border-b border-zinc-800/80 px-3 sm:px-5 py-2.5 shadow-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand & Logo */}
        <div
          onClick={() => onSelectTab('dashboard')}
          className="flex items-center space-x-2.5 cursor-pointer select-none group shrink-0"
        >
          <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl overflow-hidden border-2 border-purple-500/80 shadow-[0_0_12px_rgba(168,85,247,0.4)] group-hover:border-cyan-400 group-hover:shadow-[0_0_16px_rgba(56,189,248,0.5)] transition bg-zinc-950 shrink-0">
            <img
              src="/logo.png"
              alt="SUFYAN AI EDITOR PRO"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-extrabold tracking-wider text-sm bg-gradient-to-r from-white via-zinc-200 to-zinc-400 bg-clip-text text-transparent">
                SUFYAN
              </span>
              <span className="text-[10px] bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 text-black font-extrabold px-1.5 py-0.2 rounded shadow-sm">
                PRO
              </span>
            </div>
            <div className="text-[9px] sm:text-[10px] text-zinc-400 font-medium tracking-tight hidden xs:block">
              AI Video & Photo Studio
            </div>
          </div>
        </div>

        {/* Central Studio Tabs (Responsive overflow scroll for small mobile screens) */}
        <nav className="flex items-center space-x-1 bg-zinc-900/90 p-1 rounded-xl border border-zinc-800 text-xs font-semibold overflow-x-auto no-scrollbar max-w-[55vw] sm:max-w-none">
          {/* Dashboard Hub */}
          <button
            onClick={() => onSelectTab('dashboard')}
            className={`flex items-center space-x-1 px-2.5 py-1.5 rounded-lg transition shrink-0 ${
              currentTab === 'dashboard'
                ? 'bg-zinc-800 text-white shadow-sm ring-1 ring-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
            title="Studio Dashboard & Projects"
          >
            <LayoutDashboard className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="hidden md:inline">Dashboard</span>
          </button>

          {/* Video Editor */}
          <button
            onClick={() => onSelectTab('video')}
            className={`flex items-center space-x-1 px-2.5 py-1.5 rounded-lg transition shrink-0 ${
              currentTab === 'video'
                ? 'bg-zinc-800 text-white shadow-sm ring-1 ring-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
            title="Video Editor & Timeline"
          >
            <Film className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Video<span className="hidden lg:inline"> Editor</span></span>
          </button>

          {/* Gaming Studio */}
          <button
            onClick={() => onSelectTab('gaming')}
            className={`flex items-center space-x-1 px-2.5 py-1.5 rounded-lg transition shrink-0 ${
              currentTab === 'gaming'
                ? 'bg-zinc-800 text-white shadow-sm ring-1 ring-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
            title="PUBG / BGMI Gaming Studio"
          >
            <Gamepad2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
            <span>Gaming<span className="hidden lg:inline"> Studio</span></span>
          </button>

          {/* Entertainment & Reels */}
          <button
            onClick={() => onSelectTab('entertainment')}
            className={`flex items-center space-x-1 px-2.5 py-1.5 rounded-lg transition shrink-0 ${
              currentTab === 'entertainment'
                ? 'bg-zinc-800 text-white shadow-sm ring-1 ring-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
            title="TikTok & Reels Cinema"
          >
            <Tv className="w-3.5 h-3.5 text-pink-400 shrink-0" />
            <span className="hidden sm:inline">Cinema</span>
          </button>

          {/* Music Studio */}
          <button
            onClick={() => onSelectTab('music')}
            className={`flex items-center space-x-1 px-2.5 py-1.5 rounded-lg transition shrink-0 ${
              currentTab === 'music'
                ? 'bg-zinc-800 text-white shadow-sm ring-1 ring-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
            title="Music Studio, Beat Sequencer & Audio Mixer"
          >
            <Music className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Music<span className="hidden lg:inline"> Studio</span></span>
          </button>

          {/* Photo Studio */}
          <button
            onClick={() => onSelectTab('photo')}
            className={`flex items-center space-x-1 px-2.5 py-1.5 rounded-lg transition shrink-0 ${
              currentTab === 'photo'
                ? 'bg-zinc-800 text-white shadow-sm ring-1 ring-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
            title="Photo Studio & AI Retouch"
          >
            <Camera className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>Photo</span>
          </button>

          {/* Android APK & Source Tab (Highlighted with high contrast) */}
          <button
            onClick={() => onSelectTab('android')}
            className={`relative flex items-center space-x-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg transition shrink-0 ${
              currentTab === 'android'
                ? 'bg-gradient-to-r from-red-500/25 via-zinc-800 to-purple-500/25 text-white shadow-lg ring-2 ring-red-500/80 border border-red-500/50'
                : 'bg-zinc-800/90 text-white border-2 border-red-500/80 hover:border-red-400 shadow-[0_0_14px_rgba(239,68,68,0.35)]'
            }`}
            title="Download Android APK & Source Code"
          >
            <Smartphone className="w-3.5 h-3.5 text-red-400 shrink-0 animate-pulse" />
            <span className="font-bold text-white text-[11px] sm:text-xs">
              APK<span className="hidden lg:inline"> & Source</span>
            </span>
            <span className="bg-red-500 hover:bg-red-600 text-white text-[8px] sm:text-[9px] font-extrabold px-1.5 py-0.5 rounded-full uppercase tracking-wider shadow-sm">
              TAP
            </span>
          </button>
        </nav>

        {/* Right Section: Auth & Account */}
        <div className="flex items-center space-x-2 shrink-0">
          <button
            onClick={onOpenAuth}
            className="flex items-center space-x-2 py-1.5 px-2.5 sm:px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs text-zinc-300 hover:text-white transition group"
            title="Unified Account & Cloud Sync"
          >
            {currentUser ? (
              <>
                <div className="w-5 h-5 rounded-full overflow-hidden border border-cyan-400/60 bg-black shrink-0">
                  <img
                    src={currentUser.avatarUrl || '/logo.png'}
                    alt={currentUser.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className="font-bold text-cyan-300 text-[11px] max-w-[80px] truncate hidden sm:inline">
                  {currentUser.name}
                </span>
              </>
            ) : (
              <>
                <User className="w-3.5 h-3.5 text-cyan-400" />
                <span className="font-semibold text-[11px] hidden sm:inline">Sign In</span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
