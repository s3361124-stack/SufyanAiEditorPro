import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  FileCode,
  CheckCircle,
  Copy,
  ExternalLink,
  Terminal,
  Cloud,
  HelpCircle,
  Layers,
  Sparkles,
  Zap
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ANDROID_PROJECT_FILES, generateAndroidProjectZip } from '../../utils/androidProjectGenerator';

export const AndroidApkHub: React.FC = () => {
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [activeGuideTab, setActiveGuideTab] = useState<'pwa' | 'github' | 'termux'>('pwa');
  const [zipError, setZipError] = useState<string | null>(null);

  const activeFile = ANDROID_PROJECT_FILES[selectedFileIndex];

  const handleCopyCode = () => {
    if (!activeFile) return;
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    setZipError(null);
    try {
      const zipBlob = await generateAndroidProjectZip();
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'SufyanAiEditorPro-Android-Kotlin-Source.zip';
      a.click();

      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch (err) {
      setZipError('Error generating ZIP: ' + (err as Error).message);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="w-full flex flex-col space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 border border-zinc-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center space-x-3">
              <div className="relative w-12 h-12 rounded-2xl overflow-hidden border-2 border-purple-500 shadow-[0_0_16px_rgba(168,85,247,0.5)] shrink-0 bg-black">
                <img src="/logo.png" alt="SUFYAN PRO Logo" className="w-full h-full object-cover" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white tracking-wide">
                  ANDROID MOBILE APK & SOURCE CENTER
                </h2>
                <div className="text-[11px] text-cyan-400 font-mono">
                  Official Mascot & Full Android Launcher Icon Pack Included
                </div>
              </div>
            </div>
            <p className="text-xs text-zinc-400 max-w-2xl leading-relaxed">
              Complete Jetpack Compose & AndroidX Media3 source code for <strong>SUFYAN AI EDITOR PRO</strong> with your mascot launcher icons, adaptive mipmaps, plus 3 beginner-friendly methods to install or compile the APK directly using only your Android phone.
            </p>
          </div>

          {/* Dual Download Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
            <a
              href="/SufyanAiEditorPro-Complete-Source.zip"
              download="SufyanAiEditorPro-Complete-Source.zip"
              className="flex items-center justify-center space-x-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-extrabold px-4 py-3 rounded-xl shadow-lg shadow-emerald-500/20 transition text-xs"
              title="Download Complete Full-Stack Web + Android Studio Source ZIP (16 MB)"
            >
              <Download className="w-4 h-4" />
              <span>Full Studio & Android ZIP (16 MB)</span>
            </a>

            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="flex items-center justify-center space-x-2 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold px-4 py-3 rounded-xl shadow-lg shadow-cyan-500/20 transition text-xs shrink-0 disabled:opacity-50"
              title="Generate & Download Standalone Android Kotlin Studio Project"
            >
              <Download className="w-4 h-4" />
              <span>{isZipping ? 'Generating...' : 'Android Kotlin Project (.ZIP)'}</span>
            </button>
          </div>
        </div>

        {zipError && (
          <div className="mt-3 p-3 bg-red-950/80 border border-red-500/50 rounded-xl text-red-300 text-xs flex items-center justify-between">
            <span>{zipError}</span>
            <button onClick={() => setZipError(null)} className="text-red-400 hover:text-white font-bold ml-2">
              Dismiss
            </button>
          </div>
        )}
      </div>

      {/* 3 Mobile-Only Build Guides for Beginners */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 shadow-xl space-y-5">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3 flex-wrap gap-2">
          <div className="flex items-center space-x-2">
            <HelpCircle className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white tracking-wide">
              HOW TO INSTALL & BUILD ON AN ANDROID PHONE (NO COMPUTER)
            </h3>
          </div>

          {/* Guide Method Switcher */}
          <div className="flex items-center space-x-1 bg-zinc-900 p-1 rounded-xl border border-zinc-800 text-xs">
            <button
              onClick={() => setActiveGuideTab('pwa')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                activeGuideTab === 'pwa'
                  ? 'bg-zinc-800 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Method 1: Instant 1-Tap (Fastest)
            </button>
            <button
              onClick={() => setActiveGuideTab('github')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                activeGuideTab === 'github'
                  ? 'bg-cyan-500/20 text-cyan-300 shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Method 2: Free Cloud APK
            </button>
            <button
              onClick={() => setActiveGuideTab('termux')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                activeGuideTab === 'termux'
                  ? 'bg-zinc-800 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Method 3: Termux On-Device
            </button>
          </div>
        </div>

        {/* Method 1: Instant PWA */}
        {activeGuideTab === 'pwa' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="p-4 rounded-xl bg-cyan-950/20 border border-cyan-500/20 text-xs text-zinc-300 space-y-2">
              <div className="font-bold text-white text-sm flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>Instant Android Installation (No compiling needed — Ready in 10 seconds!)</span>
              </div>
              <p>
                Because this app is a fully compliant Progressive Web Application (PWA), Android Chrome can install it as a standalone application directly on your phone's home screen.
              </p>
            </div>

            <ol className="space-y-3 text-xs text-zinc-300">
              <li className="flex items-start space-x-3 p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                <span className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-700 text-cyan-400 flex items-center justify-center font-bold shrink-0">
                  1
                </span>
                <div>
                  <strong className="text-white">Open in Chrome on your phone:</strong>
                  <p className="text-zinc-400 mt-0.5">
                    Open this app link in your Android Chrome or Samsung Internet browser.
                  </p>
                </div>
              </li>

              <li className="flex items-start space-x-3 p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                <span className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-700 text-cyan-400 flex items-center justify-center font-bold shrink-0">
                  2
                </span>
                <div>
                  <strong className="text-white">Tap the 3 dots (⋮) in Chrome:</strong>
                  <p className="text-zinc-400 mt-0.5">
                    Look at the top-right corner of Google Chrome and tap the three vertical dots.
                  </p>
                </div>
              </li>

              <li className="flex items-start space-x-3 p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                <span className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-700 text-cyan-400 flex items-center justify-center font-bold shrink-0">
                  3
                </span>
                <div>
                  <strong className="text-white">Tap "Install app" or "Add to Home screen":</strong>
                  <p className="text-zinc-400 mt-0.5">
                    Chrome will prompt you to install <strong>SUFYAN AI EDITOR PRO</strong>. Confirm and tap <strong>Add</strong>.
                  </p>
                </div>
              </li>

              <li className="flex items-start space-x-3 p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                <span className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-700 text-emerald-400 flex items-center justify-center font-bold shrink-0">
                  ✓
                </span>
                <div>
                  <strong className="text-emerald-400">Done!</strong>
                  <p className="text-zinc-400 mt-0.5">
                    The app icon appears on your home screen and launcher. It opens in fullscreen without browser navigation bars, works offline, and accesses your phone gallery!
                  </p>
                </div>
              </li>
            </ol>
          </div>
        )}

        {/* Method 2: GitHub Actions Free Cloud Build */}
        {activeGuideTab === 'github' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="p-4 rounded-xl bg-purple-950/20 border border-purple-500/20 text-xs text-zinc-300 space-y-2">
              <div className="font-bold text-white text-sm flex items-center space-x-2">
                <Cloud className="w-4 h-4 text-purple-400" />
                <span>Compile a Real .APK File for Free Using GitHub Actions (From Your Phone)</span>
              </div>
              <p>
                You don't need a computer! GitHub provides free Linux build servers with the Android SDK pre-installed. We have included an automated build file (<code>.github/workflows/android-build.yml</code>) inside the project ZIP.
              </p>
            </div>

            <ol className="space-y-3 text-xs text-zinc-300">
              <li className="flex items-start space-x-3 p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                <span className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-700 text-purple-400 flex items-center justify-center font-bold shrink-0">
                  1
                </span>
                <div>
                  <strong className="text-white">Download the Project ZIP:</strong>
                  <p className="text-zinc-400 mt-0.5">
                    Tap the <strong>"Full Studio & Android ZIP (16 MB)"</strong> or <strong>"Android Kotlin Project (.ZIP)"</strong> button at the top of this screen. The zip will save in your phone's <em>Download</em> folder.
                  </p>
                </div>
              </li>

              <li className="flex items-start space-x-3 p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                <span className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-700 text-purple-400 flex items-center justify-center font-bold shrink-0">
                  2
                </span>
                <div>
                  <strong className="text-white">Create a free GitHub repository:</strong>
                  <p className="text-zinc-400 mt-0.5">
                    Open <a href="https://github.com" target="_blank" rel="noreferrer" className="text-cyan-400 underline">github.com</a> on your phone browser, tap <strong>New Repository</strong>, and name it <code>SufyanAiEditorPro</code>.
                  </p>
                </div>
              </li>

              <li className="flex items-start space-x-3 p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                <span className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-700 text-purple-400 flex items-center justify-center font-bold shrink-0">
                  3
                </span>
                <div>
                  <strong className="text-white">Upload files and watch the build:</strong>
                  <p className="text-zinc-400 mt-0.5">
                    Upload the project files or push via git. Tap the <strong>Actions</strong> tab in your repository. GitHub automatically detects <code>.github/workflows/android-build.yml</code>, runs Gradle assembleDebug with JDK 17, and finishes in ~2 minutes!
                  </p>
                </div>
              </li>

              <li className="flex items-start space-x-3 p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                <span className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-700 text-emerald-400 flex items-center justify-center font-bold shrink-0">
                  4
                </span>
                <div>
                  <strong className="text-emerald-400">Download and Install the Real APK:</strong>
                  <p className="text-zinc-400 mt-0.5">
                    Under the completed GitHub Actions run, tap <strong>SufyanAiEditorPro-Debug-APK</strong> under Artifacts. Download and open <code>app-debug.apk</code> on your Android phone to install!
                  </p>
                </div>
              </li>
            </ol>
          </div>
        )}

        {/* Method 3: Termux on Phone */}
        {activeGuideTab === 'termux' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-zinc-300 space-y-2">
              <div className="font-bold text-white text-sm flex items-center space-x-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span>Compile Locally on Your Android Phone via Termux</span>
              </div>
              <p>
                If your phone has 4GB+ RAM and you want to compile directly on your phone's processor using command-line:
              </p>
            </div>

            <div className="space-y-2">
              <div className="text-xs font-semibold text-zinc-300">Run these commands in Termux on your phone:</div>
              <div className="bg-black/90 p-4 rounded-xl border border-zinc-800 font-mono text-xs text-emerald-400 space-y-1 overflow-x-auto">
                <div># 1. Update packages and install OpenJDK 17</div>
                <div className="text-white">pkg update && pkg install openjdk-17 git unzip -y</div>
                <div className="mt-2 text-zinc-500"># 2. Extract your downloaded project zip</div>
                <div className="text-white">unzip /sdcard/Download/SufyanAiEditorPro-Android-Kotlin-Source.zip -d sufyan_editor</div>
                <div className="text-white">cd sufyan_editor</div>
                <div className="mt-2 text-zinc-500"># 3. Compile the debug APK</div>
                <div className="text-white">./gradlew assembleDebug</div>
                <div className="mt-2 text-zinc-500"># 4. Your APK will be located at:</div>
                <div className="text-cyan-400">app/build/outputs/apk/debug/app-debug.apk</div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Interactive Android Kotlin Source Code Browser */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3 flex-wrap gap-2">
          <div className="flex items-center space-x-2">
            <FileCode className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white tracking-wide">
              KOTLIN & JETPACK COMPOSE SOURCE CODE EXPLORER
            </h3>
          </div>

          <button
            onClick={handleCopyCode}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 rounded-xl text-xs font-medium transition"
          >
            {copied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy File'}</span>
          </button>
        </div>

        {/* File Tabs */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-2 text-xs">
          {ANDROID_PROJECT_FILES.map((file, idx) => (
            <button
              key={file.path}
              onClick={() => setSelectedFileIndex(idx)}
              className={`shrink-0 px-3 py-1.5 rounded-lg border font-mono transition ${
                selectedFileIndex === idx
                  ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300 font-semibold'
                  : 'border-zinc-800 bg-zinc-900 text-zinc-400 hover:text-white'
              }`}
            >
              {file.path.split('/').pop()}
            </button>
          ))}
        </div>

        {/* Current File Path */}
        <div className="text-[11px] font-mono text-zinc-500 bg-zinc-900/60 px-3 py-1.5 rounded-lg border border-zinc-800/80">
          Path: <span className="text-zinc-300">{activeFile?.path}</span>
        </div>

        {/* Code Content Viewer */}
        <div className="bg-black/80 border border-zinc-800 rounded-xl p-4 overflow-x-auto max-h-[460px] font-mono text-xs text-zinc-200 leading-relaxed">
          <pre>{activeFile?.content}</pre>
        </div>
      </div>
    </div>
  );
};
