import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  Square,
  Upload,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sliders,
  Trash2,
  Sparkles,
  RotateCcw,
  Download,
  Scissors,
  Radio,
  Clock,
  Layers,
  Film,
  Zap,
  CheckCircle,
  AlertCircle,
  Music,
  Plus,
  Activity
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { DrumInstrument, DrumPattern, MusicTrack, MasterFxSettings } from '../../types/music';
import { VideoProject, AudioTrack } from '../../types/editor';
import {
  getAudioContext,
  playSynthesizedDrum,
  decodeAudioFile,
  createReverbImpulse,
  renderMusicMixdown
} from '../../utils/audioEngine';
import { BUILTIN_AUDIO_LIST, generateBuiltinAudio } from '../../utils/audioSynthesis';

interface MusicStudioProps {
  videoProject: VideoProject;
  onSendToVideoProject: (audioTrack: AudioTrack) => void;
  onOpenVideoEditor: () => void;
}

const DEFAULT_DRUM_PATTERN: DrumPattern = {
  kick:    [true, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false],
  snare:   [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
  hihat:   [true, false, true, false, true, false, true, false, true, false, true, false, true, false, true, false],
  openhat: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, true, false],
  clap:    [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
  bass808: [true, false, false, true, false, false, true, false, false, false, true, false, false, true, false, false]
};

const PRESET_PATTERNS: Record<string, { name: string; bpm: number; pattern: DrumPattern }> = {
  trap: {
    name: '🔥 Trap / BGMI Hype',
    bpm: 140,
    pattern: {
      kick:    [true, false, false, false, false, false, true, false, false, false, true, false, false, false, false, false],
      snare:   [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
      hihat:   [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
      openhat: [false, false, true, false, false, false, false, false, false, false, true, false, false, false, false, false],
      clap:    [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
      bass808: [true, false, false, false, false, false, true, false, false, false, true, false, false, false, false, false]
    }
  },
  synthwave: {
    name: '⚡ Synthwave 4-on-Floor',
    bpm: 120,
    pattern: {
      kick:    [true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false],
      snare:   [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
      hihat:   [false, false, true, false, false, false, true, false, false, false, true, false, false, false, true, false],
      openhat: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
      clap:    [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
      bass808: [true, false, true, false, true, false, true, false, true, false, true, false, true, false, true, false]
    }
  },
  boombap: {
    name: '🎧 90s BoomBap Hip-Hop',
    bpm: 92,
    pattern: {
      kick:    [true, false, false, false, false, false, true, false, false, true, false, false, false, false, false, false],
      snare:   [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
      hihat:   [true, false, true, false, true, false, true, false, true, false, true, false, true, false, true, false],
      openhat: [false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false],
      clap:    [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
      bass808: [true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false]
    }
  },
  lofi: {
    name: '☕ Lofi Chill Beat',
    bpm: 80,
    pattern: {
      kick:    [true, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false],
      snare:   [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
      hihat:   [true, false, true, false, true, false, true, false, true, false, true, false, true, false, true, false],
      openhat: [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
      clap:    [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
      bass808: [true, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false]
    }
  }
};

const DRUM_NAMES: { id: DrumInstrument; label: string; color: string }[] = [
  { id: 'kick', label: 'KICK PUNCH', color: '#06b6d4' },
  { id: 'snare', label: 'CRISP SNARE', color: '#a855f7' },
  { id: 'hihat', label: 'CLOSED HAT', color: '#eab308' },
  { id: 'openhat', label: 'OPEN CYMBAL', color: '#f97316' },
  { id: 'clap', label: 'STUDIO CLAP', color: '#ec4899' },
  { id: 'bass808', label: '808 SUB BASS', color: '#ef4444' }
];

export const MusicStudio: React.FC<MusicStudioProps> = ({
  videoProject,
  onSendToVideoProject,
  onOpenVideoEditor
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Studio State
  const [bpm, setBpm] = useState(120);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [metronome, setMetronome] = useState(false);
  const [drumPattern, setDrumPattern] = useState<DrumPattern>(DEFAULT_DRUM_PATTERN);

  // Multitrack Audio Tracks
  const [tracks, setTracks] = useState<MusicTrack[]>([]);
  const [activeTrackId, setActiveTrackId] = useState<string | null>(null);

  // Master FX Rack
  const [masterFx, setMasterFx] = useState<MasterFxSettings>({
    volume: 0.9,
    reverbWet: 0.25,
    reverbDecay: 1.8,
    echoTime: 0.25,
    echoFeedback: 0.3,
    filterCutoff: 20000
  });

  // Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingTimerRef = useRef<number | null>(null);

  // User Error & Success Feedback
  const [errorNotice, setErrorNotice] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  // Mixdown export state
  const [isExportingMix, setIsExportingMix] = useState(false);
  const [mixdownResult, setMixdownResult] = useState<{ blob: Blob; url: string; duration: number } | null>(null);

  // Tap tempo helper
  const tapTimesRef = useRef<number[]>([]);

  // Web Audio Nodes Ref for live playback
  const liveAudioNodesRef = useRef<{
    sourceNodes: Map<string, AudioBufferSourceNode>;
    startTime: number;
    pauseOffset: number;
    convolverNode: ConvolverNode | null;
    delayNode: DelayNode | null;
    delayFeedback: GainNode | null;
    delayWetGain: GainNode | null;
    reverbWetGain: GainNode | null;
    masterGain: GainNode | null;
  }>({
    sourceNodes: new Map(),
    startTime: 0,
    pauseOffset: 0,
    convolverNode: null,
    delayNode: null,
    delayFeedback: null,
    delayWetGain: null,
    reverbWetGain: null,
    masterGain: null
  });

  // 1. Initialize Master Web Audio FX Graph
  const ensureMasterAudioGraph = () => {
    const ctx = getAudioContext();
    if (!liveAudioNodesRef.current.masterGain) {
      const masterGain = ctx.createGain();
      masterGain.gain.value = masterFx.volume;

      const convolver = ctx.createConvolver();
      convolver.buffer = createReverbImpulse(ctx, masterFx.reverbDecay, 2.0);

      const reverbWet = ctx.createGain();
      reverbWet.gain.value = masterFx.reverbWet;
      convolver.connect(reverbWet);
      reverbWet.connect(masterGain);

      const delay = ctx.createDelay(2.0);
      delay.delayTime.value = masterFx.echoTime;

      const delayFeedback = ctx.createGain();
      delayFeedback.gain.value = masterFx.echoFeedback;
      delay.connect(delayFeedback);
      delayFeedback.connect(delay);

      const delayWet = ctx.createGain();
      delayWet.gain.value = masterFx.echoFeedback > 0 ? 0.35 : 0;
      delay.connect(delayWet);
      delayWet.connect(masterGain);

      masterGain.connect(ctx.destination);

      liveAudioNodesRef.current.masterGain = masterGain;
      liveAudioNodesRef.current.convolverNode = convolver;
      liveAudioNodesRef.current.reverbWetGain = reverbWet;
      liveAudioNodesRef.current.delayNode = delay;
      liveAudioNodesRef.current.delayFeedback = delayFeedback;
      liveAudioNodesRef.current.delayWetGain = delayWet;
    }
    return liveAudioNodesRef.current;
  };

  // Sync master FX parameters live
  useEffect(() => {
    const graph = liveAudioNodesRef.current;
    if (graph.masterGain) graph.masterGain.gain.value = masterFx.volume;
    if (graph.reverbWetGain) graph.reverbWetGain.gain.value = masterFx.reverbWet;
    if (graph.delayNode) graph.delayNode.delayTime.value = masterFx.echoTime;
    if (graph.delayFeedback) graph.delayFeedback.gain.value = masterFx.echoFeedback;
    if (graph.delayWetGain) graph.delayWetGain.gain.value = masterFx.echoFeedback > 0 ? 0.35 : 0;
  }, [masterFx]);

  // 2. Drum Sequencer Clock Loop
  useEffect(() => {
    let intervalId: number | null = null;
    if (isPlaying) {
      const ctx = getAudioContext();
      ensureMasterAudioGraph();
      const sixteenthMs = ((60 / bpm) / 4) * 1000;

      intervalId = window.setInterval(() => {
        setCurrentStep((prevStep) => {
          const nextStep = (prevStep + 1) % 16;
          const graph = ensureMasterAudioGraph();

          // Metronome click on quarter notes (steps 0, 4, 8, 12)
          if (metronome && nextStep % 4 === 0) {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.frequency.value = nextStep === 0 ? 1200 : 800;
            gain.gain.setValueAtTime(0.3, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.06);
          }

          // Trigger Drum instruments active on this step
          (Object.keys(drumPattern) as DrumInstrument[]).forEach((inst) => {
            if (drumPattern[inst][nextStep] && graph.masterGain) {
              playSynthesizedDrum(ctx, graph.masterGain, inst, ctx.currentTime, 0.85);

              // Send to Reverb if snare/clap
              if (masterFx.reverbWet > 0 && graph.convolverNode && (inst === 'snare' || inst === 'clap')) {
                playSynthesizedDrum(ctx, graph.convolverNode, inst, ctx.currentTime, 0.35);
              }
              // Send to Echo if hihat
              if (masterFx.echoFeedback > 0 && graph.delayNode && inst === 'hihat') {
                playSynthesizedDrum(ctx, graph.delayNode, inst, ctx.currentTime, 0.25);
              }
            }
          });

          return nextStep;
        });
      }, sixteenthMs);
    }

    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [isPlaying, bpm, drumPattern, metronome, masterFx]);

  // 3. Play / Pause / Stop Multitrack Audio
  const handleTogglePlay = () => {
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    if (!isPlaying) {
      // Start multitrack playback
      startMultitrackPlayback();
      setIsPlaying(true);
    } else {
      stopMultitrackPlayback();
      setIsPlaying(false);
    }
  };

  const handleStop = () => {
    stopMultitrackPlayback();
    setIsPlaying(false);
    setCurrentStep(0);
  };

  const startMultitrackPlayback = () => {
    const ctx = getAudioContext();
    const graph = ensureMasterAudioGraph();
    stopMultitrackPlayback();

    const anySolo = tracks.some((t) => t.isSolo);

    tracks.forEach((track) => {
      if (!track.buffer) return;
      if (track.isMuted) return;
      if (anySolo && !track.isSolo) return;

      const source = ctx.createBufferSource();
      source.buffer = track.buffer;

      const gain = ctx.createGain();
      gain.gain.value = track.volume;

      const panner = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
      if (panner) panner.pan.value = track.pan;

      if (panner) {
        source.connect(gain);
        gain.connect(panner);
        if (graph.masterGain) panner.connect(graph.masterGain);
        if (track.reverbSend > 0 && graph.convolverNode) panner.connect(graph.convolverNode);
        if (track.echoSend > 0 && graph.delayNode) panner.connect(graph.delayNode);
      } else {
        source.connect(gain);
        if (graph.masterGain) gain.connect(graph.masterGain);
        if (track.reverbSend > 0 && graph.convolverNode) gain.connect(graph.convolverNode);
        if (track.echoSend > 0 && graph.delayNode) gain.connect(graph.delayNode);
      }

      const trimDuration = Math.max(0.1, track.trimEnd - track.trimStart);
      source.loop = true;
      source.loopStart = track.trimStart;
      source.loopEnd = track.trimEnd;

      source.start(0, track.trimStart);
      liveAudioNodesRef.current.sourceNodes.set(track.id, source);
    });
  };

  const stopMultitrackPlayback = () => {
    liveAudioNodesRef.current.sourceNodes.forEach((node) => {
      try {
        node.stop();
        node.disconnect();
      } catch (e) {}
    });
    liveAudioNodesRef.current.sourceNodes.clear();
  };

  // 4. File Import Handler
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorNotice(null);
    try {
      const ctx = getAudioContext();
      const decoded = await decodeAudioFile(file, ctx);

      const newTrack: MusicTrack = {
        id: 'track_' + Math.random().toString(36).substring(2, 9),
        name: file.name.replace(/\.[^/.]+$/, '').substring(0, 24),
        url: URL.createObjectURL(file),
        buffer: decoded.buffer,
        peaks: decoded.peaks,
        duration: decoded.buffer.duration,
        trimStart: 0,
        trimEnd: decoded.buffer.duration,
        volume: 0.85,
        pan: 0,
        isMuted: false,
        isSolo: false,
        reverbSend: 0.15,
        echoSend: 0,
        color: '#06b6d4'
      };

      setTracks((prev) => [...prev, newTrack]);
      setActiveTrackId(newTrack.id);
      setSuccessNotice(`Imported "${newTrack.name}" (${newTrack.duration.toFixed(1)}s)`);
    } catch (err) {
      setErrorNotice(`Could not decode audio file "${file.name}". Format may be unsupported or corrupted.`);
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // 5. Microphone Recording Handler
  const handleToggleRecord = async () => {
    setErrorNotice(null);

    if (isRecording) {
      // Stop recording
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      if (recordingTimerRef.current) {
        clearInterval(recordingTimerRef.current);
      }
      setIsRecording(false);
      return;
    }

    // Check microphone support
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setErrorNotice('Microphone recording is not supported in this browser or environment.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      const audioChunks: Blob[] = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunks.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
        stream.getTracks().forEach((track) => track.stop());

        try {
          const arrayBuf = await audioBlob.arrayBuffer();
          const ctx = getAudioContext();
          const buffer = await ctx.decodeAudioData(arrayBuf);
          const peaks = Array.from(buffer.getChannelData(0)).slice(0, 100).map(Math.abs);

          const newTrack: MusicTrack = {
            id: 'rec_' + Date.now(),
            name: `Mic Recording ${tracks.length + 1}`,
            url: URL.createObjectURL(audioBlob),
            buffer,
            peaks,
            duration: buffer.duration,
            trimStart: 0,
            trimEnd: buffer.duration,
            volume: 1.0,
            pan: 0,
            isMuted: false,
            isSolo: false,
            reverbSend: 0.2,
            echoSend: 0.1,
            color: '#ec4899'
          };

          setTracks((prev) => [...prev, newTrack]);
          setActiveTrackId(newTrack.id);
          setSuccessNotice(`Microphone recording saved (${buffer.duration.toFixed(1)}s)`);
        } catch (err) {
          setErrorNotice('Failed to process recorded audio data.');
        }
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);

      recordingTimerRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      setErrorNotice('Microphone access denied. Please grant microphone permission to record audio.');
      setIsRecording(false);
    }
  };

  // 6. Add Built-in Synthesized Audio Track
  const handleAddBuiltinTrack = async (soundId: string) => {
    try {
      const audioUrl = await generateBuiltinAudio(soundId);
      const res = await fetch(audioUrl);
      const arrayBuf = await res.arrayBuffer();
      const ctx = getAudioContext();
      const buffer = await ctx.decodeAudioData(arrayBuf);
      const soundInfo = BUILTIN_AUDIO_LIST.find((s) => s.id === soundId);

      const newTrack: MusicTrack = {
        id: 'builtin_' + Date.now(),
        name: soundInfo?.name || 'Synthesizer Loop',
        url: audioUrl,
        buffer,
        peaks: Array.from(buffer.getChannelData(0)).slice(0, 100).map(Math.abs),
        duration: buffer.duration,
        trimStart: 0,
        trimEnd: buffer.duration,
        volume: 0.8,
        pan: 0,
        isMuted: false,
        isSolo: false,
        reverbSend: 0.1,
        echoSend: 0,
        color: '#a855f7'
      };

      setTracks((prev) => [...prev, newTrack]);
      setActiveTrackId(newTrack.id);
      setSuccessNotice(`Added "${newTrack.name}"`);
    } catch (err) {
      setErrorNotice('Failed to generate synthesized audio track.');
    }
  };

  // 7. Tap Tempo Calculator
  const handleTapTempo = () => {
    const now = Date.now();
    const taps = tapTimesRef.current;
    taps.push(now);
    if (taps.length > 5) taps.shift();

    if (taps.length >= 2) {
      const intervals = [];
      for (let i = 1; i < taps.length; i++) {
        intervals.push(taps[i] - taps[i - 1]);
      }
      const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
      if (avgInterval > 200 && avgInterval < 2000) {
        const calculatedBpm = Math.round(60000 / avgInterval);
        setBpm(Math.max(50, Math.min(220, calculatedBpm)));
      }
    }
  };

  // 8. Drum Step Toggle & Instrument Audition
  const handleToggleDrumStep = (instrument: DrumInstrument, stepIdx: number) => {
    setDrumPattern((prev) => {
      const updated = [...prev[instrument]];
      updated[stepIdx] = !updated[stepIdx];
      return { ...prev, [instrument]: updated };
    });
  };

  const handleAuditionDrum = (instrument: DrumInstrument) => {
    const ctx = getAudioContext();
    const graph = ensureMasterAudioGraph();
    if (graph.masterGain) {
      playSynthesizedDrum(ctx, graph.masterGain, instrument, ctx.currentTime, 0.9);
    }
  };

  // 9. Load Beat Preset
  const handleApplyPreset = (presetKey: string) => {
    const preset = PRESET_PATTERNS[presetKey];
    if (preset) {
      setBpm(preset.bpm);
      setDrumPattern(preset.pattern);
      setSuccessNotice(`Applied "${preset.name}" preset (${preset.bpm} BPM)`);
    }
  };

  // 10. Offline Mixdown & Export
  const handleExportMixdown = async () => {
    setIsExportingMix(true);
    setErrorNotice(null);
    setMixdownResult(null);

    try {
      const result = await renderMusicMixdown(tracks, drumPattern, bpm, masterFx, 4);
      setMixdownResult(result);
      setIsExportingMix(false);

      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch (err) {
      setIsExportingMix(false);
      setErrorNotice('Failed to render audio mixdown: ' + (err as Error).message);
    }
  };

  // 11. Send Music Mix into Video Project Timeline
  const handleSendToVideo = async () => {
    if (!mixdownResult) {
      try {
        const result = await renderMusicMixdown(tracks, drumPattern, bpm, masterFx, 4);
        const newVideoAudioTrack: AudioTrack = {
          id: 'audio_mix_' + Date.now(),
          name: `Music Studio Beat (${bpm} BPM)`,
          url: result.url,
          duration: result.duration,
          startTime: 0,
          volume: 1.0,
          fadeIn: 0.5,
          fadeOut: 0.5
        };
        onSendToVideoProject(newVideoAudioTrack);
        setSuccessNotice('Sent beat into Video Editor Timeline!');
        onOpenVideoEditor();
      } catch (err) {
        setErrorNotice('Could not send to video editor: ' + (err as Error).message);
      }
    } else {
      const newVideoAudioTrack: AudioTrack = {
        id: 'audio_mix_' + Date.now(),
        name: `Music Studio Beat (${bpm} BPM)`,
        url: mixdownResult.url,
        duration: mixdownResult.duration,
        startTime: 0,
        volume: 1.0,
        fadeIn: 0.5,
        fadeOut: 0.5
      };
      onSendToVideoProject(newVideoAudioTrack);
      setSuccessNotice('Sent beat into Video Editor Timeline!');
      onOpenVideoEditor();
    }
  };

  return (
    <div className="w-full space-y-5 animate-fadeIn pb-12">
      <input ref={fileInputRef} type="file" accept="audio/*" onChange={handleFileUpload} className="hidden" />

      {/* Studio Header Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-zinc-800 bg-gradient-to-r from-zinc-950 via-zinc-900 to-black p-5 sm:p-6 shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] bg-cyan-500/20 text-cyan-300 font-extrabold px-2.5 py-0.5 rounded-full border border-cyan-500/40">
                PRO AUDIO & BEAT ENGINE
              </span>
              <span className="text-xs text-zinc-400">• Web Audio API Studio</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight mt-1">
              MUSIC & AUDIO PRODUCTION STUDIO
            </h1>
            <p className="text-xs text-zinc-300 max-w-xl mt-1">
              Multitrack audio workstation, 16-step drum sequencer, real-time Reverb & Echo DSP effects, microphone recording, waveform trimming, and video timeline sync.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleExportMixdown}
              disabled={isExportingMix}
              className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-500/20 flex items-center space-x-2 transition disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isExportingMix ? 'Rendering WAV...' : 'Export Mixdown (.WAV)'}</span>
            </button>

            <button
              onClick={handleSendToVideo}
              className="px-3.5 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-bold text-xs rounded-xl flex items-center space-x-1.5 transition"
              title="Add this beat directly as background music in your Video Editor project"
            >
              <Film className="w-4 h-4 text-cyan-400" />
              <span>Add to Video Timeline</span>
            </button>
          </div>
        </div>

        {/* Notices */}
        {errorNotice && (
          <div className="mt-3 p-3 bg-red-950/80 border border-red-500/50 rounded-xl text-red-300 text-xs flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorNotice}</span>
            </div>
            <button onClick={() => setErrorNotice(null)} className="text-red-400 hover:text-white font-bold ml-2">
              Dismiss
            </button>
          </div>
        )}

        {successNotice && (
          <div className="mt-3 p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-xl text-emerald-300 text-xs flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successNotice}</span>
            </div>
            <button onClick={() => setSuccessNotice(null)} className="text-emerald-400 hover:text-white font-bold ml-2">
              Dismiss
            </button>
          </div>
        )}
      </div>

      {/* Master Transport & Tempo Control Bar */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 shadow-xl flex flex-wrap items-center justify-between gap-4">
        {/* Playback Controls */}
        <div className="flex items-center space-x-2">
          <button
            onClick={handleTogglePlay}
            className={`p-3 rounded-xl font-bold flex items-center justify-center transition shadow-lg ${
              isPlaying
                ? 'bg-amber-500 hover:bg-amber-400 text-black shadow-amber-500/20'
                : 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-cyan-500/20'
            }`}
            title={isPlaying ? 'Pause Studio (Space)' : 'Play Studio (Space)'}
          >
            {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
          </button>

          <button
            onClick={handleStop}
            className="p-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition"
            title="Stop & Reset"
          >
            <Square className="w-4 h-4 fill-current" />
          </button>

          {/* Bar / Beat Counter */}
          <div className="px-3.5 py-2 bg-zinc-900/90 border border-zinc-800 rounded-xl font-mono text-xs text-cyan-400 flex items-center space-x-2">
            <Clock className="w-3.5 h-3.5 text-zinc-500" />
            <span>BAR {Math.floor(currentStep / 4) + 1} : STEP {(currentStep % 4) + 1}</span>
          </div>

          {/* Metronome Toggle */}
          <button
            onClick={() => setMetronome(!metronome)}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 ${
              metronome
                ? 'bg-cyan-500/20 border border-cyan-500/50 text-cyan-300'
                : 'bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-400'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Click</span>
          </button>
        </div>

        {/* BPM & Tap Tempo */}
        <div className="flex items-center space-x-3 flex-wrap">
          <div className="flex items-center space-x-2 bg-zinc-900/90 border border-zinc-800 px-3 py-1.5 rounded-xl">
            <span className="text-xs font-bold text-zinc-400">TEMPO</span>
            <input
              type="range"
              min={50}
              max={200}
              value={bpm}
              onChange={(e) => setBpm(Number(e.target.value))}
              className="w-24 accent-cyan-400"
            />
            <span className="font-mono font-extrabold text-sm text-white w-12 text-right">{bpm} BPM</span>
          </div>

          <button
            onClick={handleTapTempo}
            className="px-3 py-2 bg-zinc-900 hover:bg-zinc-800 active:scale-95 border border-zinc-700 text-zinc-200 text-xs font-bold rounded-xl transition"
            title="Tap repeatedly to set tempo"
          >
            TAP TEMPO
          </button>
        </div>

        {/* Quick Media Creation Buttons */}
        <div className="flex items-center space-x-2">
          {/* Audio File Import */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-3.5 py-2 bg-zinc-900 hover:bg-zinc-800 border border-cyan-500/40 text-cyan-300 font-semibold text-xs rounded-xl flex items-center space-x-1.5 transition"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import Audio</span>
          </button>

          {/* Microphone Record */}
          <button
            onClick={handleToggleRecord}
            className={`px-3.5 py-2 rounded-xl font-bold text-xs flex items-center space-x-1.5 transition ${
              isRecording
                ? 'bg-red-600 text-white animate-pulse'
                : 'bg-zinc-900 hover:bg-zinc-800 border border-red-500/50 text-red-400'
            }`}
          >
            {isRecording ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
            <span>{isRecording ? `Recording (${recordingSeconds}s)` : 'Record Mic'}</span>
          </button>
        </div>
      </div>

      {/* 16-Step Drum Sequencer */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800/80 pb-3">
          <div className="flex items-center space-x-2">
            <Radio className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm font-bold text-white tracking-wide uppercase">
              16-Step Drum Sequencer & Rhythm Matrix
            </h2>
          </div>

          {/* Preset Beat Patterns */}
          <div className="flex items-center space-x-1.5 overflow-x-auto no-scrollbar">
            <span className="text-[11px] text-zinc-500 font-semibold mr-1">Presets:</span>
            {Object.keys(PRESET_PATTERNS).map((key) => (
              <button
                key={key}
                onClick={() => handleApplyPreset(key)}
                className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-zinc-300 text-[11px] font-medium rounded-lg transition shrink-0"
              >
                {PRESET_PATTERNS[key].name}
              </button>
            ))}
            <button
              onClick={() =>
                setDrumPattern({
                  kick: Array(16).fill(false),
                  snare: Array(16).fill(false),
                  hihat: Array(16).fill(false),
                  openhat: Array(16).fill(false),
                  clap: Array(16).fill(false),
                  bass808: Array(16).fill(false)
                })
              }
              className="px-2 py-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-500 hover:text-red-400 text-[11px] font-medium rounded-lg transition shrink-0"
            >
              Clear
            </button>
          </div>
        </div>

        {/* 16-Step Grid */}
        <div className="space-y-2.5 overflow-x-auto pb-2">
          {DRUM_NAMES.map((drum) => {
            const steps = drumPattern[drum.id];
            return (
              <div key={drum.id} className="flex items-center space-x-2 min-w-[620px]">
                {/* Instrument Label & Audition Button */}
                <button
                  onClick={() => handleAuditionDrum(drum.id)}
                  style={{ borderColor: drum.color + '44' }}
                  className="w-28 sm:w-32 py-1.5 px-2 bg-zinc-900 hover:bg-zinc-800/90 border rounded-xl text-[11px] font-bold text-left transition flex items-center justify-between text-zinc-200 group"
                  title={`Click to test ${drum.label}`}
                >
                  <span className="truncate">{drum.label}</span>
                  <Zap className="w-3 h-3 text-zinc-500 group-hover:text-cyan-400" />
                </button>

                {/* 16 Steps (grouped into 4 beats of 4) */}
                <div className="flex-1 grid grid-cols-16 gap-1 sm:gap-1.5">
                  {steps.map((isActive, sIdx) => {
                    const isQuarterNote = sIdx % 4 === 0;
                    const isCurrentPlayhead = isPlaying && currentStep === sIdx;

                    return (
                      <button
                        key={sIdx}
                        onClick={() => handleToggleDrumStep(drum.id, sIdx)}
                        style={{
                          backgroundColor: isActive ? drum.color : undefined,
                          borderColor: isCurrentPlayhead ? '#ffffff' : undefined
                        }}
                        className={`h-9 rounded-lg border transition flex items-center justify-center relative ${
                          isActive
                            ? 'text-black font-extrabold shadow-sm'
                            : isQuarterNote
                            ? 'bg-zinc-900/90 border-zinc-700/80 hover:bg-zinc-800'
                            : 'bg-zinc-950 border-zinc-800/70 hover:bg-zinc-900'
                        } ${isCurrentPlayhead ? 'ring-2 ring-white scale-105 z-10' : ''}`}
                        title={`Beat ${Math.floor(sIdx / 4) + 1}.${(sIdx % 4) + 1}`}
                      >
                        {isCurrentPlayhead && (
                          <span className="absolute -top-1 w-1.5 h-1.5 rounded-full bg-white shadow-glow" />
                        )}
                        {isActive && <span className="w-2 h-2 rounded-full bg-black/60" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Multitrack Audio Workstation & Waveform Display */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3 flex-wrap gap-2">
          <div className="flex items-center space-x-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm font-bold text-white tracking-wide uppercase">
              Multitrack Audio Session ({tracks.length} {tracks.length === 1 ? 'Track' : 'Tracks'})
            </h2>
          </div>

          {/* Preset Audio Adders */}
          <div className="flex items-center space-x-2">
            <span className="text-[11px] text-zinc-500 font-semibold hidden sm:inline">Add Synthesizer:</span>
            <button
              onClick={() => handleAddBuiltinTrack('epic-cinematic')}
              className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-[11px] font-medium rounded-lg transition"
            >
              + Cinematic Strings
            </button>
            <button
              onClick={() => handleAddBuiltinTrack('cyberpunk-pulse')}
              className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-[11px] font-medium rounded-lg transition"
            >
              + Synthwave Bass
            </button>
          </div>
        </div>

        {/* Tracks List */}
        {tracks.length === 0 ? (
          <div className="py-10 text-center space-y-3 bg-zinc-900/30 rounded-xl border border-dashed border-zinc-800">
            <Music className="w-10 h-10 text-zinc-600 mx-auto" />
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-zinc-300">No Audio Tracks Added Yet</h3>
              <p className="text-xs text-zinc-500 max-w-sm mx-auto">
                Import an audio file, record your voice with the microphone, or click a synthesizer preset above to begin multitracking.
              </p>
            </div>
            <div className="flex justify-center space-x-2 pt-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Import Audio File</span>
              </button>
              <button
                onClick={handleToggleRecord}
                className="px-4 py-2 bg-red-950/60 hover:bg-red-900/60 border border-red-500/40 text-red-300 rounded-xl text-xs font-bold transition flex items-center space-x-1.5"
              >
                <Mic className="w-3.5 h-3.5" />
                <span>Record Voice</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {tracks.map((track) => {
              const effectiveDur = Math.max(0.1, track.trimEnd - track.trimStart);

              return (
                <div
                  key={track.id}
                  onClick={() => setActiveTrackId(track.id)}
                  className={`p-3.5 rounded-xl border transition space-y-3 ${
                    activeTrackId === track.id
                      ? 'bg-zinc-900/90 border-cyan-500/60 shadow-lg'
                      : 'bg-zinc-900/50 border-zinc-800/80 hover:border-zinc-700'
                  }`}
                >
                  {/* Track Top Bar: Name, Solo/Mute, Volume, Delete */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: track.color }} />
                      <input
                        type="text"
                        value={track.name}
                        onChange={(e) =>
                          setTracks(tracks.map((t) => (t.id === track.id ? { ...t, name: e.target.value } : t)))
                        }
                        className="bg-transparent font-bold text-xs text-white focus:outline-none focus:border-b focus:border-cyan-400 max-w-[140px] sm:max-w-xs"
                      />
                      <span className="text-[10px] text-zinc-500 font-mono">
                        {effectiveDur.toFixed(1)}s
                      </span>
                    </div>

                    <div className="flex items-center space-x-2 text-xs">
                      {/* Solo */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setTracks(tracks.map((t) => (t.id === track.id ? { ...t, isSolo: !t.isSolo } : t)));
                        }}
                        className={`px-2 py-1 rounded text-[10px] font-bold transition ${
                          track.isSolo
                            ? 'bg-amber-500 text-black shadow-sm'
                            : 'bg-zinc-800 text-zinc-400 hover:text-white'
                        }`}
                      >
                        SOLO
                      </button>

                      {/* Mute */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setTracks(tracks.map((t) => (t.id === track.id ? { ...t, isMuted: !t.isMuted } : t)));
                        }}
                        className={`px-2 py-1 rounded text-[10px] font-bold transition ${
                          track.isMuted
                            ? 'bg-red-500 text-white shadow-sm'
                            : 'bg-zinc-800 text-zinc-400 hover:text-white'
                        }`}
                      >
                        MUTE
                      </button>

                      {/* Volume */}
                      <div className="flex items-center space-x-1.5 bg-zinc-950 px-2.5 py-1 rounded-lg border border-zinc-800">
                        <Volume2 className="w-3.5 h-3.5 text-zinc-400" />
                        <input
                          type="range"
                          min={0}
                          max={1}
                          step={0.05}
                          value={track.volume}
                          onChange={(e) =>
                            setTracks(
                              tracks.map((t) => (t.id === track.id ? { ...t, volume: Number(e.target.value) } : t))
                            )
                          }
                          className="w-16 accent-cyan-400"
                        />
                        <span className="text-[10px] font-mono text-zinc-300 w-7 text-right">
                          {Math.round(track.volume * 100)}%
                        </span>
                      </div>

                      {/* Delete */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setTracks(tracks.filter((t) => t.id !== track.id));
                        }}
                        className="p-1 text-zinc-500 hover:text-red-400 rounded transition"
                        title="Delete Track"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Waveform Visualization Canvas & Trim Slider */}
                  <div className="space-y-1.5">
                    <div className="relative h-12 w-full bg-zinc-950 rounded-lg overflow-hidden border border-zinc-800 flex items-center px-2">
                      {/* Waveform Bars */}
                      <div className="w-full h-full flex items-center justify-between gap-[2px]">
                        {(track.peaks || Array(60).fill(0.3)).map((peak, idx) => {
                          const heightPct = Math.max(10, Math.min(100, Math.round(peak * 100)));
                          const isTrimmedOut =
                            track.duration > 0 &&
                            ((idx / 60) * track.duration < track.trimStart ||
                              (idx / 60) * track.duration > track.trimEnd);

                          return (
                            <div
                              key={idx}
                              style={{
                                height: `${heightPct}%`,
                                backgroundColor: isTrimmedOut ? '#3f3f46' : track.color,
                                opacity: isTrimmedOut ? 0.3 : 0.85
                              }}
                              className="flex-1 rounded-full transition-all"
                            />
                          );
                        })}
                      </div>

                      {/* Playhead indicator */}
                      {isPlaying && (
                        <div
                          style={{ left: `${(currentStep / 16) * 100}%` }}
                          className="absolute top-0 bottom-0 w-0.5 bg-white shadow-glow pointer-events-none transition-all duration-75"
                        />
                      )}
                    </div>

                    {/* Precision Trim Sliders */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] text-zinc-400 bg-zinc-950/70 p-2 rounded-lg border border-zinc-800/80">
                      <div className="flex items-center space-x-2">
                        <span className="font-semibold text-zinc-300">Trim Start:</span>
                        <input
                          type="range"
                          min={0}
                          max={Math.max(0, track.trimEnd - 0.2)}
                          step={0.1}
                          value={track.trimStart}
                          onChange={(e) =>
                            setTracks(
                              tracks.map((t) =>
                                t.id === track.id ? { ...t, trimStart: Number(e.target.value) } : t
                              )
                            )
                          }
                          className="flex-1 accent-cyan-400"
                        />
                        <span className="font-mono text-zinc-200 w-10 text-right">{track.trimStart.toFixed(1)}s</span>
                      </div>

                      <div className="flex items-center space-x-2">
                        <span className="font-semibold text-zinc-300">Trim End:</span>
                        <input
                          type="range"
                          min={Math.min(track.duration, track.trimStart + 0.2)}
                          max={track.duration}
                          step={0.1}
                          value={track.trimEnd}
                          onChange={(e) =>
                            setTracks(
                              tracks.map((t) =>
                                t.id === track.id ? { ...t, trimEnd: Number(e.target.value) } : t
                              )
                            )
                          }
                          className="flex-1 accent-cyan-400"
                        />
                        <span className="font-mono text-zinc-200 w-10 text-right">{track.trimEnd.toFixed(1)}s</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Master Audio DSP Effects Rack: Reverb & Echo */}
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 shadow-2xl space-y-4">
        <div className="flex items-center space-x-2 border-b border-zinc-800/80 pb-3">
          <Sliders className="w-4 h-4 text-purple-400" />
          <h2 className="text-sm font-bold text-white tracking-wide uppercase">
            Master DSP Effects Rack (Reverb, Echo & Dynamics)
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
          {/* Reverb Wet / Dry */}
          <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800/80 space-y-1.5">
            <div className="flex justify-between text-zinc-300 font-semibold">
              <span>Studio Reverb Mix</span>
              <span className="font-mono text-cyan-400">{Math.round(masterFx.reverbWet * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={masterFx.reverbWet}
              onChange={(e) => setMasterFx({ ...masterFx, reverbWet: Number(e.target.value) })}
              className="w-full accent-cyan-400"
            />
            <p className="text-[10px] text-zinc-500">Convolver algorithmic space simulator</p>
          </div>

          {/* Reverb Decay Time */}
          <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800/80 space-y-1.5">
            <div className="flex justify-between text-zinc-300 font-semibold">
              <span>Reverb Room Decay</span>
              <span className="font-mono text-cyan-400">{masterFx.reverbDecay.toFixed(1)}s</span>
            </div>
            <input
              type="range"
              min={0.5}
              max={5.0}
              step={0.2}
              value={masterFx.reverbDecay}
              onChange={(e) => setMasterFx({ ...masterFx, reverbDecay: Number(e.target.value) })}
              className="w-full accent-cyan-400"
            />
            <p className="text-[10px] text-zinc-500">Impulse tail duration & room size</p>
          </div>

          {/* Echo Delay Time */}
          <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800/80 space-y-1.5">
            <div className="flex justify-between text-zinc-300 font-semibold">
              <span>Echo Delay Time</span>
              <span className="font-mono text-purple-400">{Math.round(masterFx.echoTime * 1000)}ms</span>
            </div>
            <input
              type="range"
              min={0.05}
              max={0.8}
              step={0.05}
              value={masterFx.echoTime}
              onChange={(e) => setMasterFx({ ...masterFx, echoTime: Number(e.target.value) })}
              className="w-full accent-purple-400"
            />
            <p className="text-[10px] text-zinc-500">Delay offset for rhythmic sync</p>
          </div>

          {/* Echo Feedback */}
          <div className="p-3 bg-zinc-900/60 rounded-xl border border-zinc-800/80 space-y-1.5">
            <div className="flex justify-between text-zinc-300 font-semibold">
              <span>Echo Feedback / Repeats</span>
              <span className="font-mono text-purple-400">{Math.round(masterFx.echoFeedback * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={0.75}
              step={0.05}
              value={masterFx.echoFeedback}
              onChange={(e) => setMasterFx({ ...masterFx, echoFeedback: Number(e.target.value) })}
              className="w-full accent-purple-400"
            />
            <p className="text-[10px] text-zinc-500">Number of echo repeats</p>
          </div>
        </div>
      </div>

      {/* Rendered Mixdown Download Modal / Drawer */}
      {mixdownResult && (
        <div className="p-5 rounded-2xl bg-zinc-950 border border-emerald-500/50 shadow-2xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-emerald-400">
              <CheckCircle className="w-5 h-5" />
              <h3 className="font-bold text-sm text-white">Audio Mixdown Ready!</h3>
            </div>
            <button
              onClick={() => setMixdownResult(null)}
              className="text-xs text-zinc-500 hover:text-white"
            >
              Dismiss
            </button>
          </div>

          <p className="text-xs text-zinc-300">
            Your multitrack audio and drum sequencer mix has been rendered into a 16-bit 44.1 kHz PCM WAV file ({mixdownResult.duration.toFixed(1)}s).
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-1">
            <a
              href={mixdownResult.url}
              download={`sufyan_pro_mix_${Date.now()}.wav`}
              className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-cyan-500 text-black font-extrabold rounded-xl text-xs flex items-center space-x-1.5 shadow-md shadow-emerald-500/20"
            >
              <Download className="w-4 h-4" />
              <span>Download WAV to Device</span>
            </a>

            <button
              onClick={handleSendToVideo}
              className="px-4 py-2 bg-zinc-900 hover:bg-zinc-800 border border-cyan-500/50 text-cyan-300 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition"
            >
              <Film className="w-4 h-4" />
              <span>Open in Video Timeline</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
