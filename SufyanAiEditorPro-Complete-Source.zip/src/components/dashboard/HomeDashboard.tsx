import React, { useState } from 'react';
import {
  Film,
  Camera,
  Gamepad2,
  Tv,
  Music,
  Download,
  Smartphone,
  User,
  Sparkles,
  ShieldCheck,
  Zap,
  Play,
  Clock,
  Layers,
  Settings,
  HelpCircle,
  ExternalLink,
  Plus,
  Trash2,
  FileCode,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { VideoProject } from '../../types/editor';
import { UserProfile } from '../../types/auth';

interface HomeDashboardProps {
  onNavigateTab: (tab: 'dashboard' | 'video' | 'gaming' | 'entertainment' | 'music' | 'photo' | 'android' | 'auth') => void;
  currentProject: VideoProject;
  onOpenProject: (project: VideoProject) => void;
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
}

export const HomeDashboard: React.FC<HomeDashboardProps> = ({
  onNavigateTab,
  currentProject,
  onOpenProject,
  currentUser,
  onOpenAuth
}) => {
  const [recentProjects, setRecentProjects] = useState<VideoProject[]>(() => {
    try {
      const saved = localStorage.getItem('sufyan_video_project');
      if (saved) {
        const parsed = JSON.parse(saved);
        return [parsed];
      }
    } catch (e) {}
    return [currentProject];
  });

  const totalClipsCount = currentProject.clips.length;
  const totalDurationSec = currentProject.clips.reduce(
    (sum, c) => sum + (c.endTime - c.startTime) / c.playbackRate,
    0
  );

  return (
    <div className="w-full space-y-6 animate-fadeIn pb-8">
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-zinc-800 bg-gradient-to-br from-zinc-950 via-zinc-900 to-black p-5 sm:p-7 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
          <div className="space-y-2 max-w-xl">
            <div className="flex items-center space-x-2">
              <span className="text-[10px] bg-cyan-500/20 text-cyan-300 font-extrabold px-2.5 py-0.5 rounded-full border border-cyan-500/40 tracking-wider">
                PRO CREATOR STUDIO
              </span>
              <span className="text-xs text-zinc-400">• v1.0.0 Stable</span>
            </div>

            <h1 className="text-xl sm:text-3xl font-extrabold text-white tracking-tight">
              SUFYAN AI EDITOR PRO
            </h1>

            <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">
              Professional mobile-first video & photo editing studio. Cut gaming montages for PUBG & BGMI, produce cinematic reels for TikTok, retouch photos with local AI, and export up to 10K with zero watermarks.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2 text-xs text-zinc-400">
              <div className="flex items-center space-x-1.5 text-emerald-400">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>100% Free • No Watermark</span>
              </div>
              <span>•</span>
              <div className="flex items-center space-x-1.5 text-cyan-400">
                <Zap className="w-4 h-4 shrink-0" />
                <span>On-Device GPU Processing</span>
              </div>
            </div>
          </div>

          {/* Quick Actions Card */}
          <div className="flex flex-col sm:flex-row md:flex-col gap-2.5 w-full md:w-auto shrink-0">
            <button
              onClick={() => onNavigateTab('video')}
              className="py-3 px-5 rounded-xl bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 hover:from-cyan-300 hover:to-purple-500 text-black font-extrabold text-xs shadow-lg shadow-cyan-500/25 flex items-center justify-center space-x-2 transition"
            >
              <Film className="w-4 h-4" />
              <span>Open Video Timeline</span>
            </button>

            <button
              onClick={() => onNavigateTab('android')}
              className="py-2.5 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-red-500/60 text-white font-bold text-xs flex items-center justify-center space-x-2 shadow-sm transition"
            >
              <Smartphone className="w-4 h-4 text-red-400" />
              <span>Download Android APK & Source</span>
            </button>
          </div>
        </div>
      </div>

      {/* Complete Studio Sections Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold tracking-wide text-zinc-200 uppercase">
            Editing Studios & Creative Workflows
          </h2>
          <span className="text-[11px] text-zinc-500">Tap any studio to launch</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {/* 1. Video Editor */}
          <div
            onClick={() => onNavigateTab('video')}
            className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/90 hover:border-cyan-400/60 hover:bg-zinc-900/40 cursor-pointer transition group shadow-md"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 group-hover:scale-105 transition">
                <Film className="w-5 h-5" />
              </div>
              <span className="text-[10px] uppercase font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded-full border border-cyan-500/30">
                Core Timeline
              </span>
            </div>
            <h3 className="font-bold text-sm text-white group-hover:text-cyan-400 transition">
              Video Editor Studio
            </h3>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
              Multi-clip timeline, trimming, splitting, speed ramps (0.25x - 4x), LUT grading, text titles, and picture-in-picture.
            </p>
          </div>

          {/* 2. Gaming Studio */}
          <div
            onClick={() => onNavigateTab('gaming')}
            className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/90 hover:border-purple-400/60 hover:bg-zinc-900/40 cursor-pointer transition group shadow-md"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20 group-hover:scale-105 transition">
                <Gamepad2 className="w-5 h-5" />
              </div>
              <span className="text-[10px] uppercase font-bold text-purple-400 bg-purple-950/60 px-2 py-0.5 rounded-full border border-purple-500/30">
                PUBG & BGMI
              </span>
            </div>
            <h3 className="font-bold text-sm text-white group-hover:text-purple-400 transition">
              Gaming Montage Studio
            </h3>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
              Fast-paced velocity ramps, clutch kill-cam slow mo, white flash transitions, glitch effects, and neon gaming title presets.
            </p>
          </div>

          {/* 3. Entertainment Studio */}
          <div
            onClick={() => onNavigateTab('entertainment')}
            className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/90 hover:border-pink-400/60 hover:bg-zinc-900/40 cursor-pointer transition group shadow-md"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-2.5 rounded-xl bg-pink-500/10 text-pink-400 border border-pink-500/20 group-hover:scale-105 transition">
                <Tv className="w-5 h-5" />
              </div>
              <span className="text-[10px] uppercase font-bold text-pink-400 bg-pink-950/60 px-2 py-0.5 rounded-full border border-pink-500/30">
                Shorts & Reels
              </span>
            </div>
            <h3 className="font-bold text-sm text-white group-hover:text-pink-400 transition">
              Entertainment & Cinema
            </h3>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
              9:16 vertical TikTok/Reels formatting, cinematic 2.39:1 letterbox bars, film grain, vintage noir, and movie title cards.
            </p>
          </div>

          {/* 4. Music & Audio Studio */}
          <div
            onClick={() => onNavigateTab('music')}
            className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/90 hover:border-emerald-400/60 hover:bg-zinc-900/40 cursor-pointer transition group shadow-md"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 group-hover:scale-105 transition">
                <Music className="w-5 h-5" />
              </div>
              <span className="text-[10px] uppercase font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
                Beats & Multi-Track
              </span>
            </div>
            <h3 className="font-bold text-sm text-white group-hover:text-emerald-400 transition">
              Music & Audio Studio
            </h3>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
              16-step drum sequencer, multitrack audio playback, microphone recording, waveform trimming, Reverb and Echo DSP effects.
            </p>
          </div>

          {/* 5. Photo Studio & AI Tools */}
          <div
            onClick={() => onNavigateTab('photo')}
            className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/90 hover:border-amber-400/60 hover:bg-zinc-900/40 cursor-pointer transition group shadow-md"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20 group-hover:scale-105 transition">
                <Camera className="w-5 h-5" />
              </div>
              <span className="text-[10px] uppercase font-bold text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-500/30">
                Photo & AI
              </span>
            </div>
            <h3 className="font-bold text-sm text-white group-hover:text-amber-400 transition">
              Photo Editor & AI Retouch
            </h3>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
              Crop, rotate, portrait bokeh blur, background replacement with transparent export, before-and-after split slider.
            </p>
          </div>

          {/* 5. Android APK Hub */}
          <div
            onClick={() => onNavigateTab('android')}
            className="p-4 rounded-2xl bg-zinc-950 border border-red-500/50 hover:border-red-400 hover:bg-zinc-900/40 cursor-pointer transition group shadow-md shadow-red-500/10"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-2.5 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20 group-hover:scale-105 transition">
                <Smartphone className="w-5 h-5" />
              </div>
              <span className="text-[10px] uppercase font-bold text-white bg-red-600 px-2 py-0.5 rounded-full animate-pulse">
                APK & ZIP
              </span>
            </div>
            <h3 className="font-bold text-sm text-white group-hover:text-red-400 transition">
              Android APK & Source Download
            </h3>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
              Download complete Android Studio native project ZIP with logo assets. Build debug APK free on phone via GitHub Actions.
            </p>
          </div>

          {/* 6. Account & Sync */}
          <div
            onClick={onOpenAuth}
            className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/90 hover:border-blue-400/60 hover:bg-zinc-900/40 cursor-pointer transition group shadow-md"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 group-hover:scale-105 transition">
                <User className="w-5 h-5" />
              </div>
              <span className="text-[10px] uppercase font-bold text-blue-400 bg-blue-950/60 px-2 py-0.5 rounded-full border border-blue-500/30">
                {currentUser ? 'Signed In' : 'Local Mode'}
              </span>
            </div>
            <h3 className="font-bold text-sm text-white group-hover:text-blue-400 transition">
              {currentUser ? currentUser.name : 'Unified Account & Cloud Sync'}
            </h3>
            <p className="text-xs text-zinc-400 mt-1 leading-relaxed">
              Google/Apple OAuth config, email/password login, phone OTP verification, and secure cloud project backup.
            </p>
          </div>
        </div>
      </div>

      {/* Active Project & Recent Edits */}
      <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">Active Project & Recent Edits</h3>
          </div>
          <button
            onClick={() => onNavigateTab('video')}
            className="text-xs text-cyan-400 hover:underline flex items-center space-x-1"
          >
            <span>Resume Editing</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <h4 className="font-bold text-sm text-white">{currentProject.name || 'My Cinematic Movie'}</h4>
              <span className="text-[10px] bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded font-mono font-bold">
                {currentProject.aspectRatio}
              </span>
            </div>
            <p className="text-xs text-zinc-400">
              {totalClipsCount} {totalClipsCount === 1 ? 'clip' : 'clips'} • Duration: {totalDurationSec.toFixed(1)}s • Color Preset: {currentProject.colorGrade.preset}
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => onNavigateTab('video')}
              className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-black font-bold rounded-lg text-xs transition flex items-center space-x-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Open in Timeline</span>
            </button>
          </div>
        </div>
      </div>

      {/* Device Compatibility & Cross-Platform Installation Guide */}
      <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
        <div className="flex items-center space-x-2">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <h3 className="text-sm font-bold text-white">Cross-Platform Installation Matrix</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800/80 space-y-1.5">
            <div className="font-bold text-white flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span>Android Phone & Tablet</span>
            </div>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Install directly via Chrome PWA (tap "Install App") or download the Android Studio APK source ZIP.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800/80 space-y-1.5">
            <div className="font-bold text-white flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-blue-400"></span>
              <span>iPhone & iPad (iOS)</span>
            </div>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Open in Safari, tap the <strong>Share</strong> icon, and select <strong>"Add to Home Screen"</strong> for full-screen PWA.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800/80 space-y-1.5">
            <div className="font-bold text-white flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
              <span>Windows Laptop / PC</span>
            </div>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Open in Google Chrome or Microsoft Edge and click the install icon in the address bar. Full mouse & shortcut support.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800/80 space-y-1.5">
            <div className="font-bold text-white flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-purple-400"></span>
              <span>macOS & Linux</span>
            </div>
            <p className="text-[11px] text-zinc-400 leading-relaxed">
              Supported on Chrome, Brave, and Edge as standalone PWA desktop app with high-bitrate canvas export.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
