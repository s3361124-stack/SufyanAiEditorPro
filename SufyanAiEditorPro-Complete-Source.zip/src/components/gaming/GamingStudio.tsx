import React, { useState } from 'react';
import {
  Gamepad2,
  Zap,
  Flame,
  Crosshair,
  Trophy,
  Sliders,
  RotateCcw,
  Eye,
  Film,
  Sparkles,
  ArrowRight,
  Play,
  Volume2,
  Tv
} from 'lucide-react';
import { VideoProject, AspectRatio, ColorGradeSettings, TextOverlay, VideoClip } from '../../types/editor';

interface GamingStudioProps {
  project: VideoProject;
  onUpdateProject: (project: VideoProject) => void;
  onOpenTimeline: () => void;
}

export const GamingStudio: React.FC<GamingStudioProps> = ({
  project,
  onUpdateProject,
  onOpenTimeline
}) => {
  const [showBeforeAfter, setShowBeforeAfter] = useState(false);

  // Apply PUBG/BGMI Clutch Velocity Preset
  const handleApplyPreset = (presetName: 'clutch' | 'sniper' | 'victory' | 'funny') => {
    let updatedGrade: ColorGradeSettings = { ...project.colorGrade };
    let newAspectRatio: AspectRatio = project.aspectRatio;
    let newTextOverlays = [...project.textOverlays];

    if (presetName === 'clutch') {
      // Natural esports boost: punchy contrast, slightly saturated, crisp sharpness
      updatedGrade = {
        preset: 'teal-orange',
        brightness: 5,
        contrast: 15,
        saturation: 20,
        temperature: 0,
        sharpness: 35,
        vignette: 25,
        filmGrain: 0,
        letterbox: false,
        letterboxHeight: 0
      };
      // Add Clutch Overlay
      newTextOverlays.push({
        id: 'gaming_txt_' + Date.now(),
        text: '1v4 CLUTCH MOMENT',
        type: 'title',
        startTime: 0.5,
        endTime: 4.5,
        x: 50,
        y: 80,
        fontSize: 38,
        fontFamily: 'Impact',
        color: '#00f2fe',
        borderColor: '#000000',
        letterSpacing: 2,
        align: 'center',
        animation: 'zoom-in'
      });
    } else if (presetName === 'sniper') {
      updatedGrade = {
        preset: 'cyberpunk',
        brightness: 0,
        contrast: 20,
        saturation: 25,
        temperature: -10,
        sharpness: 40,
        vignette: 40,
        filmGrain: 10,
        letterbox: true,
        letterboxHeight: 10
      };
      newTextOverlays.push({
        id: 'gaming_txt_' + Date.now(),
        text: 'HEADSHOT • AWM MONTAGE',
        type: 'title',
        startTime: 0,
        endTime: 4.0,
        x: 50,
        y: 85,
        fontSize: 32,
        fontFamily: 'Arial',
        color: '#ff0055',
        borderColor: '#ffffff',
        align: 'center',
        animation: 'typewriter'
      });
    } else if (presetName === 'victory') {
      updatedGrade = {
        preset: 'golden-hour',
        brightness: 10,
        contrast: 10,
        saturation: 15,
        temperature: 15,
        sharpness: 20,
        vignette: 15,
        filmGrain: 0,
        letterbox: false,
        letterboxHeight: 0
      };
      newTextOverlays.push({
        id: 'gaming_txt_' + Date.now(),
        text: 'WINNER WINNER CHICKEN DINNER',
        type: 'title',
        startTime: 0,
        endTime: 5.0,
        x: 50,
        y: 20,
        fontSize: 34,
        fontFamily: 'Impact',
        color: '#ffd700',
        borderColor: '#000000',
        align: 'center',
        animation: 'fade'
      });
    } else if (presetName === 'funny') {
      updatedGrade = {
        preset: 'original',
        brightness: 10,
        contrast: 5,
        saturation: 30,
        temperature: 5,
        sharpness: 10,
        vignette: 0,
        filmGrain: 0,
        letterbox: false,
        letterboxHeight: 0
      };
    }

    onUpdateProject({
      ...project,
      aspectRatio: newAspectRatio,
      colorGrade: updatedGrade,
      textOverlays: newTextOverlays
    });
  };

  // Reset to original colors
  const handleResetColor = () => {
    onUpdateProject({
      ...project,
      colorGrade: {
        preset: 'original',
        brightness: 0,
        contrast: 0,
        saturation: 0,
        temperature: 0,
        sharpness: 0,
        vignette: 0,
        filmGrain: 0,
        letterbox: false,
        letterboxHeight: 0
      }
    });
  };

  return (
    <div className="w-full space-y-6 animate-fadeIn pb-8">
      {/* Studio Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-purple-500/30 bg-gradient-to-r from-purple-950/40 via-zinc-950 to-black p-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className="text-[10px] bg-purple-500/20 text-purple-300 font-extrabold px-2.5 py-0.5 rounded-full border border-purple-500/40">
                PUBG MOBILE & BGMI STUDIO
              </span>
              <span className="text-xs text-zinc-400">• Esports Montage Engine</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-white">
              GAMING HIGHLIGHTS & CLUTCH STUDIO
            </h1>
            <p className="text-xs text-zinc-300 max-w-xl">
              Velocity speed ramps, clutch kill-cam slow mo, white flash kill transitions, shake effects, and esports color tuning.
            </p>
          </div>

          <button
            onClick={onOpenTimeline}
            className="py-2.5 px-5 bg-gradient-to-r from-purple-500 to-cyan-500 hover:from-purple-400 hover:to-cyan-400 text-black font-extrabold text-xs rounded-xl shadow-lg shadow-purple-500/25 flex items-center space-x-2 transition shrink-0"
          >
            <Film className="w-4 h-4" />
            <span>Open Multi-Clip Timeline</span>
          </button>
        </div>
      </div>

      {/* Quick Gaming Presets */}
      <div className="space-y-3">
        <h2 className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center space-x-2">
          <Flame className="w-4 h-4 text-orange-400" />
          <span>One-Tap Gaming Montage Presets</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {/* Preset 1: 1v4 Clutch */}
          <div
            onClick={() => handleApplyPreset('clutch')}
            className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-cyan-400/80 cursor-pointer transition group"
          >
            <div className="flex items-center space-x-2 text-cyan-400 font-bold text-sm mb-1">
              <Zap className="w-4 h-4" />
              <span>1v4 Clutch Velocity</span>
            </div>
            <p className="text-[11px] text-zinc-400">
              High-contrast teal & orange grade, 25% vignette focus, and bold neon clutch title overlay.
            </p>
          </div>

          {/* Preset 2: Sniper AWM */}
          <div
            onClick={() => handleApplyPreset('sniper')}
            className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-purple-400/80 cursor-pointer transition group"
          >
            <div className="flex items-center space-x-2 text-purple-400 font-bold text-sm mb-1">
              <Crosshair className="w-4 h-4" />
              <span>Sniper Headshot Montage</span>
            </div>
            <p className="text-[11px] text-zinc-400">
              Cyberpunk neon hue, cinematic letterbox bars, and typewriter headshot title card.
            </p>
          </div>

          {/* Preset 3: Victory Royale */}
          <div
            onClick={() => handleApplyPreset('victory')}
            className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-amber-400/80 cursor-pointer transition group"
          >
            <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm mb-1">
              <Trophy className="w-4 h-4" />
              <span>Chicken Dinner Victory</span>
            </div>
            <p className="text-[11px] text-zinc-400">
              Warm golden-hour triumph color grade with gold victory header.
            </p>
          </div>

          {/* Preset 4: Funny Moments */}
          <div
            onClick={() => handleApplyPreset('funny')}
            className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-emerald-400/80 cursor-pointer transition group"
          >
            <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm mb-1">
              <Sparkles className="w-4 h-4" />
              <span>Funny Fails & Memes</span>
            </div>
            <p className="text-[11px] text-zinc-400">
              Vibrant saturation boost with clean natural sharpness.
            </p>
          </div>
        </div>
      </div>

      {/* Gaming Color Grading & Original Reset Section */}
      <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">Natural Esports Color Tuning</h3>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowBeforeAfter(!showBeforeAfter)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition ${
                showBeforeAfter
                  ? 'bg-cyan-500 text-black'
                  : 'bg-zinc-800 text-zinc-300 hover:text-white'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Before / After</span>
            </button>

            <button
              onClick={handleResetColor}
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white text-xs font-semibold flex items-center space-x-1.5 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Original Colors</span>
            </button>
          </div>
        </div>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
          {/* Brightness */}
          <div>
            <div className="flex justify-between text-zinc-300 mb-1">
              <span>Brightness</span>
              <span className="font-mono">{project.colorGrade.brightness}</span>
            </div>
            <input
              type="range"
              min={-50}
              max={50}
              value={project.colorGrade.brightness}
              onChange={(e) =>
                onUpdateProject({
                  ...project,
                  colorGrade: { ...project.colorGrade, brightness: Number(e.target.value) }
                })
              }
              className="w-full accent-cyan-400"
            />
          </div>

          {/* Contrast */}
          <div>
            <div className="flex justify-between text-zinc-300 mb-1">
              <span>Contrast</span>
              <span className="font-mono">{project.colorGrade.contrast}</span>
            </div>
            <input
              type="range"
              min={-50}
              max={50}
              value={project.colorGrade.contrast}
              onChange={(e) =>
                onUpdateProject({
                  ...project,
                  colorGrade: { ...project.colorGrade, contrast: Number(e.target.value) }
                })
              }
              className="w-full accent-cyan-400"
            />
          </div>

          {/* Saturation */}
          <div>
            <div className="flex justify-between text-zinc-300 mb-1">
              <span>Saturation</span>
              <span className="font-mono">{project.colorGrade.saturation}</span>
            </div>
            <input
              type="range"
              min={-50}
              max={50}
              value={project.colorGrade.saturation}
              onChange={(e) =>
                onUpdateProject({
                  ...project,
                  colorGrade: { ...project.colorGrade, saturation: Number(e.target.value) }
                })
              }
              className="w-full accent-cyan-400"
            />
          </div>

          {/* Sharpness */}
          <div>
            <div className="flex justify-between text-zinc-300 mb-1">
              <span>Sharpness</span>
              <span className="font-mono">{project.colorGrade.sharpness}</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={project.colorGrade.sharpness}
              onChange={(e) =>
                onUpdateProject({
                  ...project,
                  colorGrade: { ...project.colorGrade, sharpness: Number(e.target.value) }
                })
              }
              className="w-full accent-cyan-400"
            />
          </div>

          {/* Temperature */}
          <div>
            <div className="flex justify-between text-zinc-300 mb-1">
              <span>Color Temperature</span>
              <span className="font-mono">{project.colorGrade.temperature}</span>
            </div>
            <input
              type="range"
              min={-50}
              max={50}
              value={project.colorGrade.temperature}
              onChange={(e) =>
                onUpdateProject({
                  ...project,
                  colorGrade: { ...project.colorGrade, temperature: Number(e.target.value) }
                })
              }
              className="w-full accent-cyan-400"
            />
          </div>

          {/* Vignette */}
          <div>
            <div className="flex justify-between text-zinc-300 mb-1">
              <span>Vignette Edge Focus</span>
              <span className="font-mono">{project.colorGrade.vignette}</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={project.colorGrade.vignette}
              onChange={(e) =>
                onUpdateProject({
                  ...project,
                  colorGrade: { ...project.colorGrade, vignette: Number(e.target.value) }
                })
              }
              className="w-full accent-cyan-400"
            />
          </div>
        </div>

        {/* Aspect Ratio Switcher for Gaming Platforms */}
        <div className="pt-3 border-t border-zinc-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <span className="text-zinc-400 font-semibold">Gaming Canvas Aspect Ratio:</span>
          <div className="flex items-center space-x-2">
            {(['16:9', '9:16', '1:1', '21:9'] as AspectRatio[]).map((ratio) => (
              <button
                key={ratio}
                onClick={() => onUpdateProject({ ...project, aspectRatio: ratio })}
                className={`px-3 py-1.5 rounded-lg font-mono font-bold transition ${
                  project.aspectRatio === ratio
                    ? 'bg-cyan-500 text-black shadow-sm'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
                }`}
              >
                {ratio}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
