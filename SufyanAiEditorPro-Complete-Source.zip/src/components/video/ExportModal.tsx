import React, { useState, useRef } from 'react';
import {
  X,
  Download,
  Film,
  CheckCircle,
  AlertCircle,
  Clock,
  Sparkles,
  ShieldCheck,
  Zap,
  Share2,
  HardDrive,
  Cpu,
  Info,
  Smartphone,
  ExternalLink,
  Layers,
  StopCircle,
  Play
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { VideoProject, ExportSettings, ExportResolution } from '../../types/editor';
import { exportVideoProject, ExportProgress, RESOLUTION_SPECS } from '../../utils/videoExporter';
import { getAspectRatioDimensions } from '../../utils/videoRenderer';
import { createProceduralVideoClip } from '../../utils/sampleMedia';
import { generateBuiltinAudio } from '../../utils/audioSynthesis';

interface ExportModalProps {
  project: VideoProject;
  isOpen: boolean;
  onClose: () => void;
}

interface SocialPlatformInfo {
  name: string;
  recommendedAspect: string;
  recommendedRes: string;
  recommendedFps: string;
  tip: string;
  color: string;
}

const SOCIAL_PLATFORMS: SocialPlatformInfo[] = [
  {
    name: 'TikTok',
    recommendedAspect: '9:16 Vertical',
    recommendedRes: '1080p (1080x1920)',
    recommendedFps: '30 or 60 FPS',
    tip: 'TikTok automatically compresses 4K uploads; 1080p produces the sharpest result with fastest upload.',
    color: '#00f2fe'
  },
  {
    name: 'Instagram Reels',
    recommendedAspect: '9:16 Vertical',
    recommendedRes: '1080p (1080x1920)',
    recommendedFps: '30 FPS',
    tip: 'Ensure "Upload at highest quality" is enabled in Instagram settings > Account > Data Usage.',
    color: '#e1306c'
  },
  {
    name: 'YouTube',
    recommendedAspect: '16:9 Landscape',
    recommendedRes: '1440p / 4K (2160p)',
    recommendedFps: '60 FPS',
    tip: 'YouTube grants higher bitrate VP9/AV01 video encoding presets to 1440p and 4K uploads.',
    color: '#ff0000'
  },
  {
    name: 'Facebook & Shorts',
    recommendedAspect: '9:16 or 1:1',
    recommendedRes: '1080p (1080x1080 or 1080x1920)',
    recommendedFps: '30 FPS',
    tip: 'Standard MP4 with AAC audio has universal playback across all Facebook mobile apps.',
    color: '#1877f2'
  }
];

export const ExportModal: React.FC<ExportModalProps> = ({ project, isOpen, onClose }) => {
  const [settings, setSettings] = useState<ExportSettings>({
    resolution: '1080p',
    fps: 30,
    quality: 'high',
    format: 'mp4'
  });

  const [isExporting, setIsExporting] = useState(false);
  const [progressData, setProgressData] = useState<ExportProgress | null>(null);
  const [downloadResult, setDownloadResult] = useState<{ blob: Blob; url: string; filename: string } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'settings' | 'social_guide'>('settings');
  const [shareSuccess, setShareSuccess] = useState(false);
  const [saveNotice, setSaveNotice] = useState<string | null>(null);

  const abortSignalRef = useRef<{ aborted: boolean }>({ aborted: false });

  if (!isOpen) return null;

  // Calculate project total duration
  const totalDurationSec = project.clips.reduce(
    (sum, c) => sum + (c.endTime - c.startTime) / c.playbackRate,
    0
  );

  // Calculate pixel dimensions for current project aspect ratio and selected resolution
  const currentSpec = RESOLUTION_SPECS[settings.resolution] || RESOLUTION_SPECS['1080p'];
  const outputDims = getAspectRatioDimensions(project.aspectRatio, currentSpec.baseWidth);

  // Estimate file size in MB
  const targetBitrateBps =
    settings.quality === 'ultra'
      ? currentSpec.bitrateUltra
      : settings.quality === 'high'
      ? currentSpec.bitrateHigh
      : Math.round(currentSpec.bitrateHigh * 0.6);
  const estimatedSizeBytes = (targetBitrateBps / 8) * Math.max(1, totalDurationSec);
  const estimatedSizeMb = (estimatedSizeBytes / (1024 * 1024)).toFixed(1);

  // Check whether current choice is native or canvas upscaling
  const isUpscaled = settings.resolution === '4k' || settings.resolution === '8k' || settings.resolution === '10k';

  // Start Real Export
  const handleStartExport = async () => {
    setIsExporting(true);
    setErrorMsg(null);
    setSaveNotice(null);
    setDownloadResult(null);
    abortSignalRef.current = { aborted: false };

    try {
      const result = await exportVideoProject(
        project,
        settings,
        (p) => {
          setProgressData(p);
        },
        abortSignalRef.current
      );

      setDownloadResult({ blob: result.blob, url: result.url, filename: result.filename });
      setIsExporting(false);

      // Trigger celebratory confetti
      confetti({
        particleCount: 90,
        spread: 75,
        origin: { y: 0.6 }
      });
    } catch (err) {
      setIsExporting(false);
      setErrorMsg((err as Error).message || 'Export failed. Check clip memory and format compatibility.');
    }
  };

  // Step 2 Verification Test: 3-second live export with video, text overlay, and audio
  const handleRunTestExport = async () => {
    setIsExporting(true);
    setErrorMsg(null);
    setSaveNotice(null);
    setDownloadResult(null);
    abortSignalRef.current = { aborted: false };

    try {
      // 1. Generate 3-second sample video clip
      const testClip = await createProceduralVideoClip('SUFYAN Cinematic Shot', 'cinematic', 3);

      // 2. Synthesize audio track
      const audioUrl = await generateBuiltinAudio('sfx-boom');

      const testProject: VideoProject = {
        ...project,
        name: 'Sufyan_Export_Verification_Test',
        clips: [testClip],
        textOverlays: [
          {
            id: 'test_txt_1',
            text: 'SUFYAN AI EDITOR PRO',
            type: 'title',
            startTime: 0,
            endTime: 3,
            x: 50,
            y: 42,
            fontSize: 44,
            fontFamily: 'system-ui, sans-serif',
            color: '#38bdf8',
            align: 'center',
            animation: 'zoom-in'
          },
          {
            id: 'test_txt_2',
            text: 'VERIFIED EXPORT: TEXT OVERLAY & AUDIO ACTIVE',
            type: 'subtitle',
            startTime: 0.5,
            endTime: 3,
            x: 50,
            y: 60,
            fontSize: 20,
            fontFamily: 'system-ui, sans-serif',
            color: '#ffffff',
            align: 'center',
            animation: 'fade'
          }
        ],
        audioTracks: [
          {
            id: 'test_audio_1',
            name: 'Verification Audio Pulse',
            url: audioUrl,
            duration: 2.5,
            startTime: 0,
            volume: 1.0,
            fadeIn: 0,
            fadeOut: 0.5
          }
        ]
      };

      const result = await exportVideoProject(
        testProject,
        { ...settings, resolution: '720p', fps: 30 },
        (p) => setProgressData(p),
        abortSignalRef.current
      );

      setDownloadResult({ blob: result.blob, url: result.url, filename: result.filename });
      setIsExporting(false);

      confetti({
        particleCount: 90,
        spread: 75,
        origin: { y: 0.6 }
      });
    } catch (err) {
      setIsExporting(false);
      setErrorMsg((err as Error).message || 'Test export failed.');
    }
  };

  // Cancel in-progress export
  const handleCancelExport = () => {
    abortSignalRef.current.aborted = true;
    setIsExporting(false);
    setErrorMsg('Export was halted by user.');
  };

  // Direct Social Share using Web Share API
  const handleShareToSocial = async () => {
    if (!downloadResult) return;
    try {
      const file = new File([downloadResult.blob], downloadResult.filename, {
        type: downloadResult.blob.type || 'video/mp4'
      });

      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: project.name || 'SUFYAN AI Video Export',
          text: 'Edited with SUFYAN AI EDITOR PRO'
        });
        setShareSuccess(true);
      } else if (navigator.share) {
        await navigator.share({
          title: project.name || 'SUFYAN AI Video Export',
          text: 'Download file created in SUFYAN AI EDITOR PRO',
          url: window.location.href
        });
        setShareSuccess(true);
      } else {
        setSaveNotice('Web Share is not supported by your current browser. Saved file directly to device downloads!');
        handleSaveToDevice();
      }
    } catch (e) {
      if ((e as Error).name !== 'AbortError') {
        console.warn('Share dismissed or unsupported:', e);
      }
    }
  };

  // Save to Device Storage (with File System Access API if supported)
  const handleSaveToDevice = async () => {
    if (!downloadResult) return;

    if ('showSaveFilePicker' in window) {
      try {
        const handle = await (window as any).showSaveFilePicker({
          suggestedName: downloadResult.filename,
          types: [
            {
              description: 'Video File',
              accept: { 'video/mp4': ['.mp4'], 'video/webm': ['.webm'] }
            }
          ]
        });
        const writable = await handle.createWritable();
        await writable.write(downloadResult.blob);
        await writable.close();
        setSaveNotice('Video saved directly to selected device folder!');
        return;
      } catch (e) {
        // User cancelled picker or fallback to standard anchor
      }
    }

    const a = document.createElement('a');
    a.href = downloadResult.url;
    a.download = downloadResult.filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setSaveNotice('Download initiated to your device Downloads folder.');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn overflow-y-auto">
      <div className="w-full max-w-2xl bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-zinc-800/80 bg-zinc-900/70 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <Film className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm sm:text-base font-bold text-white tracking-wide">EXPORT VIDEO STUDIO</h2>
                <span className="text-[10px] bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 font-bold px-1.5 py-0.5 rounded">
                  720p - 10K
                </span>
              </div>
              <p className="text-[11px] text-zinc-400">100% Free • No Watermark • Real Device Rendering</p>
            </div>
          </div>
          {!isExporting && (
            <button
              onClick={onClose}
              className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Tab Switcher: Settings vs Social Guides */}
        {!isExporting && !downloadResult && (
          <div className="flex border-b border-zinc-800/80 bg-zinc-900/40 px-6 pt-2 shrink-0">
            <button
              onClick={() => setActiveTab('settings')}
              className={`pb-2 px-3 text-xs font-semibold border-b-2 transition ${
                activeTab === 'settings'
                  ? 'border-cyan-400 text-cyan-400'
                  : 'border-transparent text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Export Resolution & Quality
            </button>
            <button
              onClick={() => setActiveTab('social_guide')}
              className={`pb-2 px-3 text-xs font-semibold border-b-2 transition ${
                activeTab === 'social_guide'
                  ? 'border-cyan-400 text-cyan-400'
                  : 'border-transparent text-zinc-400 hover:text-zinc-200'
              }`}
            >
              TikTok / YouTube / Reels Guides
            </button>
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-6 space-y-5 overflow-y-auto flex-1">
          {/* SETTINGS VIEW */}
          {!isExporting && !downloadResult && activeTab === 'settings' && (
            <>
              {/* Technical Truth & No-Watermark Guarantee */}
              <div className="flex items-start space-x-2.5 p-3 rounded-xl bg-emerald-950/25 border border-emerald-500/25 text-emerald-300 text-xs">
                <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                <div>
                  <span className="font-bold">Zero Watermark & On-Device Processing: </span>
                  <span className="text-zinc-300">
                    Your video is rendered directly on your phone or computer. No watermarks are added, and no clips are uploaded to private cloud servers.
                  </span>
                </div>
              </div>

              {/* Resolution Grid: 720p, 1080p, 1440p, 4K, 8K, 10K */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-semibold text-zinc-200 flex items-center space-x-1.5">
                    <span>Export Resolution:</span>
                    <span className="text-cyan-400 font-mono font-bold">{settings.resolution.toUpperCase()}</span>
                  </label>
                  <span className="text-[11px] text-zinc-400 font-mono">
                    Output: {outputDims.width} × {outputDims.height}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {(['720p', '1080p', '1440p', '4k', '8k', '10k'] as ExportResolution[]).map((res) => {
                    const isSelected = settings.resolution === res;
                    const spec = RESOLUTION_SPECS[res];
                    const isHighMemory = res === '8k' || res === '10k';
                    const isUhd = res === '4k';

                    return (
                      <button
                        key={res}
                        type="button"
                        onClick={() => setSettings({ ...settings, resolution: res })}
                        className={`p-3 rounded-xl border text-left transition relative flex flex-col justify-between ${
                          isSelected
                            ? 'border-cyan-400 bg-cyan-950/30 ring-1 ring-cyan-400/50 text-white'
                            : 'border-zinc-800 bg-zinc-900/80 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between">
                            <span className="font-extrabold text-sm text-zinc-100 uppercase">{res}</span>
                            {res === '1080p' && (
                              <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1 py-0.5 rounded font-bold">
                                REC
                              </span>
                            )}
                            {isUhd && (
                              <span className="text-[9px] bg-purple-500/20 text-purple-300 px-1 py-0.5 rounded font-bold">
                                UHD
                              </span>
                            )}
                            {isHighMemory && (
                              <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1 py-0.5 rounded font-bold">
                                PRO PC
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-zinc-400 mt-1 font-mono">{spec.label.split(' ')[0]}</div>
                        </div>

                        <div className="text-[9px] text-zinc-500 mt-2">
                          Min RAM: {spec.minRamGb}GB {isHighMemory ? '• Workstation' : '• Mobile OK'}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Technical Honesty & Transparency Notice */}
              {isUpscaled ? (
                <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-200 text-xs space-y-1">
                  <div className="flex items-center space-x-1.5 font-bold">
                    <Info className="w-3.5 h-3.5 shrink-0" />
                    <span>Technical Honesty: Ultra Canvas Rasterization</span>
                  </div>
                  <p className="text-[11px] text-zinc-300 leading-relaxed">
                    Exporting at {settings.resolution.toUpperCase()} creates an ultra-high resolution canvas. Text titles, subtitles, transitions, and overlays will render with razor-sharp pixel precision. However, camera clips shot at 1080p will be interpolated; genuine optical sensor detail cannot be falsely invented. High GPU memory is required.
                  </p>
                </div>
              ) : (
                <div className="p-3 rounded-xl bg-zinc-900/60 border border-zinc-800 text-zinc-400 text-xs flex items-center space-x-2">
                  <CheckCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Optimal mobile performance. Suitable for all Android phones, iPhones, and tablets without overheating.</span>
                </div>
              )}

              {/* FPS & Quality Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Frame Rate (FPS) */}
                <div>
                  <label className="text-xs font-semibold text-zinc-300 block mb-1.5">Frame Rate (FPS):</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setSettings({ ...settings, fps: 30 })}
                      className={`py-2 px-3 rounded-xl border text-xs text-center transition ${
                        settings.fps === 30
                          ? 'border-cyan-400 bg-cyan-950/30 text-white font-bold'
                          : 'border-zinc-800 bg-zinc-900 text-zinc-400'
                      }`}
                    >
                      30 FPS (Standard)
                    </button>
                    <button
                      type="button"
                      onClick={() => setSettings({ ...settings, fps: 60 })}
                      className={`py-2 px-3 rounded-xl border text-xs text-center transition ${
                        settings.fps === 60
                          ? 'border-cyan-400 bg-cyan-950/30 text-white font-bold'
                          : 'border-zinc-800 bg-zinc-900 text-zinc-400'
                      }`}
                    >
                      60 FPS (Ultra Smooth)
                    </button>
                  </div>
                </div>

                {/* Bitrate Quality */}
                <div>
                  <label className="text-xs font-semibold text-zinc-300 block mb-1.5">Bitrate Preset:</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setSettings({ ...settings, quality: 'high' })}
                      className={`py-2 px-3 rounded-xl border text-xs text-center transition ${
                        settings.quality === 'high'
                          ? 'border-cyan-400 bg-cyan-950/30 text-white font-semibold'
                          : 'border-zinc-800 bg-zinc-900 text-zinc-400'
                      }`}
                    >
                      High (Balanced)
                    </button>
                    <button
                      type="button"
                      onClick={() => setSettings({ ...settings, quality: 'ultra' })}
                      className={`py-2 px-3 rounded-xl border text-xs text-center transition ${
                        settings.quality === 'ultra'
                          ? 'border-cyan-400 bg-cyan-950/30 text-white font-semibold'
                          : 'border-zinc-800 bg-zinc-900 text-zinc-400'
                      }`}
                    >
                      Ultra (Master)
                    </button>
                  </div>
                </div>
              </div>

              {/* Live Render Telemetry & File Size Estimate */}
              <div className="p-3.5 rounded-xl bg-zinc-900/90 border border-zinc-800 text-xs space-y-2">
                <div className="text-zinc-400 font-semibold flex items-center space-x-1.5">
                  <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Real-Time Output Specifications:</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono">
                  <div>
                    <span className="text-zinc-500 block text-[9px]">DIMENSIONS</span>
                    <span className="text-zinc-200">{outputDims.width}x{outputDims.height}</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block text-[9px]">EST. FILE SIZE</span>
                    <span className="text-emerald-400 font-bold">~{estimatedSizeMb} MB</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block text-[9px]">ENCODING CODEC</span>
                    <span className="text-zinc-200">H.264 / VP9 WebM</span>
                  </div>
                  <div>
                    <span className="text-zinc-500 block text-[9px]">PROJECT DURATION</span>
                    <span className="text-zinc-200">{totalDurationSec.toFixed(1)}s</span>
                  </div>
                </div>
              </div>

              {/* 1-Tap Export Verification Test Button */}
              <div className="p-3.5 rounded-xl bg-gradient-to-r from-zinc-900 via-zinc-950 to-zinc-900 border border-cyan-500/30 flex items-center justify-between flex-wrap gap-2">
                <div>
                  <span className="text-xs font-bold text-white flex items-center space-x-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Instant Export Verification (3s Test)</span>
                  </span>
                  <p className="text-[10px] text-zinc-400 mt-0.5">
                    Renders a 3s test clip with animated background, text titles & audio beat to verify video export.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleRunTestExport}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold rounded-xl text-xs flex items-center space-x-1.5 transition shadow-sm"
                >
                  <Play className="w-3.5 h-3.5 fill-black" />
                  <span>Run 3s Test</span>
                </button>
              </div>
            </>
          )}

          {/* SOCIAL PLATFORM GUIDES TAB */}
          {!isExporting && !downloadResult && activeTab === 'social_guide' && (
            <div className="space-y-4">
              <div className="text-xs text-zinc-400">
                Official upload recommendations for major video and social platforms:
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SOCIAL_PLATFORMS.map((platform) => (
                  <div
                    key={platform.name}
                    className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-sm" style={{ color: platform.color }}>
                        {platform.name}
                      </span>
                      <span className="text-[10px] text-zinc-400 bg-zinc-800 px-1.5 py-0.5 rounded">
                        {platform.recommendedAspect}
                      </span>
                    </div>
                    <div className="text-[11px] text-zinc-300">
                      <div className="font-semibold text-zinc-200">Settings: {platform.recommendedRes} @ {platform.recommendedFps}</div>
                      <p className="text-zinc-400 text-[10px] mt-1 leading-relaxed">{platform.tip}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-[11px] text-zinc-400 space-y-1">
                <span className="font-bold text-zinc-300 block">Direct In-App Publishing Notice:</span>
                <p>
                  Official social platforms (TikTok, Instagram, YouTube) require authorized OAuth credentials from developer portals to publish videos directly from third-party tools. To protect your social passwords and retain full account ownership, SUFYAN AI EDITOR PRO exports directly to your phone gallery so you can upload directly via your official apps.
                </p>
              </div>
            </div>
          )}

          {/* EXPORT IN PROGRESS VIEW */}
          {isExporting && (
            <div className="py-6 space-y-5 text-center">
              <div className="relative w-24 h-24 mx-auto">
                <div className="absolute inset-0 rounded-full border-4 border-zinc-800 border-t-cyan-400 animate-spin" />
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="font-bold text-lg text-cyan-400 font-mono">
                    {progressData?.progress || 0}%
                  </span>
                  <span className="text-[9px] text-zinc-400 font-mono">RENDERING</span>
                </div>
              </div>

              <div>
                <h3 className="text-base font-bold text-white">
                  Rendering {settings.resolution.toUpperCase()} Video On-Device...
                </h3>
                <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
                  Compositing clips, color grades, text overlays, and cinematic filters into master video stream.
                </p>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-zinc-900 h-2.5 rounded-full overflow-hidden border border-zinc-800">
                <div
                  className="bg-gradient-to-r from-cyan-400 to-blue-500 h-full transition-all duration-150"
                  style={{ width: `${progressData?.progress || 0}%` }}
                />
              </div>

              {/* Detailed Progress Stats */}
              <div className="w-full bg-zinc-900 rounded-xl p-3 border border-zinc-800 text-xs grid grid-cols-3 gap-2 text-zinc-300 font-mono">
                <div>
                  <span className="text-zinc-500 block text-[10px]">FRAMES RENDERED</span>
                  <span>{progressData?.currentFrame || 0} / {progressData?.totalFrames || 0}</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px]">ELAPSED TIME</span>
                  <span>{progressData?.elapsedSeconds || 0}s</span>
                </div>
                <div>
                  <span className="text-zinc-500 block text-[10px]">EST. REMAINING</span>
                  <span>~{progressData?.remainingSeconds || 0}s</span>
                </div>
              </div>

              {/* Abort / Cancel Button */}
              <button
                type="button"
                onClick={handleCancelExport}
                className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-red-950/40 hover:bg-red-950/70 border border-red-500/30 text-xs text-red-400 font-medium transition"
              >
                <StopCircle className="w-3.5 h-3.5" />
                <span>Cancel Export</span>
              </button>
            </div>
          )}

          {/* DOWNLOAD COMPLETED VIEW */}
          {downloadResult && (
            <div className="py-4 space-y-4 text-center">
              <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-xl shadow-emerald-500/10">
                <CheckCircle className="w-6 h-6" />
              </div>

              <div>
                <h3 className="text-base font-bold text-white">Video Export Ready & Verified!</h3>
                <p className="text-xs text-zinc-400 mt-0.5 font-mono">
                  {downloadResult.filename} • {settings.resolution.toUpperCase()} @ {settings.fps} FPS
                </p>
              </div>

              {/* Live Playback Verification Player */}
              <div className="max-w-md mx-auto rounded-xl overflow-hidden border border-zinc-700 bg-black shadow-2xl">
                <video
                  src={downloadResult.url}
                  controls
                  playsInline
                  autoPlay
                  className="w-full max-h-52 object-contain bg-black"
                />
              </div>

              {/* Verification Metrics */}
              <div className="flex items-center justify-center space-x-2 text-xs font-mono flex-wrap gap-1">
                <span className="bg-zinc-800 text-cyan-400 px-2.5 py-1 rounded-md font-bold">
                  {downloadResult.filename.endsWith('.mp4') ? 'Format: MP4 (H.264)' : 'Format: WebM (VP9)'}
                </span>
                <span className="bg-zinc-800 text-emerald-400 px-2.5 py-1 rounded-md font-bold">
                  Size: {downloadResult.blob.size > 1048576 ? (downloadResult.blob.size / (1024 * 1024)).toFixed(2) + ' MB' : (downloadResult.blob.size / 1024).toFixed(1) + ' KB'}
                </span>
                <span className="bg-zinc-800 text-zinc-300 px-2.5 py-1 rounded-md">
                  Status: Verified Playable
                </span>
              </div>

              {/* Notification Banner */}
              {saveNotice && (
                <div className="p-3 bg-emerald-950/80 border border-emerald-500/50 rounded-xl text-emerald-300 text-xs flex items-center justify-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{saveNotice}</span>
                </div>
              )}

              {/* Primary Actions */}
              <div className="space-y-2.5 max-w-md mx-auto">
                {/* Save to Device Storage */}
                <button
                  type="button"
                  onClick={handleSaveToDevice}
                  className="w-full py-3 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-black font-extrabold rounded-xl shadow-lg shadow-emerald-500/20 flex items-center justify-center space-x-2 transition"
                >
                  <Download className="w-5 h-5" />
                  <span>Save Video to Phone Gallery</span>
                </button>

                {/* Share directly using Web Share API */}
                <button
                  type="button"
                  onClick={handleShareToSocial}
                  className="w-full py-2.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-white font-semibold rounded-xl text-xs flex items-center justify-center space-x-2 transition"
                >
                  <Share2 className="w-4 h-4 text-cyan-400" />
                  <span>Share to TikTok, Reels, YouTube or WhatsApp</span>
                </button>
              </div>

              {/* Android Download Location Tip */}
              <div className="p-3.5 rounded-xl bg-zinc-900/70 border border-zinc-800 text-left text-xs text-zinc-400 space-y-1">
                <div className="flex items-center space-x-1.5 text-zinc-200 font-semibold">
                  <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Android & Mobile Download Location:</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  Your video is saved directly into your device's <strong>Downloads</strong> or <strong>Movies</strong> directory. Open your phone's Gallery, Google Photos, or Files app to view, share, or set as status.
                </p>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setDownloadResult(null);
                    onClose();
                  }}
                  className="py-2 px-6 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-medium rounded-xl text-xs transition"
                >
                  Close Export Studio
                </button>
              </div>
            </div>
          )}

          {/* Error Message */}
          {errorMsg && (
            <div className="flex items-center space-x-2 p-3 bg-red-950/40 border border-red-500/30 rounded-xl text-red-300 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        {!isExporting && !downloadResult && activeTab === 'settings' && (
          <div className="flex items-center justify-between px-5 sm:px-6 py-3.5 bg-zinc-900/70 border-t border-zinc-800/80 shrink-0">
            <span className="text-xs text-zinc-400 font-mono hidden sm:inline">
              Est. ~{estimatedSizeMb} MB
            </span>
            <div className="flex items-center space-x-3 ml-auto">
              <button
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-zinc-400 hover:text-white transition"
              >
                Cancel
              </button>
              <button
                onClick={handleStartExport}
                disabled={project.clips.length === 0}
                className="flex items-center space-x-2 px-5 py-2.5 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 hover:from-cyan-300 hover:to-purple-500 text-black font-extrabold rounded-xl text-xs shadow-lg shadow-cyan-500/20 transition disabled:opacity-40"
              >
                <Zap className="w-4 h-4" />
                <span>Export ({settings.resolution.toUpperCase()})</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
