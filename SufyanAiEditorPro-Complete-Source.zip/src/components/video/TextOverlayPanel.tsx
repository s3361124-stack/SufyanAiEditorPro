import React, { useState } from 'react';
import {
  Type,
  Plus,
  Trash2,
  Film,
  Sparkles,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Move
} from 'lucide-react';
import { TextOverlay } from '../../types/editor';

interface TextOverlayPanelProps {
  textOverlays: TextOverlay[];
  onUpdateTextOverlays: (overlays: TextOverlay[]) => void;
  projectDuration: number;
  currentTime: number;
}

export const TextOverlayPanel: React.FC<TextOverlayPanelProps> = ({
  textOverlays,
  onUpdateTextOverlays,
  projectDuration,
  currentTime
}) => {
  const [selectedOverlayId, setSelectedOverlayId] = useState<string | null>(null);

  // Add custom text
  const handleAddText = (type: 'title' | 'subtitle' | 'caption' | 'credits') => {
    let defaultText = 'New Title';
    let fontSize = 48;
    let yPos = 50;
    let anim: 'none' | 'fade' | 'zoom-in' | 'scroll-up' = 'none';

    if (type === 'title') {
      defaultText = 'A SUFYAN FILM';
      fontSize = 56;
      anim = 'zoom-in';
      yPos = 50;
    } else if (type === 'subtitle') {
      defaultText = 'Watch this cinematic moment...';
      fontSize = 32;
      anim = 'fade';
      yPos = 85;
    } else if (type === 'caption') {
      defaultText = 'SUBSCRIBE FOR MORE 🔥';
      fontSize = 36;
      anim = 'fade';
      yPos = 20;
    } else if (type === 'credits') {
      defaultText = 'DIRECTED BY SUFYAN\nCINEMATOGRAPHY • PRODUCER\nTHANK YOU FOR WATCHING';
      fontSize = 28;
      anim = 'scroll-up';
      yPos = 50;
    }

    const newOverlay: TextOverlay = {
      id: 'text_' + Math.random().toString(36).substring(2, 9),
      text: defaultText,
      type,
      startTime: Math.max(0, currentTime),
      endTime: Math.min(projectDuration || 10, currentTime + (type === 'credits' ? 8 : 4)),
      x: 50,
      y: yPos,
      fontSize,
      fontFamily: 'Inter, sans-serif',
      color: '#FFFFFF',
      backgroundColor: type === 'subtitle' ? 'rgba(0, 0, 0, 0.75)' : 'transparent',
      borderColor: type === 'caption' ? '#000000' : undefined,
      align: 'center',
      animation: anim
    };

    onUpdateTextOverlays([...textOverlays, newOverlay]);
    setSelectedOverlayId(newOverlay.id);
  };

  const selectedOverlay = textOverlays.find((o) => o.id === selectedOverlayId) || null;

  const handleUpdateSelected = (updatedProps: Partial<TextOverlay>) => {
    if (!selectedOverlayId) return;
    onUpdateTextOverlays(
      textOverlays.map((o) => (o.id === selectedOverlayId ? { ...o, ...updatedProps } : o))
    );
  };

  const handleDeleteSelected = () => {
    if (!selectedOverlayId) return;
    onUpdateTextOverlays(textOverlays.filter((o) => o.id !== selectedOverlayId));
    setSelectedOverlayId(null);
  };

  return (
    <div className="w-full flex flex-col bg-zinc-950 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
        <div className="flex items-center space-x-2">
          <Type className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-semibold text-white tracking-wide">MOVIE TITLES, CAPTIONS & CREDITS</h3>
        </div>

        {/* Quick Add Buttons */}
        <div className="flex items-center space-x-1.5">
          <button
            onClick={() => handleAddText('title')}
            className="flex items-center space-x-1 px-2.5 py-1 bg-zinc-800 hover:bg-cyan-500 hover:text-black text-cyan-400 rounded-lg text-xs font-medium border border-zinc-700 transition"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>+ Cinema Title</span>
          </button>
          <button
            onClick={() => handleAddText('subtitle')}
            className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg text-xs font-medium border border-zinc-700 transition"
          >
            + Subtitle
          </button>
          <button
            onClick={() => handleAddText('credits')}
            className="flex items-center space-x-1 px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg text-xs font-medium border border-zinc-700 transition"
          >
            <Film className="w-3.5 h-3.5" />
            <span>+ End Credits</span>
          </button>
        </div>
      </div>

      {/* Overlays List */}
      <div>
        <label className="text-xs font-medium text-zinc-400 block mb-2">Active Text in Video:</label>
        {textOverlays.length === 0 ? (
          <div className="p-4 bg-zinc-900/60 rounded-xl border border-zinc-800/80 text-center text-xs text-zinc-500">
            No text overlays added yet. Tap <strong>"+ Cinema Title"</strong> or <strong>"+ Subtitle"</strong> above.
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {textOverlays.map((item) => (
              <button
                key={item.id}
                onClick={() => setSelectedOverlayId(item.id)}
                className={`px-3 py-1.5 rounded-lg border text-xs flex items-center space-x-2 transition ${
                  selectedOverlayId === item.id
                    ? 'border-cyan-400 bg-cyan-950/40 text-white font-medium'
                    : 'border-zinc-800 bg-zinc-900 text-zinc-300 hover:border-zinc-700'
                }`}
              >
                <span>{item.type === 'title' ? '🎬' : item.type === 'credits' ? '📜' : '💬'}</span>
                <span className="truncate max-w-[140px]">{item.text.replace('\n', ' ')}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Editor Drawer for Selected Text */}
      {selectedOverlay && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2">
            <span className="text-xs font-semibold text-zinc-300">Edit Text Element</span>
            <button
              onClick={handleDeleteSelected}
              className="flex items-center space-x-1 text-xs text-red-400 hover:text-red-300"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete</span>
            </button>
          </div>

          {/* Text Input */}
          <div>
            <textarea
              rows={2}
              value={selectedOverlay.text}
              onChange={(e) => handleUpdateSelected({ text: e.target.value })}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500"
              placeholder="Enter text..."
            />
          </div>

          {/* Controls Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            {/* Color */}
            <div>
              <label className="text-[11px] text-zinc-400 block mb-1">Color:</label>
              <div className="flex items-center space-x-1">
                {['#FFFFFF', '#38BDF8', '#F59E0B', '#EF4444', '#10B981', '#E5E7EB'].map((color) => (
                  <button
                    key={color}
                    onClick={() => handleUpdateSelected({ color })}
                    className={`w-5 h-5 rounded-full border ${selectedOverlay.color === color ? 'ring-2 ring-cyan-400' : 'border-zinc-700'}`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            {/* Font Size */}
            <div>
              <label className="text-[11px] text-zinc-400 block mb-1">Size ({selectedOverlay.fontSize}px):</label>
              <input
                type="range"
                min="18"
                max="80"
                value={selectedOverlay.fontSize}
                onChange={(e) => handleUpdateSelected({ fontSize: Number(e.target.value) })}
                className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded"
              />
            </div>

            {/* Vertical Position */}
            <div>
              <label className="text-[11px] text-zinc-400 block mb-1">Y Position ({selectedOverlay.y}%):</label>
              <input
                type="range"
                min="5"
                max="95"
                value={selectedOverlay.y}
                onChange={(e) => handleUpdateSelected({ y: Number(e.target.value) })}
                className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded"
              />
            </div>

            {/* Animation Style */}
            <div>
              <label className="text-[11px] text-zinc-400 block mb-1">Animation:</label>
              <select
                value={selectedOverlay.animation}
                onChange={(e) => handleUpdateSelected({ animation: e.target.value as any })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded p-1 text-xs text-white"
              >
                <option value="none">None (Static)</option>
                <option value="fade">Smooth Fade In/Out</option>
                <option value="zoom-in">Cinematic Zoom In</option>
                <option value="scroll-up">Hollywood Credits Roll</option>
              </select>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
