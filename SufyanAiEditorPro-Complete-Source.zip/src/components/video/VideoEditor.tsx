import React, { useState, useEffect, useRef } from 'react';
import {
  Undo,
  Redo,
  Download,
  Palette,
  Music,
  Type,
  Layers,
  Sparkles,
  Share2,
  Smartphone,
  FolderOpen
} from 'lucide-react';
import { VideoProject, VideoClip, AspectRatio, ColorGradeSettings, TextOverlay, AudioTrack } from '../../types/editor';
import { PreviewPlayer } from './PreviewPlayer';
import { Timeline } from './Timeline';
import { ColorGradingPanel } from './ColorGradingPanel';
import { AudioPanel } from './AudioPanel';
import { TextOverlayPanel } from './TextOverlayPanel';
import { ExportModal } from './ExportModal';
import { GalleryPickerModal } from '../gallery/GalleryPickerModal';

const DEFAULT_PROJECT: VideoProject = {
  id: 'proj_default',
  name: 'My Cinematic Movie',
  createdAt: Date.now(),
  updatedAt: Date.now(),
  aspectRatio: '16:9',
  clips: [],
  transitions: {},
  colorGrade: {
    preset: 'original',
    brightness: 0,
    contrast: 0,
    saturation: 0,
    temperature: 0,
    sharpness: 0,
    vignette: 0,
    filmGrain: 0,
    letterbox: false,
    letterboxHeight: 12
  },
  textOverlays: [],
  pipOverlays: [],
  audioTracks: []
};

interface VideoEditorProps {
  onNavigateToAndroid?: () => void;
  externalProject?: VideoProject;
  onUpdateExternalProject?: (project: VideoProject) => void;
}

export const VideoEditor: React.FC<VideoEditorProps> = ({
  onNavigateToAndroid,
  externalProject,
  onUpdateExternalProject
}) => {
  // Load initial project from external prop, localStorage, or fallback
  const [project, setProject] = useState<VideoProject>(() => {
    if (externalProject) return externalProject;
    try {
      const saved = localStorage.getItem('sufyan_video_project');
      if (saved) {
        const parsed: VideoProject = JSON.parse(saved);
        if (parsed.clips && Array.isArray(parsed.clips)) {
          parsed.clips = parsed.clips.filter((c) => !c.sourceUrl.startsWith('blob:'));
        }
        return parsed;
      }
    } catch (e) {}
    return DEFAULT_PROJECT;
  });

  // Keep synced if externalProject updates
  useEffect(() => {
    if (externalProject) {
      setProject(externalProject);
    }
  }, [externalProject]);

  const [history, setHistory] = useState<VideoProject[]>([project]);
  const [historyIndex, setHistoryIndex] = useState(0);

  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'color' | 'audio' | 'text'>('color');
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);

  // Calculate total duration across clips
  const totalDuration = project.clips.reduce(
    (sum, c) => sum + (c.endTime - c.startTime) / c.playbackRate,
    0
  );

  // Playhead update loop
  useEffect(() => {
    let timer: number;
    if (isPlaying) {
      const intervalMs = 1000 / 30; // 30 FPS playback step
      timer = window.setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= totalDuration && totalDuration > 0) {
            setIsPlaying(false);
            return 0; // loop or reset
          }
          return Math.min(totalDuration, prev + 1 / 30);
        });
      }, intervalMs);
    }
    return () => clearInterval(timer);
  }, [isPlaying, totalDuration]);

  // Push to undo/redo history
  const updateProjectWithHistory = (newProject: VideoProject) => {
    const updated = { ...newProject, updatedAt: Date.now() };
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(updated);
    if (newHistory.length > 25) newHistory.shift();

    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    setProject(updated);

    try {
      localStorage.setItem('sufyan_video_project', JSON.stringify(updated));
    } catch (e) {}
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const prev = history[historyIndex - 1];
      setHistoryIndex(historyIndex - 1);
      setProject(prev);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const next = history[historyIndex + 1];
      setHistoryIndex(historyIndex + 1);
      setProject(next);
    }
  };

  const handleTogglePlay = () => {
    if (currentTime >= totalDuration && totalDuration > 0) {
      setCurrentTime(0);
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="w-full flex flex-col space-y-4">
      {/* Top Video Toolbar: Project title, Undo/Redo, Export Button */}
      <div className="flex items-center justify-between bg-zinc-950 border border-zinc-800 rounded-2xl px-4 py-2.5 shadow-lg">
        <div className="flex items-center space-x-3">
          <input
            type="text"
            value={project.name}
            onChange={(e) => updateProjectWithHistory({ ...project, name: e.target.value })}
            className="bg-transparent font-bold text-sm text-white focus:outline-none focus:border-b focus:border-cyan-400 max-w-[180px] sm:max-w-xs truncate"
            title="Edit Project Title"
          />
          <span className="hidden sm:inline-block text-[11px] bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded font-mono">
            {project.clips.length} {project.clips.length === 1 ? 'clip' : 'clips'}
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {/* Undo / Redo */}
          <button
            onClick={handleUndo}
            disabled={historyIndex <= 0}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition disabled:opacity-30"
            title="Undo"
          >
            <Undo className="w-4 h-4" />
          </button>
          <button
            onClick={handleRedo}
            disabled={historyIndex >= history.length - 1}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition disabled:opacity-30"
            title="Redo"
          >
            <Redo className="w-4 h-4" />
          </button>

          {/* Quick APK shortcut for creators */}
          {onNavigateToAndroid && (
            <button
              onClick={onNavigateToAndroid}
              className="hidden sm:flex items-center space-x-1 px-2.5 py-1.5 rounded-xl text-xs bg-red-950/40 border border-red-500/50 text-red-300 hover:text-white hover:bg-red-900/50 transition font-medium shadow-sm"
              title="Download Android APK & Build Instructions"
            >
              <Smartphone className="w-3.5 h-3.5 text-red-400" />
              <span>Android APK</span>
            </button>
          )}

          {/* Gallery Import Picker Button */}
          <button
            onClick={() => setIsGalleryOpen(true)}
            className="flex items-center space-x-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-zinc-200 hover:text-white font-semibold px-3 py-1.5 rounded-xl text-xs transition shadow-sm"
            title="Import Video, Photo, or Audio from Phone Gallery"
          >
            <FolderOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Import</span>
            <span>Gallery</span>
          </button>

          {/* Export Video Button */}
          <button
            onClick={() => setIsExportModalOpen(true)}
            disabled={project.clips.length === 0}
            className="flex items-center space-x-1.5 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold px-4 py-1.5 rounded-xl text-xs transition shadow-md shadow-cyan-500/20 disabled:opacity-40"
          >
            <Download className="w-4 h-4" />
            <span>Export Video</span>
          </button>
        </div>
      </div>

      {/* Main Preview Player */}
      <PreviewPlayer
        project={project}
        currentTime={currentTime}
        isPlaying={isPlaying}
        onTimeUpdate={(t) => setCurrentTime(t)}
        onTogglePlay={handleTogglePlay}
        onAspectRatioChange={(aspectRatio: AspectRatio) =>
          updateProjectWithHistory({ ...project, aspectRatio })
        }
        totalDuration={totalDuration}
      />

      {/* Multi-Clip Timeline */}
      <Timeline
        project={project}
        currentTime={currentTime}
        selectedClipId={selectedClipId}
        onSelectClip={(id) => setSelectedClipId(id)}
        onTimeUpdate={(t) => setCurrentTime(t)}
        onUpdateClips={(clips: VideoClip[]) =>
          updateProjectWithHistory({ ...project, clips })
        }
        totalDuration={totalDuration}
      />

      {/* Tool Dock Tabs Navigation */}
      <div className="flex items-center justify-center space-x-2 bg-zinc-950 p-1.5 rounded-2xl border border-zinc-800">
        <button
          onClick={() => setActiveTab('color')}
          className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition ${
            activeTab === 'color'
              ? 'bg-zinc-800 text-white shadow-sm ring-1 ring-zinc-700'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Palette className="w-4 h-4 text-cyan-400" />
          <span>Cinematic Color / LUTs</span>
        </button>

        <button
          onClick={() => setActiveTab('audio')}
          className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition ${
            activeTab === 'audio'
              ? 'bg-zinc-800 text-white shadow-sm ring-1 ring-zinc-700'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Music className="w-4 h-4 text-amber-400" />
          <span>Audio, Music & Voice</span>
        </button>

        <button
          onClick={() => setActiveTab('text')}
          className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition ${
            activeTab === 'text'
              ? 'bg-zinc-800 text-white shadow-sm ring-1 ring-zinc-700'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Type className="w-4 h-4 text-purple-400" />
          <span>Titles & Subtitles</span>
        </button>
      </div>

      {/* Active Tab Subpanel */}
      {activeTab === 'color' && (
        <ColorGradingPanel
          colorGrade={project.colorGrade}
          onChange={(colorGrade: ColorGradeSettings) =>
            updateProjectWithHistory({ ...project, colorGrade })
          }
        />
      )}

      {activeTab === 'audio' && (
        <AudioPanel
          audioTracks={project.audioTracks}
          onUpdateAudioTracks={(audioTracks: AudioTrack[]) =>
            updateProjectWithHistory({ ...project, audioTracks })
          }
          projectDuration={totalDuration}
        />
      )}

      {activeTab === 'text' && (
        <TextOverlayPanel
          textOverlays={project.textOverlays}
          onUpdateTextOverlays={(textOverlays: TextOverlay[]) =>
            updateProjectWithHistory({ ...project, textOverlays })
          }
          projectDuration={totalDuration}
          currentTime={currentTime}
        />
      )}

      {/* Export Modal */}
      <ExportModal
        project={project}
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
      />

      {/* Gallery Import Picker Modal */}
      <GalleryPickerModal
        isOpen={isGalleryOpen}
        onClose={() => setIsGalleryOpen(false)}
        onSelectVideoClip={(newClip) => {
          updateProjectWithHistory({
            ...project,
            clips: [...project.clips, newClip]
          });
        }}
        onSelectPhoto={(photoUrl) => {
          const photoClip: VideoClip = {
            id: 'clip_img_' + Date.now(),
            name: 'Imported Photo',
            type: 'image',
            sourceUrl: photoUrl,
            duration: 4,
            startTime: 0,
            endTime: 4,
            playbackRate: 1.0,
            volume: 1.0,
            muted: true,
            rotation: 0,
            flipHorizontal: false,
            flipVertical: false,
            fitMode: 'cover'
          };
          updateProjectWithHistory({
            ...project,
            clips: [...project.clips, photoClip]
          });
        }}
        onSelectAudioTrack={(newTrack) => {
          updateProjectWithHistory({
            ...project,
            audioTracks: [...project.audioTracks, newTrack]
          });
        }}
      />
    </div>
  );
};
