import React, { useEffect, useRef, useState } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Maximize2,
  Minimize2,
  ChevronLeft,
  ChevronRight,
  Volume2,
  VolumeX,
  Smartphone,
  Tv,
  Film
} from 'lucide-react';
import { VideoProject, VideoClip, AspectRatio } from '../../types/editor';
import {
  getAspectRatioDimensions,
  buildCssFilter,
  applyCanvasCinematicEffects,
  drawClipToCanvas,
  drawTextOverlays,
  drawPipOverlays
} from '../../utils/videoRenderer';

interface PreviewPlayerProps {
  project: VideoProject;
  currentTime: number;
  isPlaying: boolean;
  onTimeUpdate: (time: number) => void;
  onTogglePlay: () => void;
  onAspectRatioChange: (aspectRatio: AspectRatio) => void;
  totalDuration: number;
}

export const PreviewPlayer: React.FC<PreviewPlayerProps> = ({
  project,
  currentTime,
  isPlaying,
  onTimeUpdate,
  onTogglePlay,
  onAspectRatioChange,
  totalDuration
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaElementsRef = useRef<Map<string, HTMLVideoElement | HTMLImageElement>>(new Map());
  const pipElementsRef = useRef<Map<string, HTMLImageElement>>(new Map());
  const audioElementsRef = useRef<Map<string, HTMLAudioElement>>(new Map());

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Synchronize and preload media elements
  useEffect(() => {
    project.clips.forEach((clip) => {
      if (!mediaElementsRef.current.has(clip.id)) {
        if (clip.type === 'video') {
          const video = document.createElement('video');
          if (!clip.sourceUrl.startsWith('data:') && !clip.sourceUrl.startsWith('blob:')) {
            video.crossOrigin = 'anonymous';
          }
          video.src = clip.sourceUrl;
          video.muted = true; // Mute video element to avoid autoplay blocks; audio handled via audioCtx/player
          video.preload = 'auto';
          video.playsInline = true;
          video.onerror = () => {
            console.warn(`Video clip ${clip.id} failed to load`);
          };
          mediaElementsRef.current.set(clip.id, video);
        } else {
          const img = new Image();
          if (!clip.sourceUrl.startsWith('data:') && !clip.sourceUrl.startsWith('blob:')) {
            img.crossOrigin = 'anonymous';
          }
          img.src = clip.sourceUrl;
          img.onerror = () => {
            console.warn(`Image clip ${clip.id} failed to load`);
          };
          mediaElementsRef.current.set(clip.id, img);
        }
      }
    });

    // Clean up elements that were deleted
    const clipIds = new Set(project.clips.map((c) => c.id));
    mediaElementsRef.current.forEach((_, key) => {
      if (!clipIds.has(key)) {
        mediaElementsRef.current.delete(key);
      }
    });
  }, [project.clips]);

  // Synchronize audio tracks
  useEffect(() => {
    project.audioTracks.forEach((track) => {
      if (!audioElementsRef.current.has(track.id)) {
        const audio = new Audio(track.url);
        audio.preload = 'auto';
        audioElementsRef.current.set(track.id, audio);
      }
      const audio = audioElementsRef.current.get(track.id);
      if (audio) {
        audio.volume = isMuted ? 0 : Math.min(1, track.volume);
      }
    });
  }, [project.audioTracks, isMuted]);

  // Handle Play / Pause for active clip and audio
  useEffect(() => {
    if (isPlaying) {
      // Start audio tracks if in their time window
      project.audioTracks.forEach((track) => {
        const audio = audioElementsRef.current.get(track.id);
        if (audio && currentTime >= track.startTime && currentTime <= track.startTime + track.duration) {
          audio.currentTime = currentTime - track.startTime;
          audio.play().catch(() => {});
        }
      });
    } else {
      // Pause all audio
      audioElementsRef.current.forEach((audio) => audio.pause());
    }
  }, [isPlaying, currentTime, project.audioTracks]);

  // Render loop
  useEffect(() => {
    let animationFrameId: number;

    const render = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const dims = getAspectRatioDimensions(project.aspectRatio, 1280);
      if (canvas.width !== dims.width || canvas.height !== dims.height) {
        canvas.width = dims.width;
        canvas.height = dims.height;
      }

      // Background black fill
      ctx.fillStyle = '#0a0b0e';
      ctx.fillRect(0, 0, dims.width, dims.height);

      if (project.clips.length > 0) {
        // Calculate which clip is active at currentTime
        let accumulatedTime = 0;
        let activeClip: VideoClip | null = null;
        let clipLocalTime = 0;

        for (const clip of project.clips) {
          const effectiveDuration = (clip.endTime - clip.startTime) / clip.playbackRate;
          if (currentTime >= accumulatedTime && currentTime <= accumulatedTime + effectiveDuration) {
            activeClip = clip;
            clipLocalTime = clip.startTime + (currentTime - accumulatedTime) * clip.playbackRate;
            break;
          }
          accumulatedTime += effectiveDuration;
        }

        if (!activeClip && currentTime >= totalDuration) {
          activeClip = project.clips[project.clips.length - 1];
          clipLocalTime = activeClip.endTime;
        }

        if (activeClip) {
          const el = mediaElementsRef.current.get(activeClip.id);
          if (el) {
            if (activeClip.type === 'video' && el instanceof HTMLVideoElement) {
              if (isPlaying && el.paused) {
                el.playbackRate = activeClip.playbackRate;
                el.play().catch(() => {});
              } else if (!isPlaying && !el.paused) {
                el.pause();
              }

              // Keep video element synced if drift exceeds 0.15s
              if (Math.abs(el.currentTime - clipLocalTime) > 0.15) {
                el.currentTime = clipLocalTime;
              }
            }

            ctx.save();
            ctx.filter = buildCssFilter(project.colorGrade);
            drawClipToCanvas(ctx, el, activeClip, dims.width, dims.height);
            ctx.restore();

            // Apply cinematic overlay effects (temperature, vignette, grain, letterbox)
            applyCanvasCinematicEffects(ctx, dims.width, dims.height, project.colorGrade);
          }
        }
      } else {
        // Empty placeholder state on canvas
        ctx.fillStyle = '#1e222d';
        ctx.fillRect(0, 0, dims.width, dims.height);
        ctx.fillStyle = '#9ca3af';
        ctx.font = '28px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('NO CLIPS ADDED YET', dims.width / 2, dims.height / 2 - 20);
        ctx.font = '20px sans-serif';
        ctx.fillText('Import video or tap sample below to start', dims.width / 2, dims.height / 2 + 25);
      }

      // Draw active Text Overlays
      drawTextOverlays(ctx, project.textOverlays, currentTime, dims.width, dims.height);

      // Draw PIP Overlays
      drawPipOverlays(ctx, project.pipOverlays, currentTime, dims.width, dims.height, pipElementsRef.current);

      animationFrameId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animationFrameId);
  }, [project, currentTime, isPlaying, totalDuration]);

  // Fullscreen toggle
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const formatTimecode = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const hundredths = Math.floor((seconds % 1) * 100);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${hundredths.toString().padStart(2, '0')}`;
  };

  return (
    <div
      ref={containerRef}
      className={`relative flex flex-col items-center justify-center bg-black/95 rounded-2xl border border-zinc-800 shadow-2xl overflow-hidden ${
        isFullscreen ? 'w-full h-full p-4' : 'w-full py-2'
      }`}
    >
      {/* Aspect Ratio & Format Bar */}
      <div className="w-full flex items-center justify-between px-4 py-2 bg-zinc-900/80 border-b border-zinc-800/80 text-xs text-zinc-300">
        <div className="flex items-center space-x-2">
          <span className="text-zinc-500 font-medium">CANVAS FORMAT:</span>
          <div className="flex items-center space-x-1 bg-zinc-950 p-1 rounded-lg border border-zinc-800">
            <button
              onClick={() => onAspectRatioChange('16:9')}
              className={`px-2 py-0.5 rounded flex items-center space-x-1 text-xs transition ${
                project.aspectRatio === '16:9' ? 'bg-zinc-700 text-white font-semibold' : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title="16:9 Widescreen (YouTube / TV)"
            >
              <Tv className="w-3 h-3" />
              <span>16:9</span>
            </button>
            <button
              onClick={() => onAspectRatioChange('9:16')}
              className={`px-2 py-0.5 rounded flex items-center space-x-1 text-xs transition ${
                project.aspectRatio === '9:16' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title="9:16 Vertical (TikTok / Reels / Shorts)"
            >
              <Smartphone className="w-3 h-3" />
              <span>9:16</span>
            </button>
            <button
              onClick={() => onAspectRatioChange('1:1')}
              className={`px-2 py-0.5 rounded text-xs transition ${
                project.aspectRatio === '1:1' ? 'bg-zinc-700 text-white font-semibold' : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title="1:1 Square"
            >
              1:1
            </button>
            <button
              onClick={() => onAspectRatioChange('21:9')}
              className={`px-2 py-0.5 rounded flex items-center space-x-1 text-xs transition ${
                project.aspectRatio === '21:9' ? 'bg-amber-500/20 text-amber-300 font-semibold' : 'text-zinc-400 hover:text-zinc-200'
              }`}
              title="21:9 Cinematic Anamorphic"
            >
              <Film className="w-3 h-3" />
              <span>21:9</span>
            </button>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="font-mono text-zinc-300 text-xs bg-zinc-950 px-2.5 py-1 rounded border border-zinc-800">
            <span className="text-cyan-400 font-bold">{formatTimecode(currentTime)}</span>
            <span className="text-zinc-600 mx-1">/</span>
            <span className="text-zinc-400">{formatTimecode(totalDuration)}</span>
          </div>

          <button
            onClick={toggleFullscreen}
            className="p-1.5 hover:bg-zinc-800 rounded text-zinc-400 hover:text-white transition"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Video Viewport Canvas */}
      <div className="relative w-full flex items-center justify-center p-2 min-h-[260px] max-h-[460px] overflow-hidden bg-black/60">
        <canvas
          ref={canvasRef}
          onClick={onTogglePlay}
          className="max-h-[440px] max-w-full rounded-lg shadow-2xl object-contain cursor-pointer transition-all border border-zinc-800/80"
          style={{
            aspectRatio:
              project.aspectRatio === '16:9'
                ? '16/9'
                : project.aspectRatio === '9:16'
                ? '9/16'
                : project.aspectRatio === '1:1'
                ? '1/1'
                : project.aspectRatio === '4:5'
                ? '4/5'
                : '21/9'
          }}
        />

        {/* Big play overlay if paused */}
        {!isPlaying && project.clips.length > 0 && (
          <button
            onClick={onTogglePlay}
            className="absolute inset-auto w-16 h-16 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 text-white shadow-2xl transition transform hover:scale-110 active:scale-95"
            aria-label="Play"
          >
            <Play className="w-8 h-8 fill-current ml-1" />
          </button>
        )}

        {/* Brand Mascot Welcome Overlay when project has no clips */}
        {project.clips.length === 0 && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center select-none pointer-events-none">
            <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border-2 border-purple-500/90 shadow-[0_0_28px_rgba(168,85,247,0.55)] bg-black mb-3 pointer-events-auto">
              <img
                src="/logo.png"
                alt="SUFYAN AI EDITOR PRO"
                className="w-full h-full object-cover"
              />
            </div>
            <h3 className="font-extrabold text-base sm:text-lg text-white tracking-wider flex items-center space-x-1.5">
              <span>SUFYAN AI EDITOR</span>
              <span className="text-[10px] bg-gradient-to-r from-cyan-400 to-blue-500 text-black px-1.5 py-0.5 rounded font-black shadow-sm">
                PRO
              </span>
            </h3>
            <p className="text-xs text-zinc-400 mt-1 max-w-xs">
              Cinema color grading, multi-clip timeline & 1080p 60fps export. Tap <strong className="text-cyan-400">Add from Phone</strong> or <strong className="text-purple-300">Logo Intro</strong> below to start!
            </p>
          </div>
        )}
      </div>


      {/* Transport Control Buttons */}
      <div className="w-full flex items-center justify-between px-4 py-2.5 bg-zinc-900/90 border-t border-zinc-800">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onTimeUpdate(0)}
            className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition"
            title="Reset to Beginning"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={() => onTimeUpdate(Math.max(0, currentTime - 1))}
            className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition"
            title="Step Back 1s"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        </div>

        <button
          onClick={onTogglePlay}
          className={`flex items-center justify-center w-12 h-12 rounded-full font-bold shadow-lg transition active:scale-95 ${
            isPlaying
              ? 'bg-zinc-700 hover:bg-zinc-600 text-white'
              : 'bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black shadow-cyan-500/20'
          }`}
          title={isPlaying ? 'Pause' : 'Play'}
        >
          {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
        </button>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => onTimeUpdate(Math.min(totalDuration, currentTime + 1))}
            className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition"
            title="Step Forward 1s"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
          <button
            onClick={() => setIsMuted(!isMuted)}
            className={`p-2 rounded-lg transition ${isMuted ? 'text-red-400 hover:bg-red-950/40' : 'text-zinc-400 hover:text-white hover:bg-zinc-800'}`}
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};
