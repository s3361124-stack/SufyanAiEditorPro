import React, { useRef, useState } from 'react';
import {
  Scissors,
  Trash2,
  Copy,
  Plus,
  RotateCw,
  FlipHorizontal,
  ChevronLeft,
  ChevronRight,
  Gauge,
  Film,
  Sparkles,
  Maximize
} from 'lucide-react';
import { VideoClip, VideoProject } from '../../types/editor';
import { createProceduralVideoClip } from '../../utils/sampleMedia';
import { VideoTrimmer } from './VideoTrimmer';

interface TimelineProps {
  project: VideoProject;
  currentTime: number;
  selectedClipId: string | null;
  onSelectClip: (clipId: string | null) => void;
  onTimeUpdate: (time: number) => void;
  onUpdateClips: (clips: VideoClip[]) => void;
  totalDuration: number;
}

export const Timeline: React.FC<TimelineProps> = ({
  project,
  currentTime,
  selectedClipId,
  onSelectClip,
  onTimeUpdate,
  onUpdateClips,
  totalDuration
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const timelineTrackRef = useRef<HTMLDivElement>(null);
  const [isTrimmerOpen, setIsTrimmerOpen] = useState(true);

  const selectedClip = project.clips.find((c) => c.id === selectedClipId) || null;

  // Handle precision trim updates for selected clip
  const handleUpdateSelectedClip = (updatedClip: VideoClip) => {
    const updated = project.clips.map((c) => (c.id === updatedClip.id ? updatedClip : c));
    onUpdateClips(updated);
  };

  // Handle file import from Android phone storage
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newClips: VideoClip[] = [];

    Array.from(files).forEach((file) => {
      const isVideo = file.type.startsWith('video');
      const blobUrl = URL.createObjectURL(file);

      newClips.push({
        id: 'clip_' + Math.random().toString(36).substring(2, 9),
        name: file.name.substring(0, 24),
        type: isVideo ? 'video' : 'image',
        sourceUrl: blobUrl,
        duration: isVideo ? 10 : 4, // Default fallback duration; updated once metadata loaded
        startTime: 0,
        endTime: isVideo ? 10 : 4,
        playbackRate: 1.0,
        volume: 1.0,
        muted: false,
        rotation: 0,
        flipHorizontal: false,
        flipVertical: false,
        fitMode: 'cover'
      });
    });

    onUpdateClips([...project.clips, ...newClips]);
    if (newClips.length > 0) {
      onSelectClip(newClips[0].id);
    }
    // Reset file input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Add demo clip for instant test
  const handleAddSampleClip = async (theme: 'cinematic' | 'cyberpunk' | 'vlog' | 'sunset' | 'gaming') => {
    const names = {
      cinematic: 'Cinematic Movie Shot',
      cyberpunk: 'Neon Cyber Drive',
      vlog: 'Summer Travel Vlog',
      sunset: 'Golden Hour Sunset',
      gaming: 'Gaming Montage Action'
    };
    const clip = await createProceduralVideoClip(names[theme], theme, 5);
    onUpdateClips([...project.clips, clip]);
    onSelectClip(clip.id);
  };

  // Add SUFYAN Mascot Logo clip directly onto timeline
  const handleAddLogoClip = () => {
    const clip: VideoClip = {
      id: 'clip_' + Math.random().toString(36).substring(2, 9),
      name: 'SUFYAN Mascot Intro',
      type: 'image',
      sourceUrl: '/logo.png',
      duration: 4,
      startTime: 0,
      endTime: 4,
      playbackRate: 1.0,
      volume: 1.0,
      muted: true,
      rotation: 0,
      flipHorizontal: false,
      flipVertical: false,
      fitMode: 'cover'
    };
    onUpdateClips([...project.clips, clip]);
    onSelectClip(clip.id);
  };


  // Split active clip at current playhead position or selected clip
  const handleSplitClip = () => {
    if (project.clips.length === 0) return;

    let accumulated = 0;
    let clipToSplit: VideoClip | null = null;
    let clipIndex = -1;
    let localSplitTime = 0;

    // 1. Try to find clip directly under playhead
    for (let i = 0; i < project.clips.length; i++) {
      const clip = project.clips[i];
      const effDuration = (clip.endTime - clip.startTime) / clip.playbackRate;
      if (currentTime >= accumulated && currentTime <= accumulated + effDuration) {
        clipToSplit = clip;
        clipIndex = i;
        localSplitTime = clip.startTime + (currentTime - accumulated) * clip.playbackRate;
        break;
      }
      accumulated += effDuration;
    }

    // 2. Fallback to currently selected clip if playhead is not inside
    if ((!clipToSplit || clipIndex === -1) && selectedClipId) {
      clipIndex = project.clips.findIndex((c) => c.id === selectedClipId);
      if (clipIndex !== -1) {
        clipToSplit = project.clips[clipIndex];
        localSplitTime = (clipToSplit.startTime + clipToSplit.endTime) / 2;
      }
    }

    // 3. Fallback to first clip
    if (!clipToSplit || clipIndex === -1) {
      clipIndex = 0;
      clipToSplit = project.clips[0];
      localSplitTime = (clipToSplit.startTime + clipToSplit.endTime) / 2;
    }

    // Ensure valid duration padding (at least 0.15s on either side)
    const minPadding = 0.15;
    if (
      localSplitTime <= clipToSplit.startTime + minPadding ||
      localSplitTime >= clipToSplit.endTime - minPadding
    ) {
      localSplitTime = (clipToSplit.startTime + clipToSplit.endTime) / 2;
    }

    const firstHalf: VideoClip = {
      ...clipToSplit,
      id: 'clip_' + Math.random().toString(36).substring(2, 9),
      name: clipToSplit.name + ' (Part 1)',
      endTime: localSplitTime
    };

    const secondHalf: VideoClip = {
      ...clipToSplit,
      id: 'clip_' + Math.random().toString(36).substring(2, 9),
      name: clipToSplit.name + ' (Part 2)',
      startTime: localSplitTime
    };

    const updatedClips = [...project.clips];
    updatedClips.splice(clipIndex, 1, firstHalf, secondHalf);
    onUpdateClips(updatedClips);
    onSelectClip(secondHalf.id);
  };

  // Delete selected clip
  const handleDeleteClip = () => {
    if (!selectedClipId) return;
    const updated = project.clips.filter((c) => c.id !== selectedClipId);
    onUpdateClips(updated);
    onSelectClip(updated.length > 0 ? updated[0].id : null);
  };

  // Duplicate selected clip
  const handleDuplicateClip = () => {
    if (!selectedClip) return;
    const index = project.clips.findIndex((c) => c.id === selectedClipId);
    const duplicated: VideoClip = {
      ...selectedClip,
      id: 'clip_' + Math.random().toString(36).substring(2, 9),
      name: selectedClip.name + ' (Copy)'
    };
    const updated = [...project.clips];
    updated.splice(index + 1, 0, duplicated);
    onUpdateClips(updated);
    onSelectClip(duplicated.id);
  };

  // Reorder: Move Left / Move Right
  const handleMoveClip = (direction: 'left' | 'right') => {
    if (!selectedClipId) return;
    const index = project.clips.findIndex((c) => c.id === selectedClipId);
    if (direction === 'left' && index > 0) {
      const updated = [...project.clips];
      const temp = updated[index - 1];
      updated[index - 1] = updated[index];
      updated[index] = temp;
      onUpdateClips(updated);
    } else if (direction === 'right' && index < project.clips.length - 1) {
      const updated = [...project.clips];
      const temp = updated[index + 1];
      updated[index + 1] = updated[index];
      updated[index] = temp;
      onUpdateClips(updated);
    }
  };

  // Speed adjust
  const handleSpeedChange = (rate: number) => {
    if (!selectedClip) return;
    const updated = project.clips.map((c) => (c.id === selectedClip.id ? { ...c, playbackRate: rate } : c));
    onUpdateClips(updated);
  };

  // Rotate 90
  const handleRotate = () => {
    if (!selectedClip) return;
    const newRotation = (selectedClip.rotation + 90) % 360;
    const updated = project.clips.map((c) => (c.id === selectedClip.id ? { ...c, rotation: newRotation } : c));
    onUpdateClips(updated);
  };

  // Flip horizontal
  const handleFlipHorizontal = () => {
    if (!selectedClip) return;
    const updated = project.clips.map((c) =>
      c.id === selectedClip.id ? { ...c, flipHorizontal: !c.flipHorizontal } : c
    );
    onUpdateClips(updated);
  };

  // Timeline track click to seek
  const handleTrackClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!timelineTrackRef.current || totalDuration <= 0) return;
    const rect = timelineTrackRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const progress = Math.max(0, Math.min(1, clickX / rect.width));
    onTimeUpdate(progress * totalDuration);
  };

  // Timeline track touch drag to seek on mobile phones
  const handleTrackTouch = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!timelineTrackRef.current || totalDuration <= 0) return;
    const touch = e.touches[0];
    if (!touch) return;
    const rect = timelineTrackRef.current.getBoundingClientRect();
    const touchX = touch.clientX - rect.left;
    const progress = Math.max(0, Math.min(1, touchX / rect.width));
    onTimeUpdate(progress * totalDuration);
  };

  const playheadPercent = totalDuration > 0 ? (currentTime / totalDuration) * 100 : 0;

  return (
    <div className="w-full flex flex-col bg-zinc-950 border border-zinc-800 rounded-2xl p-3 shadow-xl space-y-3">
      {/* Hidden file input with universal Android Gallery & Photos MIME types */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*,video/mp4,video/webm,video/3gpp,video/quicktime,video/x-matroska,image/*,image/jpeg,image/png,image/webp,image/gif"
        multiple
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Top Action Toolbar */}
      <div className="flex items-center justify-between flex-wrap gap-2 text-xs">
        <div className="flex items-center space-x-1.5">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center space-x-1 bg-gradient-to-r from-zinc-800 to-zinc-700 hover:from-zinc-700 hover:to-zinc-600 text-white font-medium px-3 py-1.5 rounded-lg border border-zinc-700 shadow-sm transition"
          >
            <Plus className="w-3.5 h-3.5 text-cyan-400" />
            <span>Add from Phone</span>
          </button>

          {/* Quick Demo Sample Clip Menu */}
          <div className="flex items-center space-x-1 bg-zinc-900 border border-zinc-800 rounded-lg p-0.5">
            <span className="text-zinc-500 px-1.5 text-[10px] font-semibold">DEMO:</span>
            <button
              onClick={() => handleAddSampleClip('cinematic')}
              className="px-2 py-1 text-zinc-300 hover:text-white hover:bg-zinc-800 rounded text-[11px] transition"
              title="Add Cinematic Movie Sample"
            >
              Movie
            </button>
            <button
              onClick={() => handleAddSampleClip('cyberpunk')}
              className="px-2 py-1 text-zinc-300 hover:text-white hover:bg-zinc-800 rounded text-[11px] transition"
              title="Add Cyberpunk Neon Sample"
            >
              Neon
            </button>
            <button
              onClick={() => handleAddSampleClip('gaming')}
              className="px-2 py-1 text-zinc-300 hover:text-white hover:bg-zinc-800 rounded text-[11px] transition"
              title="Add Gaming Montage Sample"
            >
              Gaming
            </button>
            <button
              onClick={handleAddLogoClip}
              className="px-2 py-1 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 hover:from-purple-500/30 hover:to-cyan-500/30 text-cyan-300 border border-cyan-500/30 rounded text-[11px] font-semibold flex items-center space-x-1 transition"
              title="Add Official SUFYAN Mascot Logo Clip"
            >
              <Sparkles className="w-3 h-3 text-cyan-400" />
              <span>Logo Intro</span>
            </button>
          </div>

        </div>

        {/* Clip Edit Actions */}
        <div className="flex items-center space-x-1">
          <button
            onClick={handleSplitClip}
            disabled={project.clips.length === 0}
            className="flex items-center space-x-1 px-2.5 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 rounded-lg transition disabled:opacity-40"
            title="Split Clip at Current Playhead"
          >
            <Scissors className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Split</span>
          </button>
          <button
            onClick={handleDuplicateClip}
            disabled={!selectedClip}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 rounded-lg transition disabled:opacity-40"
            title="Duplicate Selected Clip"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => handleMoveClip('left')}
            disabled={!selectedClip || project.clips.indexOf(selectedClip) === 0}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 rounded-lg transition disabled:opacity-40"
            title="Move Left"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => handleMoveClip('right')}
            disabled={!selectedClip || project.clips.indexOf(selectedClip) === project.clips.length - 1}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 rounded-lg transition disabled:opacity-40"
            title="Move Right"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleDeleteClip}
            disabled={!selectedClip}
            className="p-1.5 bg-zinc-900 hover:bg-red-950/40 text-red-400 border border-zinc-800 rounded-lg transition disabled:opacity-40"
            title="Delete Selected Clip"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Visual Multi-Clip Timeline Track with Mobile Touch Scrubbing */}
      <div
        ref={timelineTrackRef}
        onClick={handleTrackClick}
        onTouchStart={handleTrackTouch}
        onTouchMove={handleTrackTouch}
        className="relative w-full h-20 bg-zinc-900 rounded-xl border border-zinc-800/90 overflow-hidden cursor-pointer select-none flex items-center p-1 touch-none"
      >
        {/* Playhead Vertical Line */}
        <div
          className="absolute top-0 bottom-0 z-20 w-0.5 bg-cyan-400 pointer-events-none transition-all shadow-[0_0_8px_rgba(56,189,248,0.8)]"
          style={{ left: `${playheadPercent}%` }}
        >
          {/* Playhead Handle */}
          <div className="w-3 h-3 bg-cyan-400 rounded-full -ml-[5px] -mt-0.5 shadow-md border border-white" />
        </div>

        {/* Clip Segments */}
        {project.clips.length === 0 ? (
          <div className="w-full text-center text-zinc-500 text-xs">
            Timeline is empty. Tap <strong>"Add from Phone"</strong> or choose a sample above.
          </div>
        ) : (
          <div className="w-full h-full flex items-center space-x-1">
            {project.clips.map((clip) => {
              const clipEffDur = (clip.endTime - clip.startTime) / clip.playbackRate;
              const clipWidthPercent = Math.max(8, totalDuration > 0 ? (clipEffDur / totalDuration) * 100 : 100);
              const isSelected = clip.id === selectedClipId;
              const isTrimmed = clip.startTime > 0 || clip.endTime < (clip.duration || 10);

              return (
                <div
                  key={clip.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectClip(clip.id);
                  }}
                  className={`relative h-full rounded-lg border flex flex-col justify-between p-2 overflow-hidden transition ${
                    isSelected
                      ? 'border-cyan-400 bg-gradient-to-b from-cyan-950/60 to-zinc-900 shadow-md ring-1 ring-cyan-400/40'
                      : 'border-zinc-700/80 bg-zinc-800/90 hover:border-zinc-500'
                  }`}
                  style={{ width: `${clipWidthPercent}%` }}
                >
                  {/* Visual Trim Handles when Selected */}
                  {isSelected && (
                    <>
                      <div
                        className="absolute top-0 bottom-0 left-0 w-1.5 bg-amber-400 rounded-l shadow"
                        title={`In-Point: ${clip.startTime.toFixed(2)}s`}
                      />
                      <div
                        className="absolute top-0 bottom-0 right-0 w-1.5 bg-amber-400 rounded-r shadow"
                        title={`Out-Point: ${clip.endTime.toFixed(2)}s`}
                      />
                    </>
                  )}

                  <div className="flex items-center justify-between text-[11px] font-medium text-white truncate pl-1">
                    <span className="truncate">{clip.name}</span>
                    {clip.playbackRate !== 1.0 && (
                      <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-1 rounded font-mono">
                        {clip.playbackRate}x
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-zinc-400 font-mono pl-1">
                    <span className="flex items-center space-x-1">
                      <span>{clip.type === 'video' ? '🎬' : '📷'}</span>
                      {isTrimmed && (
                        <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1 rounded">
                          Trimmed
                        </span>
                      )}
                    </span>
                    <span>{clipEffDur.toFixed(1)}s</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Selected Clip Controls Drawer (Speed, Trim Toggle, Orientation) */}
      {selectedClip && (
        <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Trim Toggle Button */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsTrimmerOpen(!isTrimmerOpen)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold transition ${
                isTrimmerOpen
                  ? 'bg-amber-500 text-black border-amber-400 shadow-md shadow-amber-500/20'
                  : 'bg-zinc-800 hover:bg-zinc-700 text-amber-300 border-zinc-700'
              }`}
              title="Open Precision Start & End Trimmer"
            >
              <Scissors className="w-3.5 h-3.5" />
              <span>{isTrimmerOpen ? 'Trimmer Active [ ]' : 'Trim In/Out Points'}</span>
            </button>
          </div>

          {/* Speed Controls (Slow Motion & Fast Motion) */}
          <div className="flex items-center space-x-2">
            <span className="text-zinc-400 flex items-center space-x-1 font-medium">
              <Gauge className="w-3.5 h-3.5 text-cyan-400" />
              <span>Speed:</span>
            </span>
            <div className="flex items-center space-x-1 bg-zinc-950 p-1 rounded-lg border border-zinc-800">
              {[0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 4.0].map((rate) => (
                <button
                  key={rate}
                  onClick={() => handleSpeedChange(rate)}
                  className={`px-2 py-0.5 rounded text-[11px] font-mono transition ${
                    selectedClip.playbackRate === rate
                      ? 'bg-cyan-500 text-black font-bold shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {rate}x
                </button>
              ))}
            </div>
          </div>

          {/* Transform & Fit Controls */}
          <div className="flex items-center space-x-2">
            <button
              onClick={handleRotate}
              className="flex items-center space-x-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 px-2.5 py-1 rounded-lg border border-zinc-700 transition"
              title="Rotate 90 Degrees"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Rotate</span>
            </button>
            <button
              onClick={handleFlipHorizontal}
              className="flex items-center space-x-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 px-2.5 py-1 rounded-lg border border-zinc-700 transition"
              title="Flip Horizontal (Mirror)"
            >
              <FlipHorizontal className="w-3.5 h-3.5" />
              <span>Mirror</span>
            </button>
          </div>
        </div>
      )}

      {/* Embedded Precision Video Trimmer Component */}
      {selectedClip && isTrimmerOpen && (
        <VideoTrimmer
          clip={selectedClip}
          currentTime={currentTime}
          onUpdateClip={handleUpdateSelectedClip}
          onSeek={onTimeUpdate}
          onClose={() => setIsTrimmerOpen(false)}
        />
      )}
    </div>
  );
};
