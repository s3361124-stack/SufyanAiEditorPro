import React, { useRef, useState } from 'react';
import {
  Music,
  Mic,
  Volume2,
  Trash2,
  Upload,
  Play,
  Pause,
  Sliders,
  Sparkles,
  Zap,
  VolumeX
} from 'lucide-react';
import { AudioTrack } from '../../types/editor';
import { BUILTIN_AUDIO_LIST, generateBuiltinAudio } from '../../utils/audioSynthesis';

interface AudioPanelProps {
  audioTracks: AudioTrack[];
  onUpdateAudioTracks: (tracks: AudioTrack[]) => void;
  projectDuration: number;
}

export const AudioPanel: React.FC<AudioPanelProps> = ({
  audioTracks,
  onUpdateAudioTracks,
  projectDuration
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [audioError, setAudioError] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const timerRef = useRef<number | null>(null);

  // Play preview state for builtin sounds
  const [previewingId, setPreviewingId] = useState<string | null>(null);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);

  // Add built-in sound effect or music track
  const handleAddBuiltinAudio = async (soundId: string) => {
    const soundInfo = BUILTIN_AUDIO_LIST.find((s) => s.id === soundId);
    if (!soundInfo) return;

    const audioUrl = await generateBuiltinAudio(soundId);
    const newTrack: AudioTrack = {
      id: 'audio_' + Math.random().toString(36).substring(2, 9),
      name: soundInfo.name,
      url: audioUrl,
      duration: soundInfo.duration,
      startTime: 0,
      volume: 1.0,
      fadeIn: 0.5,
      fadeOut: 0.5
    };

    onUpdateAudioTracks([...audioTracks, newTrack]);
  };

  // Preview sound effect
  const handleTogglePreview = async (soundId: string) => {
    if (previewingId === soundId) {
      previewAudioRef.current?.pause();
      setPreviewingId(null);
      return;
    }

    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
    }

    const audioUrl = await generateBuiltinAudio(soundId);
    const audio = new Audio(audioUrl);
    previewAudioRef.current = audio;
    setPreviewingId(soundId);

    audio.onended = () => setPreviewingId(null);
    audio.play().catch(() => setPreviewingId(null));
  };

  // Import custom audio from Android storage
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    const audio = new Audio(url);
    audio.onloadedmetadata = () => {
      const newTrack: AudioTrack = {
        id: 'audio_' + Math.random().toString(36).substring(2, 9),
        name: file.name.substring(0, 24),
        url,
        duration: audio.duration || 15,
        startTime: 0,
        volume: 1.0,
        fadeIn: 0.5,
        fadeOut: 0.5
      };
      onUpdateAudioTracks([...audioTracks, newTrack]);
    };

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Voiceover Recording using Phone Microphone
  const handleToggleRecord = async () => {
    if (isRecording) {
      // Stop recording
      if (mediaRecorderRef.current) {
        mediaRecorderRef.current.stop();
      }
      if (timerRef.current) clearInterval(timerRef.current);
      setIsRecording(false);
      setRecordingSeconds(0);
    } else {
      // Start recording
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(stream);
        const chunks: Blob[] = [];

        mediaRecorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunks.push(e.data);
        };

        mediaRecorder.onstop = () => {
          stream.getTracks().forEach((track) => track.stop());
          const blob = new Blob(chunks, { type: 'audio/webm' });
          const url = URL.createObjectURL(blob);
          const newTrack: AudioTrack = {
            id: 'audio_' + Math.random().toString(36).substring(2, 9),
            name: `Voiceover (${recordingSeconds}s)`,
            url,
            duration: recordingSeconds || 5,
            startTime: 0,
            volume: 1.2,
            fadeIn: 0.2,
            fadeOut: 0.2,
            isVoiceover: true
          };
          onUpdateAudioTracks([...audioTracks, newTrack]);
        };

        mediaRecorderRef.current = mediaRecorder;
        mediaRecorder.start();
        setIsRecording(true);
        setRecordingSeconds(0);

        timerRef.current = window.setInterval(() => {
          setRecordingSeconds((prev) => prev + 1);
        }, 1000);
      } catch (err) {
        setAudioError('Could not access microphone: ' + (err as Error).message);
      }
    }
  };

  // Update track volume
  const handleVolumeChange = (trackId: string, volume: number) => {
    onUpdateAudioTracks(audioTracks.map((t) => (t.id === trackId ? { ...t, volume } : t)));
  };

  // Update track start time (Audio Placement along Video Timeline)
  const handleStartTimeChange = (trackId: string, startTime: number) => {
    onUpdateAudioTracks(audioTracks.map((t) => (t.id === trackId ? { ...t, startTime } : t)));
  };

  // Delete track
  const handleDeleteTrack = (trackId: string) => {
    onUpdateAudioTracks(audioTracks.filter((t) => t.id !== trackId));
  };

  return (
    <div className="w-full flex flex-col bg-zinc-950 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-4">
      <input ref={fileInputRef} type="file" accept="audio/*" onChange={handleFileUpload} className="hidden" />

      {/* Error banner if mic fails */}
      {audioError && (
        <div className="p-3 bg-red-950/80 border border-red-500/40 rounded-xl text-red-200 text-xs flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <VolumeX className="w-4 h-4 text-red-400 shrink-0" />
            <span>{audioError}</span>
          </div>
          <button onClick={() => setAudioError(null)} className="text-red-400 hover:text-white ml-2 text-xs font-bold">
            Dismiss
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
        <div className="flex items-center space-x-2">
          <Music className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-semibold text-white tracking-wide">AUDIO, MUSIC & VOICEOVER MIXER</h3>
        </div>

        <div className="flex items-center space-x-2">
          {/* Record Voiceover Button */}
          <button
            onClick={handleToggleRecord}
            className={`flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-semibold transition ${
              isRecording
                ? 'bg-red-600 text-white animate-pulse'
                : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700'
            }`}
          >
            <Mic className="w-3.5 h-3.5" />
            <span>{isRecording ? `Recording (${recordingSeconds}s)...` : 'Record Voice'}</span>
          </button>

          {/* Import Audio File */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center space-x-1 px-3 py-1 bg-gradient-to-r from-zinc-800 to-zinc-700 hover:from-zinc-700 hover:to-zinc-600 text-white rounded-full text-xs font-medium border border-zinc-700 transition"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import MP3</span>
          </button>
        </div>
      </div>

      {/* Royalty-Free Procedural Soundtracks & SFX Library */}
      <div>
        <label className="text-xs font-medium text-zinc-400 flex items-center space-x-1 mb-2">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Free Royalty-Free Soundtracks & Movie SFX (No Internet Needed):</span>
        </label>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
          {BUILTIN_AUDIO_LIST.map((item) => (
            <div
              key={item.id}
              className="flex items-center justify-between bg-zinc-900 border border-zinc-800 rounded-xl p-2.5 hover:border-zinc-700 transition"
            >
              <div className="flex items-center space-x-2 overflow-hidden">
                <button
                  onClick={() => handleTogglePreview(item.id)}
                  className={`p-1.5 rounded-full transition ${
                    previewingId === item.id ? 'bg-cyan-500 text-black' : 'bg-zinc-800 text-zinc-300 hover:text-white'
                  }`}
                  title="Preview audio"
                >
                  {previewingId === item.id ? <Pause className="w-3 h-3 fill-current" /> : <Play className="w-3 h-3 fill-current" />}
                </button>
                <div className="truncate">
                  <div className="text-xs font-medium text-zinc-200 truncate">{item.name}</div>
                  <div className="text-[10px] text-zinc-500 font-mono">{item.duration}s • {item.type.toUpperCase()}</div>
                </div>
              </div>

              <button
                onClick={() => handleAddBuiltinAudio(item.id)}
                className="shrink-0 text-[11px] bg-zinc-800 hover:bg-cyan-500 hover:text-black text-cyan-400 px-2 py-1 rounded font-medium transition"
              >
                + Add
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Active Project Audio Tracks */}
      <div className="pt-2">
        <label className="text-xs font-medium text-zinc-400 block mb-2">Active Audio Tracks in Timeline:</label>

        {audioTracks.length === 0 ? (
          <div className="p-4 bg-zinc-900/60 rounded-xl border border-zinc-800/80 text-center text-xs text-zinc-500">
            No audio tracks added yet. Tap <strong>"+ Add"</strong> above or <strong>"Record Voice"</strong> with microphone.
          </div>
        ) : (
          <div className="space-y-2">
            {audioTracks.map((track) => (
              <div
                key={track.id}
                className="flex flex-col sm:flex-row items-center justify-between bg-zinc-900 border border-zinc-800 rounded-xl p-3 gap-3"
              >
                <div className="flex items-center space-x-2.5 w-full sm:w-auto">
                  <div className="p-2 rounded-lg bg-zinc-800 text-cyan-400">
                    {track.isVoiceover ? <Mic className="w-4 h-4" /> : <Music className="w-4 h-4" />}
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white">{track.name}</div>
                    <div className="text-[10px] text-zinc-400 font-mono">Duration: {track.duration.toFixed(1)}s</div>
                  </div>
                </div>

                {/* Volume & Timeline Placement Controls */}
                <div className="flex flex-col sm:flex-row items-end sm:items-center space-y-2 sm:space-y-0 sm:space-x-4 w-full sm:w-auto justify-end">
                  {/* Timeline Start Time Placement */}
                  <div className="flex items-center space-x-2 text-xs">
                    <span className="text-[11px] text-zinc-400">Start:</span>
                    <input
                      type="range"
                      min={0}
                      max={Math.max(30, projectDuration)}
                      step={0.1}
                      value={track.startTime || 0}
                      onChange={(e) => handleStartTimeChange(track.id, Number(e.target.value))}
                      className="w-20 sm:w-24 accent-amber-400 bg-zinc-800 h-1.5 rounded appearance-none"
                    />
                    <span className="font-mono text-xs text-amber-300 w-10 text-right">
                      {(track.startTime || 0).toFixed(1)}s
                    </span>
                  </div>

                  {/* Volume Slider */}
                  <div className="flex items-center space-x-2">
                    <Volume2 className="w-3.5 h-3.5 text-zinc-400" />
                    <input
                      type="range"
                      min="0"
                      max="2"
                      step="0.05"
                      value={track.volume}
                      onChange={(e) => handleVolumeChange(track.id, Number(e.target.value))}
                      className="w-20 sm:w-24 accent-cyan-400 bg-zinc-800 h-1.5 rounded appearance-none"
                    />
                    <span className="font-mono text-xs text-zinc-300 w-8">{Math.round(track.volume * 100)}%</span>
                  </div>

                  <button
                    onClick={() => handleDeleteTrack(track.id)}
                    className="p-1.5 text-zinc-500 hover:text-red-400 rounded-lg hover:bg-zinc-800 transition"
                    title="Remove Track"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
