import React from 'react';
import {
  Palette,
  Sun,
  Contrast as ContrastIcon,
  Droplets,
  Thermometer,
  Disc,
  Film,
  Sparkles,
  RotateCcw
} from 'lucide-react';
import { ColorGradeSettings, LUTPreset } from '../../types/editor';

interface ColorGradingPanelProps {
  colorGrade: ColorGradeSettings;
  onChange: (updated: ColorGradeSettings) => void;
}

const LUT_PRESETS: { id: LUTPreset; name: string; description: string; previewColor: string }[] = [
  { id: 'original', name: 'Original', description: 'Natural camera balance', previewColor: '#71717a' },
  { id: 'teal-orange', name: 'Teal & Orange', description: 'Hollywood blockbuster contrast', previewColor: '#0ea5e9' },
  { id: 'film-noir', name: 'Film Noir', description: 'Monochrome high-contrast black & white', previewColor: '#e4e4e7' },
  { id: 'vintage-35mm', name: 'Vintage 35mm', description: 'Analog warm 70s film tone', previewColor: '#d97706' },
  { id: 'cyberpunk', name: 'Cyberpunk', description: 'Neon purples & vivid blues', previewColor: '#ec4899' },
  { id: 'golden-hour', name: 'Golden Hour', description: 'Warm sunset magic glow for vlogs', previewColor: '#f59e0b' },
  { id: 'emerald', name: 'Emerald / Sci-Fi', description: 'Atmospheric green matrix cast', previewColor: '#10b981' },
  { id: 'bleach-bypass', name: 'Bleach Bypass', description: 'Gritty action movie contrast', previewColor: '#94a3b8' },
  { id: 'kodachrome', name: 'Kodachrome 64', description: 'Rich cinema saturation', previewColor: '#ef4444' }
];

export const ColorGradingPanel: React.FC<ColorGradingPanelProps> = ({ colorGrade, onChange }) => {
  const handleReset = () => {
    onChange({
      preset: 'original',
      brightness: 0,
      contrast: 0,
      saturation: 0,
      temperature: 0,
      sharpness: 0,
      vignette: 0,
      filmGrain: 0,
      letterbox: false,
      letterboxHeight: 12
    });
  };

  return (
    <div className="w-full flex flex-col bg-zinc-950 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-4">
      <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
        <div className="flex items-center space-x-2">
          <Palette className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-semibold text-white tracking-wide">CINEMATIC COLOR GRADING & LUTS</h3>
        </div>
        <button
          onClick={handleReset}
          className="flex items-center space-x-1 text-xs text-zinc-400 hover:text-white transition"
          title="Reset Color Adjustments"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      </div>

      {/* Cinematic LUT Presets Grid */}
      <div>
        <label className="text-xs font-medium text-zinc-400 block mb-2">Film Look & LUT Presets:</label>
        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-9 gap-2">
          {LUT_PRESETS.map((lut) => (
            <button
              key={lut.id}
              onClick={() => onChange({ ...colorGrade, preset: lut.id })}
              className={`flex flex-col items-center p-2 rounded-xl border text-center transition ${
                colorGrade.preset === lut.id
                  ? 'border-cyan-400 bg-cyan-950/40 text-white ring-1 ring-cyan-400/50 shadow-md'
                  : 'border-zinc-800 bg-zinc-900/80 text-zinc-400 hover:text-zinc-200 hover:border-zinc-700'
              }`}
            >
              <div
                className="w-6 h-6 rounded-full mb-1 border border-zinc-700 shadow-inner"
                style={{ backgroundColor: lut.previewColor }}
              />
              <span className="text-[11px] font-medium leading-tight truncate w-full">{lut.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Sliders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
        {/* Brightness */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs text-zinc-400">
            <span className="flex items-center space-x-1">
              <Sun className="w-3.5 h-3.5 text-zinc-300" />
              <span>Exposure / Brightness</span>
            </span>
            <span className="font-mono text-zinc-200">{colorGrade.brightness > 0 ? `+${colorGrade.brightness}` : colorGrade.brightness}</span>
          </div>
          <input
            type="range"
            min="-60"
            max="60"
            value={colorGrade.brightness}
            onChange={(e) => onChange({ ...colorGrade, brightness: Number(e.target.value) })}
            className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        {/* Contrast */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs text-zinc-400">
            <span className="flex items-center space-x-1">
              <ContrastIcon className="w-3.5 h-3.5 text-zinc-300" />
              <span>Contrast</span>
            </span>
            <span className="font-mono text-zinc-200">{colorGrade.contrast > 0 ? `+${colorGrade.contrast}` : colorGrade.contrast}</span>
          </div>
          <input
            type="range"
            min="-60"
            max="60"
            value={colorGrade.contrast}
            onChange={(e) => onChange({ ...colorGrade, contrast: Number(e.target.value) })}
            className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        {/* Saturation */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs text-zinc-400">
            <span className="flex items-center space-x-1">
              <Droplets className="w-3.5 h-3.5 text-zinc-300" />
              <span>Color Saturation</span>
            </span>
            <span className="font-mono text-zinc-200">{colorGrade.saturation > 0 ? `+${colorGrade.saturation}` : colorGrade.saturation}</span>
          </div>
          <input
            type="range"
            min="-100"
            max="100"
            value={colorGrade.saturation}
            onChange={(e) => onChange({ ...colorGrade, saturation: Number(e.target.value) })}
            className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        {/* Temperature (Cool Cyan vs Warm Golden) */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs text-zinc-400">
            <span className="flex items-center space-x-1">
              <Thermometer className="w-3.5 h-3.5 text-zinc-300" />
              <span>Color Temperature</span>
            </span>
            <span className="font-mono text-zinc-200">
              {colorGrade.temperature < 0 ? `Cool ${colorGrade.temperature}` : colorGrade.temperature > 0 ? `Warm +${colorGrade.temperature}` : '0'}
            </span>
          </div>
          <input
            type="range"
            min="-100"
            max="100"
            value={colorGrade.temperature}
            onChange={(e) => onChange({ ...colorGrade, temperature: Number(e.target.value) })}
            className="w-full accent-amber-400 bg-zinc-800 h-1.5 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        {/* Vignette */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs text-zinc-400">
            <span className="flex items-center space-x-1">
              <Disc className="w-3.5 h-3.5 text-zinc-300" />
              <span>Cinematic Vignette</span>
            </span>
            <span className="font-mono text-zinc-200">{colorGrade.vignette}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={colorGrade.vignette}
            onChange={(e) => onChange({ ...colorGrade, vignette: Number(e.target.value) })}
            className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded-lg appearance-none cursor-pointer"
          />
        </div>

        {/* Film Grain */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs text-zinc-400">
            <span className="flex items-center space-x-1">
              <Sparkles className="w-3.5 h-3.5 text-zinc-300" />
              <span>35mm Film Grain</span>
            </span>
            <span className="font-mono text-zinc-200">{colorGrade.filmGrain}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={colorGrade.filmGrain}
            onChange={(e) => onChange({ ...colorGrade, filmGrain: Number(e.target.value) })}
            className="w-full accent-cyan-400 bg-zinc-800 h-1.5 rounded-lg appearance-none cursor-pointer"
          />
        </div>
      </div>

      {/* Hollywood Anamorphic Letterbox Bars (2.39:1 look) */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Film className="w-4 h-4 text-amber-400" />
          <div>
            <div className="text-xs font-medium text-white">Hollywood Letterbox Bars (2.39:1)</div>
            <div className="text-[11px] text-zinc-400">Add classic black cinematic bars to top and bottom of video</div>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {colorGrade.letterbox && (
            <input
              type="range"
              min="5"
              max="20"
              value={colorGrade.letterboxHeight}
              onChange={(e) => onChange({ ...colorGrade, letterboxHeight: Number(e.target.value) })}
              className="w-20 accent-amber-400 bg-zinc-800 h-1.5 rounded appearance-none"
              title="Bar Height"
            />
          )}
          <button
            onClick={() => onChange({ ...colorGrade, letterbox: !colorGrade.letterbox })}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
              colorGrade.letterbox
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                : 'bg-zinc-800 text-zinc-400 hover:text-white'
            }`}
          >
            {colorGrade.letterbox ? 'Active' : 'Off'}
          </button>
        </div>
      </div>
    </div>
  );
};
