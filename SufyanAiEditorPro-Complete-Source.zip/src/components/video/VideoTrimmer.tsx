import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  Scissors,
  Play,
  Pause,
  RotateCcw,
  ChevronsLeft,
  ChevronsRight,
  ChevronLeft,
  ChevronRight,
  Clock,
  Sparkles,
  Check,
  Film
} from 'lucide-react';
import { VideoClip } from '../../types/editor';

interface VideoTrimmerProps {
  clip: VideoClip;
  currentTime: number;
  onUpdateClip: (updated: VideoClip) => void;
  onSeek: (time: number) => void;
  onClose?: () => void;
}

export const VideoTrimmer: React.FC<VideoTrimmerProps> = ({
  clip,
  currentTime,
  onUpdateClip,
  onSeek,
  onClose
}) => {
  const trackRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState<'start' | 'end' | 'scrub' | null>(null);
  const [isPreviewingTrim, setIsPreviewingTrim] = useState(false);
  const previewTimerRef = useRef<number | null>(null);

  // Fallback max duration if clip duration is missing
  const totalClipDuration = Math.max(0.5, clip.duration || (clip.endTime > 0 ? clip.endTime : 10));

  // Current start & end percentages
  const startPercent = Math.max(0, Math.min(100, (clip.startTime / totalClipDuration) * 100));
  const endPercent = Math.max(0, Math.min(100, (clip.endTime / totalClipDuration) * 100));
  const activeWidthPercent = Math.max(0, endPercent - startPercent);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 100);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}.${ms.toString().padStart(2, '0')}`;
  };

  // Drag interaction handler for touch and mouse
  const handlePointerDown = (handle: 'start' | 'end' | 'scrub') => (e: React.PointerEvent) => {
    e.stopPropagation();
    e.preventDefault();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setIsDragging(handle);
  };

  const handlePointerMove = useCallback(
    (e: React.PointerEvent) => {
      if (!isDragging || !trackRef.current) return;
      const rect = trackRef.current.getBoundingClientRect();
      const clientX = e.clientX;
      const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      const targetTime = ratio * totalClipDuration;

      const MIN_DURATION = 0.3; // minimum trimmed clip length in seconds

      if (isDragging === 'start') {
        const newStart = Math.max(0, Math.min(clip.endTime - MIN_DURATION, targetTime));
        onUpdateClip({ ...clip, startTime: Number(newStart.toFixed(2)) });
        onSeek(newStart);
      } else if (isDragging === 'end') {
        const newEnd = Math.max(clip.startTime + MIN_DURATION, Math.min(totalClipDuration, targetTime));
        onUpdateClip({ ...clip, endTime: Number(newEnd.toFixed(2)) });
        onSeek(newEnd);
      } else if (isDragging === 'scrub') {
        const clampedScrub = Math.max(clip.startTime, Math.min(clip.endTime, targetTime));
        onSeek(clampedScrub);
      }
    },
    [isDragging, clip, totalClipDuration, onUpdateClip, onSeek]
  );

  const handlePointerUp = (e: React.PointerEvent) => {
    if (isDragging) {
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch (err) {}
      setIsDragging(null);
    }
  };

  // Precision nudge helpers (-0.1s, +0.1s)
  const handleNudgeStart = (delta: number) => {
    const MIN_DURATION = 0.3;
    const newStart = Math.max(0, Math.min(clip.endTime - MIN_DURATION, clip.startTime + delta));
    onUpdateClip({ ...clip, startTime: Number(newStart.toFixed(2)) });
    onSeek(newStart);
  };

  const handleNudgeEnd = (delta: number) => {
    const MIN_DURATION = 0.3;
    const newEnd = Math.max(clip.startTime + MIN_DURATION, Math.min(totalClipDuration, clip.endTime + delta));
    onUpdateClip({ ...clip, endTime: Number(newEnd.toFixed(2)) });
    onSeek(newEnd);
  };

  // Reset to original full length
  const handleResetTrim = () => {
    onUpdateClip({
      ...clip,
      startTime: 0,
      endTime: totalClipDuration
    });
    onSeek(0);
  };

  // Set start or end point to current playhead
  const handleSetStartToPlayhead = () => {
    const MIN_DURATION = 0.3;
    const newStart = Math.max(0, Math.min(clip.endTime - MIN_DURATION, currentTime));
    onUpdateClip({ ...clip, startTime: Number(newStart.toFixed(2)) });
  };

  const handleSetEndToPlayhead = () => {
    const MIN_DURATION = 0.3;
    const newEnd = Math.max(clip.startTime + MIN_DURATION, Math.min(totalClipDuration, currentTime));
    onUpdateClip({ ...clip, endTime: Number(newEnd.toFixed(2)) });
  };

  // Preview trimmed selection in loop
  const handleTogglePreviewTrim = () => {
    if (isPreviewingTrim) {
      if (previewTimerRef.current) clearInterval(previewTimerRef.current);
      setIsPreviewingTrim(false);
    } else {
      setIsPreviewingTrim(true);
      onSeek(clip.startTime);

      const stepMs = 1000 / 30;
      let virtualTime = clip.startTime;

      previewTimerRef.current = window.setInterval(() => {
        virtualTime += 1 / 30;
        if (virtualTime >= clip.endTime) {
          virtualTime = clip.startTime; // loop
        }
        onSeek(virtualTime);
      }, stepMs);
    }
  };

  useEffect(() => {
    return () => {
      if (previewTimerRef.current) clearInterval(previewTimerRef.current);
    };
  }, []);

  const trimmedDuration = Math.max(0, clip.endTime - clip.startTime);
  const cutAmount = Math.max(0, totalClipDuration - trimmedDuration);

  return (
    <div className="w-full flex flex-col bg-zinc-950 border border-zinc-800 rounded-2xl p-4 shadow-xl space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-zinc-800 pb-2.5 flex-wrap gap-2">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
            <Scissors className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white tracking-wide flex items-center space-x-2">
              <span>PRECISION CLIP TRIMMER</span>
              <span className="text-[10px] bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded font-mono truncate max-w-[140px]">
                {clip.name}
              </span>
            </h3>
            <p className="text-[11px] text-zinc-400">
              Drag the golden handles to trim start (in-point) and end (out-point).
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {/* Preview Trim Button */}
          <button
            onClick={handleTogglePreviewTrim}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
              isPreviewingTrim
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20 animate-pulse'
                : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700'
            }`}
          >
            {isPreviewingTrim ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isPreviewingTrim ? 'Stop Preview' : 'Play Trimmed'}</span>
          </button>

          {/* Reset Trim Button */}
          <button
            onClick={handleResetTrim}
            className="flex items-center space-x-1 px-2.5 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl text-xs border border-zinc-800 transition"
            title="Reset to Full Original Video"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Reset</span>
          </button>
        </div>
      </div>

      {/* Timecode Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
        <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-xl p-2.5">
          <span className="text-[10px] text-zinc-500 block font-medium">START IN-POINT [</span>
          <span className="font-mono text-cyan-400 font-bold text-xs">{formatTime(clip.startTime)}</span>
        </div>

        <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-xl p-2.5">
          <span className="text-[10px] text-zinc-500 block font-medium">END OUT-POINT ]</span>
          <span className="font-mono text-cyan-400 font-bold text-xs">{formatTime(clip.endTime)}</span>
        </div>

        <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-xl p-2.5">
          <span className="text-[10px] text-zinc-500 block font-medium">TRIMMED DURATION</span>
          <span className="font-mono text-emerald-400 font-bold text-xs">{trimmedDuration.toFixed(2)}s</span>
        </div>

        <div className="bg-zinc-900/90 border border-zinc-800/80 rounded-xl p-2.5">
          <span className="text-[10px] text-zinc-500 block font-medium">CUT DURATION</span>
          <span className="font-mono text-zinc-400 text-xs">-{cutAmount.toFixed(2)}s</span>
        </div>
      </div>

      {/* Visual Filmstrip Trimming Track */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-[11px] text-zinc-500 font-mono">
          <span>00:00.00</span>
          <span className="text-zinc-400">Drag yellow handles to adjust boundaries</span>
          <span>{formatTime(totalClipDuration)}</span>
        </div>

        <div
          ref={trackRef}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="relative w-full h-18 bg-zinc-900 rounded-xl border border-zinc-800 overflow-hidden select-none touch-none flex items-center p-0.5"
        >
          {/* Simulated Filmstrip Sprocket Holes */}
          <div className="absolute top-0 left-0 right-0 h-2 bg-zinc-950 flex justify-between px-1 pointer-events-none opacity-40">
            {Array.from({ length: 24 }).map((_, i) => (
              <div key={i} className="w-1.5 h-1 bg-zinc-700 rounded-xs" />
            ))}
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-2 bg-zinc-950 flex justify-between px-1 pointer-events-none opacity-40">
            {Array.from({ length: 24 }).map((_, i) => (
              <div key={i} className="w-1.5 h-1 bg-zinc-700 rounded-xs" />
            ))}
          </div>

          {/* Left Dimmed Area (Trimmed Out / Excluded) */}
          <div
            className="absolute top-0 bottom-0 left-0 bg-black/75 z-10 pointer-events-none border-r border-amber-500/30"
            style={{ width: `${startPercent}%` }}
          >
            <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,transparent,transparent_6px,rgba(0,0,0,0.4)_6px,rgba(0,0,0,0.4)_12px)] opacity-50" />
          </div>

          {/* Active Trimmed Zone (Included in Video) */}
          <div
            className="absolute top-0 bottom-0 z-10 border-t-2 border-b-2 border-amber-400 bg-amber-500/15 pointer-events-auto cursor-ew-resize transition-colors"
            style={{
              left: `${startPercent}%`,
              width: `${activeWidthPercent}%`
            }}
            onPointerDown={handlePointerDown('scrub')}
          >
            {/* Center label */}
            <div className="w-full h-full flex items-center justify-center pointer-events-none">
              <span className="text-[10px] font-mono font-bold text-amber-300 bg-black/60 px-2 py-0.5 rounded border border-amber-500/30">
                ACTIVE: {trimmedDuration.toFixed(2)}s
              </span>
            </div>
          </div>

          {/* Right Dimmed Area (Trimmed Out / Excluded) */}
          <div
            className="absolute top-0 bottom-0 right-0 bg-black/75 z-10 pointer-events-none border-l border-amber-500/30"
            style={{ width: `${100 - endPercent}%` }}
          >
            <div className="absolute inset-0 bg-[repeating-linear-gradient(45deg,transparent,transparent_6px,rgba(0,0,0,0.4)_6px,rgba(0,0,0,0.4)_12px)] opacity-50" />
          </div>

          {/* Left Handle: Start In-Point [ */}
          <div
            onPointerDown={handlePointerDown('start')}
            className="absolute top-0 bottom-0 z-30 w-6 -ml-3 flex items-center justify-center cursor-ew-resize group"
            style={{ left: `${startPercent}%` }}
          >
            <div className="w-3.5 h-full bg-amber-400 hover:bg-amber-300 rounded-l-md shadow-lg flex items-center justify-center transition border-y border-l border-black">
              {/* Grip lines */}
              <div className="flex flex-col space-y-1">
                <div className="w-1 h-3 bg-black/60 rounded" />
              </div>
            </div>
          </div>

          {/* Right Handle: End Out-Point ] */}
          <div
            onPointerDown={handlePointerDown('end')}
            className="absolute top-0 bottom-0 z-30 w-6 -ml-3 flex items-center justify-center cursor-ew-resize group"
            style={{ left: `${endPercent}%` }}
          >
            <div className="w-3.5 h-full bg-amber-400 hover:bg-amber-300 rounded-r-md shadow-lg flex items-center justify-center transition border-y border-r border-black">
              {/* Grip lines */}
              <div className="flex flex-col space-y-1">
                <div className="w-1 h-3 bg-black/60 rounded" />
              </div>
            </div>
          </div>

          {/* Current Playhead Marker inside clip */}
          {currentTime >= 0 && currentTime <= totalClipDuration && (
            <div
              className="absolute top-0 bottom-0 z-20 w-0.5 bg-cyan-400 pointer-events-none shadow-[0_0_8px_#38bdf8]"
              style={{ left: `${(currentTime / totalClipDuration) * 100}%` }}
            >
              <div className="w-2.5 h-2.5 bg-cyan-400 rounded-full -ml-1 -mt-1 shadow" />
            </div>
          )}
        </div>
      </div>

      {/* Mobile-Friendly Precision Controls (Set to Playhead & Fine Nudge Buttons) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
        {/* Start Point Controls */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-zinc-300 flex items-center space-x-1">
              <span>Start In-Point:</span>
              <span className="font-mono text-cyan-400">{formatTime(clip.startTime)}</span>
            </span>
            <button
              onClick={handleSetStartToPlayhead}
              className="px-2 py-1 bg-zinc-800 hover:bg-cyan-500 hover:text-black text-cyan-400 rounded text-[11px] font-medium transition"
              title="Set Start Point to Current Playhead"
            >
              Set to Playhead
            </button>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleNudgeStart(-0.5)}
              className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-xs transition"
              title="Nudge Start -0.5s"
            >
              -0.5s
            </button>
            <button
              onClick={() => handleNudgeStart(-0.1)}
              className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-xs transition"
              title="Nudge Start -0.1s"
            >
              -0.1s
            </button>
            <button
              onClick={() => handleNudgeStart(0.1)}
              className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-xs transition"
              title="Nudge Start +0.1s"
            >
              +0.1s
            </button>
            <button
              onClick={() => handleNudgeStart(0.5)}
              className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-xs transition"
              title="Nudge Start +0.5s"
            >
              +0.5s
            </button>
          </div>
        </div>

        {/* End Point Controls */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-zinc-300 flex items-center space-x-1">
              <span>End Out-Point:</span>
              <span className="font-mono text-cyan-400">{formatTime(clip.endTime)}</span>
            </span>
            <button
              onClick={handleSetEndToPlayhead}
              className="px-2 py-1 bg-zinc-800 hover:bg-cyan-500 hover:text-black text-cyan-400 rounded text-[11px] font-medium transition"
              title="Set End Point to Current Playhead"
            >
              Set to Playhead
            </button>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleNudgeEnd(-0.5)}
              className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-xs transition"
              title="Nudge End -0.5s"
            >
              -0.5s
            </button>
            <button
              onClick={() => handleNudgeEnd(-0.1)}
              className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-xs transition"
              title="Nudge End -0.1s"
            >
              -0.1s
            </button>
            <button
              onClick={() => handleNudgeEnd(0.1)}
              className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-xs transition"
              title="Nudge End +0.1s"
            >
              +0.1s
            </button>
            <button
              onClick={() => handleNudgeEnd(0.5)}
              className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-xs transition"
              title="Nudge End +0.5s"
            >
              +0.5s
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
