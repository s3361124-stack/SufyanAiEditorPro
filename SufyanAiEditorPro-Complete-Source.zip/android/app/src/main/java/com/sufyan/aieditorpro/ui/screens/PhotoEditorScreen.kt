package com.sufyan.aieditorpro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sufyan.aieditorpro.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoEditorScreen(onNavigateToVideo: () -> Unit) {
    var removeBgActive by remember { mutableStateOf(false) }
    var bokehBlurValue by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        TopAppBar(
            title = { Text("PHOTO AI STUDIO", fontSize = 18.sp, color = SilverPlatinum) },
            navigationIcon = {
                IconButton(onClick = onNavigateToVideo) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = SilverPlatinum)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface),
            actions = {
                IconButton(onClick = { /* Save photo */ }) {
                    Icon(Icons.Default.Save, contentDescription = "Save Photo", tint = AccentCyan)
                }
            }
        )

        // Photo Canvas Viewport
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(DarkBackground),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text("AI Background Cutout & Portrait Bokeh Studio", color = SilverPlatinum)
                Text("On-device offline photo processing", color = SilverMuted, fontSize = 12.sp)
            }
        }

        // Photo Tools Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurface
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                FilterChip(
                    selected = removeBgActive,
                    onClick = { removeBgActive = !removeBgActive },
                    label = { Text("AI Cutout") }
                )
                FilterChip(
                    selected = bokehBlurValue > 0,
                    onClick = { bokehBlurValue = if (bokehBlurValue > 0) 0f else 50f },
                    label = { Text("Portrait Bokeh") }
                )
                FilterChip(
                    selected = false,
                    onClick = { /* Auto enhance */ },
                    label = { Text("1-Tap Enhance") }
                )
            }
        }
    }
}
