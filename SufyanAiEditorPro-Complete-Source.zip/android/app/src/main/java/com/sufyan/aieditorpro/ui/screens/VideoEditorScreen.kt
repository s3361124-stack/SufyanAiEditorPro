package com.sufyan.aieditorpro.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sufyan.aieditorpro.R
import com.sufyan.aieditorpro.ui.theme.*


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoEditorScreen(onNavigateToPhoto: () -> Unit) {
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentAspectRatio by remember { mutableStateOf("16:9") }
    var selectedLut by remember { mutableStateOf("Original") }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedVideoUri = uri
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Top App Bar with Mascot Logo
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.5.dp, AccentPurple, RoundedCornerShape(8.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.logo),
                            contentDescription = "SUFYAN Logo",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        "SUFYAN AI EDITOR PRO",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = SilverPlatinum
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = DarkSurface
            ),
            actions = {
                IconButton(onClick = onNavigateToPhoto) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = "Photo Studio", tint = AccentCyan)
                }
                IconButton(onClick = { /* Export action */ }) {
                    Icon(Icons.Default.Download, contentDescription = "Export Video", tint = SilverPlatinum)
                }
            }
        )

        // Video Preview Player Viewport
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            if (selectedVideoUri != null) {
                Text("Video Active: ${selectedVideoUri?.lastPathSegment}", color = Color.White)
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.MovieCreation,
                        contentDescription = null,
                        tint = SilverMuted,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Import Video or tap + to begin", color = SilverMuted)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { videoPickerLauncher.launch("video/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Video Clip")
                    }
                }
            }
        }

        // Multi-clip Timeline Scrubbing Bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp),
            color = DarkSurface
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TIMELINE: 00:00.00", color = SilverMuted, fontSize = 12.sp)
                    Row {
                        IconButton(onClick = { isPlaying = !isPlaying }) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = SilverPlatinum
                            )
                        }
                        IconButton(onClick = { /* Split clip */ }) {
                            Icon(Icons.Default.ContentCut, contentDescription = "Split", tint = SilverPlatinum)
                        }
                        IconButton(onClick = { /* Delete clip */ }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ActionRed)
                        }
                    }
                }

                // Clip track preview
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .background(DarkSurfaceVariant, RoundedCornerShape(8.dp))
                        .border(1.dp, SilverBorder, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Primary Video Track (Trim, Split & Reorder)", color = SilverMuted, fontSize = 12.sp)
                }
            }
        }

        // Precision Video Trimmer Component
        VideoTrimmerView(
            startSeconds = 0.0f,
            endSeconds = 10.0f,
            maxDuration = 15.0f,
            onTrimChanged = { start, end -> /* update clip start & end points */ }
        )

        // Bottom Tool Dock
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkBackground)
                .padding(vertical = 12.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            ToolButton(icon = Icons.Default.ContentCut, label = "Trim [ ]")
            ToolButton(icon = Icons.Default.ColorLens, label = "Color / LUT")
            ToolButton(icon = Icons.Default.MusicNote, label = "Audio / SFX")
            ToolButton(icon = Icons.Default.TextFields, label = "Titles / Text")
            ToolButton(icon = Icons.Default.Speed, label = "Speed (0.25x)")
        }
    }
}

@Composable
fun VideoTrimmerView(
    startSeconds: Float,
    endSeconds: Float,
    maxDuration: Float,
    onTrimChanged: (Float, Float) -> Unit
) {
    var start by remember { mutableFloatStateOf(startSeconds) }
    var end by remember { mutableFloatStateOf(endSeconds) }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        color = DarkSurface,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SilverBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("TRIM IN: ${String.format("%.2f", start)}s", color = AccentCyan, fontSize = 11.sp)
                Text("DURATION: ${String.format("%.2f", end - start)}s", color = SilverPlatinum, fontSize = 11.sp)
                Text("TRIM OUT: ${String.format("%.2f", end)}s", color = AccentCyan, fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Range Trim Slider Simulator
            RangeSlider(
                value = start..end,
                onValueChange = { range ->
                    start = range.start
                    end = range.endInclusive
                    onTrimChanged(start, end)
                },
                valueRange = 0f..maxDuration,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFFF59E0B),
                    activeTrackColor = Color(0xFFF59E0B),
                    inactiveTrackColor = Color.DarkGray
                )
            )
        }
    }
}

@Composable
fun ToolButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = label, tint = SilverPlatinum, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, color = SilverMuted, fontSize = 10.sp)
    }
}
