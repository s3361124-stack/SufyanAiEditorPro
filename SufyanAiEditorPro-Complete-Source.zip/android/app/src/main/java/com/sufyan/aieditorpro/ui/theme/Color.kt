package com.sufyan.aieditorpro.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Black & Silver Palette
val DarkBackground = Color(0xFF0B0C10)
val DarkSurface = Color(0xFF14161F)
val DarkSurfaceVariant = Color(0xFF1F222E)

val SilverPlatinum = Color(0xFFE5E7EB)
val SilverLight = Color(0xFFF3F4F6)
val SilverMuted = Color(0xFF9CA3AF)
val SilverBorder = Color(0xFF374151)

val AccentCyan = Color(0xFF38BDF8)
val AccentPurple = Color(0xFF818CF8)
val ActionRed = Color(0xFFEF4444)
