package com.sufyan.aieditorpro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = SilverPlatinum,
    onPrimary = DarkBackground,
    primaryContainer = DarkSurfaceVariant,
    secondary = AccentCyan,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceVariant,
    onBackground = SilverLight,
    onSurface = SilverLight,
    outline = SilverBorder
)

@Composable
fun SufyanAiEditorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
