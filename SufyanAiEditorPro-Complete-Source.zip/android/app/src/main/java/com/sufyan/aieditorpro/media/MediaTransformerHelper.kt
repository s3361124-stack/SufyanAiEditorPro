package com.sufyan.aieditorpro.media

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.effect.Contrast
import androidx.media3.effect.RgbFilter
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Hardware-accelerated video export using AndroidX Media3 Transformer
 * Encodes directly on device GPU without watermark.
 */
class MediaTransformerHelper(private val context: Context) {

    suspend fun exportVideo(
        inputUris: List<Uri>,
        outputFile: File,
        contrastLevel: Float = 1.0f,
        onProgress: (Int) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val editedMediaItems = inputUris.map { uri ->
                val mediaItem = MediaItem.fromUri(uri)
                val effects = Effects(
                    /* audioProcessors = */ emptyList(),
                    /* videoEffects = */ listOf(
                        Contrast(contrastLevel)
                    )
                )
                EditedMediaItem.Builder(mediaItem)
                    .setEffects(effects)
                    .build()
            }

            val sequence = EditedMediaItemSequence(editedMediaItems)
            val composition = Composition.Builder(listOf(sequence)).build()

            val progressHolder = ProgressHolder()
            var exportSuccess = false
            var exportError: Exception? = null

            val transformer = Transformer.Builder(context)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        exportSuccess = true
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        exportError = exportException
                    }
                })
                .build()

            transformer.start(composition, outputFile.absolutePath)

            // Monitor progress loop
            while (!exportSuccess && exportError == null) {
                val state = transformer.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(progressHolder.progress)
                }
                kotlinx.coroutines.delay(100)
            }

            exportError?.let { return@withContext Result.failure(it) }
            Result.success(outputFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
