package com.sufyan.aieditorpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.sufyan.aieditorpro.R
import com.sufyan.aieditorpro.ui.screens.VideoEditorScreen
import com.sufyan.aieditorpro.ui.screens.PhotoEditorScreen
import com.sufyan.aieditorpro.ui.theme.*

import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SufyanAiEditorTheme {
                val navController = rememberNavController()
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MaterialTheme.colorScheme.background
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "splash",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("splash") {
                            SplashScreen(onTimeout = {
                                navController.navigate("video_editor") {
                                    popUpTo("splash") { inclusive = true }
                                }
                            })
                        }
                        composable("video_editor") {
                            VideoEditorScreen(
                                onNavigateToPhoto = { navController.navigate("photo_editor") }
                            )
                        }
                        composable("photo_editor") {
                            PhotoEditorScreen(
                                onNavigateToVideo = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(1800)
        onTimeout()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Mascot Avatar with electric neon aura
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .border(
                        3.dp,
                        Brush.sweepGradient(listOf(AccentPurple, AccentCyan, Color(0xFF00F0FF), AccentPurple)),
                        RoundedCornerShape(26.dp)
                    )
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "SUFYAN Mascot Logo",
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "SUFYAN AI EDITOR PRO",
                color = SilverPlatinum,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "CINEMA • PHOTO AI • PRO MOBILE",
                color = AccentCyan,
                fontSize = 11.sp,
                letterSpacing = 2.sp
            )
        }
    }
}
