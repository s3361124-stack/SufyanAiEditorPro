# SUFYAN AI EDITOR PRO

A professional, mobile-friendly video and photo editing application built with React, TypeScript, HTML5 Canvas, Web Audio API, Tailwind CSS, and a native Android project written in Kotlin with Jetpack Compose & Media3 ExoPlayer.

---

## 🌟 Feature Overview

1. **Import Media**: Import videos (MP4, WebM, MOV), photos (JPEG, PNG, WebP), and audio files (MP3, WAV, AAC) directly from your device storage or phone gallery.
2. **Real-time Video Playback & Seeking**: Frame-accurate seeking, real-time preview, play/pause, time display, and loop playback.
3. **Trim & Split Video Clips**: Non-destructive clip trimming (in/out points), split at playhead, duplicate, delete, and reorder.
4. **Multiple Independent Timeline Tracks**:
   - Video / Visual track
   - Background audio & sound effects tracks
   - PIP (Picture-in-Picture) overlays
   - Dynamic text & title overlays
5. **Text Overlays, Transitions & Effects**:
   - Title, subtitle, lower-third, callout, and neon styles
   - Animations (Fade, Zoom-in, Slide-up, Glitch, Bounce)
   - Real-time color grading (Brightness, Contrast, Saturation, Sepia, Invert, Hue, Blur)
   - Cinematic film grain, vignette, temperature tinting, and 21:9 anamorphic letterbox
6. **Audio Mixing & Voice Recording**:
   - Synthesizer sound generator & sound effects library
   - Live microphone voiceover recording
   - Per-track volume controls and fade-in/fade-out
   - Real-time waveform audio preview
7. **Hardware-Accelerated Video Rendering & Export**:
   - Multi-resolution exports: 720p HD, 1080p Full HD, 1440p 2K, 4K UHD, 8K FUHD, 10K Master
   - WebM (VP9/VP8) and MP4 (H.264/AAC) containers
   - Web Audio API stream mixing: audio tracks synchronized with video frames
   - In-app playback verification player with real-time frame counter and direct download
8. **Photo Editing & Studio Export**:
   - Aspect ratio cropping (1:1, 4:5, 16:9, 9:16, 3:2, Freeform)
   - Rotation, flip horizontal/vertical
   - Advanced adjustments: Brightness, Contrast, Saturation, Temperature, Sharpness, Vignette, Bokeh Blur
   - High-resolution JPEG/PNG instant export
9. **Local Project Saving & Reopening**:
   - Auto-save to browser local storage
   - Manual project snapshot saving, listing, and instant project loading
10. **Android App & PWA Installation**:
    - Full Progressive Web App (PWA) with offline caching and home screen install banner
    - Complete native Android Kotlin project (`android/`) with Jetpack Compose, ExoPlayer, and Media3 Transformer
    - GitHub Actions automated CI/CD workflow (`.github/workflows/android-build.yml`) for automated free APK compilation

---

## 🚀 Running the Web Application Locally

### Prerequisites
- Node.js 18+ or 20+
- npm or bun

### Setup Steps
```bash
# 1. Install dependencies
npm install

# 2. Start the development server
npm run dev

# 3. Open in your browser
http://localhost:3000
```

### Production Build
```bash
npm run build
```

---

## 📱 Building the Android Application

The repository includes a native Android Studio project located in the `android/` directory.

### Project Details
- **Namespace / App ID**: `com.sufyan.aieditorpro`
- **Target SDK**: 35 (Android 15)
- **Min SDK**: 26 (Android 8.0 Oreo)
- **Language**: Kotlin 1.9.22
- **UI Toolkit**: Jetpack Compose (BOM 2024.10.01, Material 3)
- **Media Engine**: AndroidX Media3 (ExoPlayer 1.4.1 & Media3 Transformer)

### Method 1: Android Studio (Recommended for Desktop)
1. Launch **Android Studio Iguana / Jellyfish** or newer.
2. Select **Open** and choose the `android` directory of this project.
3. Allow Gradle to sync dependencies automatically.
4. Connect an Android device with USB debugging enabled, or launch an Android Virtual Device (AVD).
5. Click **Run** (`Shift + F10`) or select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The resulting APK is located at:
   `android/app/build/outputs/apk/debug/app-debug.apk`

### Method 2: Command Line (CLI)
```bash
cd android
./gradlew assembleDebug
```
*Note: Requires JDK 17 (`JAVA_HOME` pointed to OpenJDK 17) and Android SDK Command-line Tools.*

### Method 3: 100% Free Cloud Build via GitHub Actions (Mobile Phone Friendly)
If you only have an Android phone and no PC:
1. Download the complete project ZIP (`SufyanAiEditorPro-Complete-Source.zip`).
2. Push or upload the repository to your GitHub account.
3. The `.github/workflows/android-build.yml` workflow will automatically trigger on push.
4. Alternatively, navigate to **Actions > Build Android APK > Run workflow**.
5. Once completed (~2 minutes), download the generated `SufyanAiEditorPro-Debug-APK` artifact directly to your phone and install it.

---

## 📦 Complete Source Code Download

The full, uncompressed, clean source code archive containing all web files, Android Kotlin files, Gradle configs, build workflows, and branding assets is available at:
`public/SufyanAiEditorPro-Complete-Source.zip` (accessible directly in the browser via `/SufyanAiEditorPro-Complete-Source.zip`).
